import { Home, Search, Bookmark, User, Menu } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { useState } from "react";

export function MobileNav() {
  const navigate = useNavigate();
  const location = useLocation();
  
  const navItems = [
    { id: "home", label: "Home", icon: Home, path: "/" },
    { id: "search", label: "Search", icon: Search, path: "/search" },
    { id: "saved", label: "Saved", icon: Bookmark, path: "/saved" },
    { id: "menu", label: "Menu", icon: Menu, path: "/menu" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Mobile Bottom Navigation - Fixed */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-40 safe-area-bottom">
        <div className="grid grid-cols-4 h-16">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center justify-center gap-1 transition-colors touch-manipulation ${
                  active 
                    ? "text-blue-600" 
                    : "text-slate-600 active:text-blue-600"
                }`}
              >
                <Icon className={`size-5 ${active ? "fill-blue-100" : ""}`} />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Spacer for fixed bottom nav on mobile */}
      <div className="md:hidden h-16" />
    </>
  );
}

// Mobile Header Component
interface MobileHeaderProps {
  title: string;
  onBack?: () => void;
  actions?: React.ReactNode;
}

export function MobileHeader({ title, onBack, actions }: MobileHeaderProps) {
  return (
    <header className="sticky top-0 bg-white border-b border-slate-200 z-30 md:static">
      <div className="flex items-center justify-between px-4 py-3 min-h-[56px]">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {onBack && (
            <button
              onClick={onBack}
              className="flex-shrink-0 -ml-2 p-2 rounded-lg active:bg-slate-100 touch-manipulation"
              aria-label="Go back"
            >
              <svg className="size-6 text-slate-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          <h1 className="text-lg font-semibold text-slate-900 truncate">{title}</h1>
        </div>
        {actions && <div className="flex-shrink-0 ml-2">{actions}</div>}
      </div>
    </header>
  );
}
