import { X } from "lucide-react";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { useEffect } from "react";

interface FilterSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  onApply?: () => void;
  onReset?: () => void;
}

export function FilterSheet({ 
  isOpen, 
  onClose, 
  title = "Filters", 
  children,
  onApply,
  onReset 
}: FilterSheetProps) {
  // Prevent body scroll when sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/50 z-50 md:hidden"
        onClick={onClose}
      />
      
      {/* Sheet */}
      <div className="fixed inset-x-0 bottom-0 z-50 md:hidden">
        <div className="bg-white rounded-t-2xl shadow-2xl max-h-[85vh] flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-4 border-b border-slate-200">
            <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
            <button
              onClick={onClose}
              className="p-2 -mr-2 rounded-lg active:bg-slate-100 touch-manipulation"
              aria-label="Close filters"
            >
              <X className="size-5 text-slate-600" />
            </button>
          </div>

          {/* Content */}
          <ScrollArea className="flex-1 overflow-y-auto">
            <div className="px-4 py-4">
              {children}
            </div>
          </ScrollArea>

          {/* Footer Actions */}
          {(onApply || onReset) && (
            <div className="flex gap-3 px-4 py-3 border-t border-slate-200 bg-slate-50">
              {onReset && (
                <Button
                  variant="outline"
                  onClick={onReset}
                  className="flex-1 h-12 touch-manipulation"
                >
                  Reset
                </Button>
              )}
              {onApply && (
                <Button
                  onClick={() => {
                    onApply();
                    onClose();
                  }}
                  className="flex-1 h-12 touch-manipulation"
                >
                  Apply Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
