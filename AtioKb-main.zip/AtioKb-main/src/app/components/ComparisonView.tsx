import { X, Download, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Technology, SDG_COLORS, SDG_NAMES } from "../data/mockTechnologies";

interface ComparisonViewProps {
  technologies: Technology[];
  onClose: () => void;
}

export function ComparisonView({ technologies, onClose }: ComparisonViewProps) {
  if (technologies.length === 0) return null;

  const comparisonRows = [
    {
      label: "Innovation Name",
      render: (tech: Technology) => (
        <div>
          <h3 className="font-semibold text-base text-slate-900 mb-1">{tech.title}</h3>
          <p className="text-sm text-slate-600">{tech.summary}</p>
        </div>
      ),
    },
    {
      label: "Region / Countries",
      render: (tech: Technology) => (
        <div>
          <p className="text-sm font-medium text-slate-900">{tech.region.join(", ")}</p>
          <p className="text-xs text-slate-600 mt-1">{tech.countries.join(", ")}</p>
        </div>
      ),
    },
    {
      label: "SDG Alignment",
      render: (tech: Technology) => (
        <div className="flex flex-wrap gap-2">
          {tech.sdgs.map((sdg) => {
            const colors = SDG_COLORS[sdg];
            return (
              <div
                key={sdg}
                className={`${colors.bg} ${colors.text} px-3 py-2 rounded-lg font-semibold text-sm flex items-center gap-2`}
                title={`SDG ${sdg}: ${SDG_NAMES[sdg]}`}
              >
                <span className="text-lg">{sdg}</span>
                <span className="hidden md:inline text-xs">{SDG_NAMES[sdg]}</span>
              </div>
            );
          })}
        </div>
      ),
    },
    {
      label: "Readiness Level (TRL)",
      render: (tech: Technology) => (
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl font-bold text-blue-700">{tech.readinessLevel}</span>
            <span className="text-xs text-slate-600">/ 9</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all"
              style={{ width: `${(tech.readinessLevel / 9) * 100}%` }}
            />
          </div>
        </div>
      ),
    },
    {
      label: "Adoption Level",
      render: (tech: Technology) => {
        const colors = {
          low: "bg-yellow-100 text-yellow-800",
          medium: "bg-blue-100 text-blue-800",
          high: "bg-green-100 text-green-800",
        };
        return (
          <Badge className={`${colors[tech.adoptionLevel]} capitalize text-sm px-4 py-1`}>
            {tech.adoptionLevel}
          </Badge>
        );
      },
    },
    {
      label: "Key Impact Metrics",
      render: (tech: Technology) => (
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-600">Productivity</span>
            <span className="text-sm font-bold text-green-700">+{tech.impact.productivity}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-600">Resilience</span>
            <span className="text-sm font-bold text-blue-700">+{tech.impact.resilience}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-600">Nutrition</span>
            <span className="text-sm font-bold text-orange-700">+{tech.impact.nutrition}%</span>
          </div>
        </div>
      ),
    },
    {
      label: "Cost / Resources",
      render: (tech: Technology) => {
        const costColors = {
          low: "bg-green-100 text-green-800",
          medium: "bg-yellow-100 text-yellow-800",
          high: "bg-red-100 text-red-800",
        };
        const labourColors = {
          low: "bg-green-100 text-green-800",
          medium: "bg-yellow-100 text-yellow-800",
          high: "bg-red-100 text-red-800",
        };
        return (
          <div className="space-y-2">
            <div>
              <span className="text-xs text-slate-600 block mb-1">Cost Level:</span>
              <Badge className={`${costColors[tech.costLevel]} capitalize`}>
                {tech.costLevel}
              </Badge>
            </div>
            <div>
              <span className="text-xs text-slate-600 block mb-1">Labour:</span>
              <Badge className={`${labourColors[tech.labourIntensity]} capitalize`}>
                {tech.labourIntensity}
              </Badge>
            </div>
          </div>
        );
      },
    },
    {
      label: "Evidence Strength",
      render: (tech: Technology) => {
        const evidenceColors = {
          low: "bg-slate-100 text-slate-700 border-slate-300",
          medium: "bg-blue-100 text-blue-800 border-blue-300",
          high: "bg-green-100 text-green-800 border-green-300",
        };
        return (
          <div>
            <Badge className={`${evidenceColors[tech.evidenceStrength]} capitalize text-sm px-4 py-2 border`}>
              {tech.evidenceStrength}
            </Badge>
            <p className="text-xs text-slate-500 mt-2">{tech.evidenceLinks.length} studies referenced</p>
          </div>
        );
      },
    },
  ];

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="min-h-screen p-4 md:p-6 lg:p-8">
        <Card className="max-w-7xl mx-auto bg-white">
          {/* Header */}
          <div className="sticky top-0 bg-white border-b border-slate-200 p-4 md:p-6 flex items-center justify-between z-10">
            <div>
              <h2 className="text-xl md:text-2xl font-bold text-slate-900">Compare Innovations</h2>
              <p className="text-sm text-slate-600 mt-1">Side-by-side comparison of {technologies.length} innovations</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="hidden md:flex">
                <Download className="size-4 mr-2" />
                Export
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="size-4 md:mr-2" />
                <span className="hidden md:inline">Close</span>
              </Button>
            </div>
          </div>

          {/* Desktop/Tablet: Side-by-side comparison */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="p-4 text-left w-1/4 bg-slate-50 sticky left-0 z-10">
                    <span className="text-sm font-semibold text-slate-700">Criteria</span>
                  </th>
                  {technologies.map((tech) => (
                    <th key={tech.id} className="p-4 text-left bg-slate-50">
                      <span className="text-sm font-semibold text-slate-900">{tech.innovationType}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row, index) => (
                  <tr key={index} className="border-b border-slate-200 hover:bg-slate-50">
                    <td className="p-4 align-top bg-white sticky left-0 z-10">
                      <span className="text-sm font-semibold text-slate-700">{row.label}</span>
                    </td>
                    {technologies.map((tech) => (
                      <td key={tech.id} className="p-4 align-top">
                        {row.render(tech)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile: Stacked comparison */}
          <div className="md:hidden p-4 space-y-6">
            {comparisonRows.map((row, index) => (
              <div key={index} className="border-b border-slate-200 pb-6 last:border-0">
                <h3 className="text-sm font-semibold text-slate-700 mb-4">{row.label}</h3>
                <div className="space-y-4">
                  {technologies.map((tech) => (
                    <Card key={tech.id} className="p-4 bg-slate-50">
                      <p className="text-xs text-slate-500 mb-2">{tech.title}</p>
                      {row.render(tech)}
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="border-t border-slate-200 p-4 md:p-6 bg-slate-50">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <p className="text-sm text-slate-600">
                Compare detailed evidence and implementation guides in full technology profiles
              </p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={onClose}>
                  <ArrowLeft className="size-4 mr-2" />
                  Back to Search
                </Button>
                <Button className="md:hidden">
                  <Download className="size-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
