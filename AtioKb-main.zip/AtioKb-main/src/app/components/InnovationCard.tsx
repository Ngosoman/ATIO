import { Badge } from "./ui/badge";
import { Card } from "./ui/card";
import { ATIOInnovation, SDG_COLORS, SDG_NAMES, getAdoptionBadgeColor, getEvidenceBadgeColor } from "../data/atioInnovations";
import { MapPin, Lightbulb, Users, TrendingUp } from "lucide-react";

interface InnovationCardProps {
  innovation: ATIOInnovation;
  variant?: "policy" | "farmer" | "researcher";
  onClick?: () => void;
  selected?: boolean;
  showCheckbox?: boolean;
  onCheckboxChange?: (checked: boolean) => void;
  className?: string;
}

export function InnovationCard({
  innovation,
  variant = "policy",
  onClick,
  selected = false,
  showCheckbox = false,
  onCheckboxChange,
  className = ""
}: InnovationCardProps) {
  
  if (variant === "farmer") {
    return (
      <Card 
        className={`p-4 md:p-6 cursor-pointer hover:shadow-lg transition-shadow ${className}`}
        onClick={onClick}
      >
        <div className="space-y-4">
          {/* Header */}
          <div>
            <h3 className="font-semibold text-base md:text-lg text-slate-900 mb-2">
              {innovation.name}
            </h3>
            <p className="text-sm md:text-base text-slate-700">
              {innovation.farmer_friendly_description || innovation.short_description}
            </p>
          </div>

          {/* Simple Tags - What it helps with */}
          <div className="flex flex-wrap gap-2">
            {innovation.use_cases.slice(0, 2).map((useCase, idx) => (
              <Badge key={idx} variant="secondary" className="text-xs">
                {useCase}
              </Badge>
            ))}
          </div>

          {/* Simplified adoption badge */}
          <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
            <div className="flex items-center gap-2">
              <MapPin className="size-4 text-slate-500" />
              <span className="text-xs text-slate-600">
                Used in {innovation.countries_adoption.length} countries
              </span>
            </div>
            <Badge className={getAdoptionBadgeColor(innovation.adoption_level)}>
              {innovation.adoption_level === "early" ? "New" : 
               innovation.adoption_level === "growing" ? "Growing" : 
               innovation.adoption_level === "common" ? "Common" : "Proven"}
            </Badge>
          </div>
        </div>
      </Card>
    );
  }

  if (variant === "researcher") {
    return (
      <Card 
        className={`p-5 md:p-6 cursor-pointer hover:shadow-lg transition-shadow ${selected ? "ring-2 ring-blue-500" : ""} ${className}`}
        onClick={onClick}
      >
        <div className="space-y-4">
          {/* Header with Type */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className="capitalize">
                  {innovation.type}
                </Badge>
                <Badge className={getEvidenceBadgeColor(innovation.evidence_strength)}>
                  {innovation.evidence_strength} evidence
                </Badge>
              </div>
              <h3 className="font-semibold text-lg text-slate-900 mb-2">
                {innovation.name}
              </h3>
              <p className="text-sm text-slate-600 mb-1">
                {innovation.region.join(", ")}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <div className="text-xs text-slate-500">Readiness</div>
              <div className="text-lg font-bold text-blue-600">{innovation.readiness_level}/9</div>
            </div>
          </div>

          {/* Description */}
          <p className="text-sm text-slate-700 line-clamp-2">
            {innovation.short_description}
          </p>

          {/* Use Cases */}
          <div>
            <p className="text-xs font-semibold text-slate-600 mb-2">Use Cases:</p>
            <div className="flex flex-wrap gap-2">
              {innovation.use_cases.map((useCase, idx) => (
                <Badge key={idx} variant="secondary" className="text-xs">
                  {useCase}
                </Badge>
              ))}
            </div>
          </div>

          {/* SDG Tags */}
          <div className="flex items-center gap-2 flex-wrap pt-3 border-t border-slate-200">
            <span className="text-xs font-medium text-slate-600">SDGs:</span>
            {innovation.impact_sdgs.map((sdg) => {
              const sdgColors = SDG_COLORS[sdg];
              return (
                <div
                  key={sdg}
                  className={`${sdgColors.bg} ${sdgColors.text} px-2 py-1 rounded font-semibold text-xs`}
                  title={`SDG ${sdg}: ${SDG_NAMES[sdg]}`}
                >
                  {sdg}
                </div>
              );
            })}
          </div>

          {/* Data Source */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Lightbulb className="size-3" />
            <span className="line-clamp-1">{innovation.data_source}</span>
          </div>
        </div>
      </Card>
    );
  }

  // Policy Maker variant (default)
  return (
    <Card 
      className={`p-5 md:p-6 cursor-pointer hover:shadow-lg transition-shadow ${selected ? "ring-2 ring-blue-500" : ""} ${className}`}
      onClick={onClick}
    >
      <div className="flex gap-4">
        {/* Selection Checkbox (if enabled) */}
        {showCheckbox && (
          <div className="flex items-start pt-1">
            <input
              type="checkbox"
              checked={selected}
              onChange={(e) => {
                e.stopPropagation();
                onCheckboxChange?.(e.target.checked);
              }}
              onClick={(e) => e.stopPropagation()}
              className="size-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 touch-manipulation"
            />
          </div>
        )}

        <div className="flex-1 space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="font-semibold text-base md:text-lg text-slate-900 mb-1">
                {innovation.name}
              </h3>
              <p className="text-xs md:text-sm text-slate-600">
                {innovation.region.join(", ")} • {innovation.type}
              </p>
            </div>
            <div className="flex gap-2 flex-wrap justify-end">
              <Badge className={getEvidenceBadgeColor(innovation.evidence_strength)}>
                {innovation.evidence_strength} evidence
              </Badge>
              <Badge className={getAdoptionBadgeColor(innovation.adoption_level)}>
                {innovation.adoption_level}
              </Badge>
            </div>
          </div>

          {/* Description */}
          <p className="text-sm text-slate-700">
            {innovation.short_description}
          </p>

          {/* SDG Tags */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-medium text-slate-600">Impact SDGs:</span>
            {innovation.impact_sdgs.map((sdg) => {
              const sdgColors = SDG_COLORS[sdg];
              return (
                <div
                  key={sdg}
                  className={`${sdgColors.bg} ${sdgColors.text} px-2.5 py-1 rounded-md font-semibold text-xs flex items-center gap-1.5`}
                  title={`SDG ${sdg}: ${SDG_NAMES[sdg]}`}
                >
                  <span>{sdg}</span>
                  <span className="hidden lg:inline">{SDG_NAMES[sdg]}</span>
                </div>
              );
            })}
          </div>

          {/* Readiness & Adoption Indicators */}
          <div className="flex items-center gap-6 pt-3 border-t border-slate-200">
            <div className="flex items-center gap-2">
              <TrendingUp className="size-4 text-blue-600" />
              <div>
                <p className="text-xs text-slate-600">Readiness</p>
                <p className="text-sm font-semibold text-slate-900">{innovation.readiness_level}/9</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="size-4 text-green-600" />
              <div>
                <p className="text-xs text-slate-600">Adopted in</p>
                <p className="text-sm font-semibold text-slate-900">{innovation.countries_adoption.length} countries</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Users className="size-4 text-purple-600" />
              <div>
                <p className="text-xs text-slate-600">Partners</p>
                <p className="text-sm font-semibold text-slate-900">{innovation.partners.length}</p>
              </div>
            </div>
          </div>

          {/* Countries */}
          <div className="text-xs text-slate-500">
            <span className="font-medium">Countries: </span>
            {innovation.countries_adoption.slice(0, 5).join(", ")}
            {innovation.countries_adoption.length > 5 && ` +${innovation.countries_adoption.length - 5} more`}
          </div>
        </div>
      </div>
    </Card>
  );
}
