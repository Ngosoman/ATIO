import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Heart, Share2, Trash2 } from "lucide-react";
import { Button } from "../components/ui/button";
import { atioInnovations } from "../data/atioInnovations";
import { FarmerBottomNav } from "./FarmerHome";

export function FarmerSaved() {
  const navigate = useNavigate();
  // In a real app, this would come from localStorage or a backend
  const [savedIds, setSavedIds] = useState<string[]>(["atio-001", "atio-002"]);

  const savedInnovations = atioInnovations.filter(i => savedIds.includes(i.id));

  const handleRemove = (id: string) => {
    setSavedIds(savedIds.filter(savedId => savedId !== id));
  };

  const getBadgeText = (level: string) => {
    switch(level) {
      case "early": return "New";
      case "growing": return "Growing";
      case "common": return "Common";
      case "widespread": return "Proven";
      default: return level;
    }
  };

  const getBadgeColor = (level: string) => {
    switch(level) {
      case "early": return "bg-purple-100 text-purple-800";
      case "growing": return "bg-blue-100 text-blue-800";
      case "common": return "bg-green-100 text-green-800";
      case "widespread": return "bg-teal-100 text-teal-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 via-white to-red-50 pb-20">
      {/* Header */}
      <header className="bg-gradient-to-r from-red-500 to-pink-600 text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Heart className="size-8 fill-white" />
            <h1 className="text-2xl font-bold">Saved Solutions</h1>
          </div>
          <p className="text-red-100 text-sm">
            {savedInnovations.length} solution{savedInnovations.length !== 1 ? "s" : ""} saved for later
          </p>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        {savedInnovations.length > 0 ? (
          <>
            {/* Share all button */}
            <div className="mb-6">
              <Button
                variant="outline"
                size="lg"
                className="w-full h-12 touch-manipulation border-2"
                onClick={() => {
                  // In a real app, this would open a share sheet
                  alert("Share feature coming soon!");
                }}
              >
                <Share2 className="size-5 mr-2" />
                Share all with my farmer group
              </Button>
            </div>

            {/* Saved items */}
            <div className="space-y-3">
              {savedInnovations.map((innovation) => (
                <div
                  key={innovation.id}
                  className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden"
                >
                  <button
                    onClick={() => navigate(`/innovation/${innovation.id}?role=farmer`)}
                    className="w-full p-5 text-left touch-manipulation active:bg-slate-50"
                  >
                    <h3 className="font-semibold text-base text-slate-900 mb-2 leading-snug">
                      {innovation.name}
                    </h3>
                    
                    <p className="text-sm text-slate-700 mb-3 leading-relaxed line-clamp-2">
                      {innovation.farmer_friendly_description || innovation.short_description}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500">
                        📍 {innovation.countries_adoption.length} countries
                      </span>
                      <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${getBadgeColor(innovation.adoption_level)}`}>
                        {getBadgeText(innovation.adoption_level)}
                      </span>
                    </div>
                  </button>

                  {/* Action buttons */}
                  <div className="flex border-t border-slate-200">
                    <button
                      onClick={() => {
                        // Share individual item
                        alert("Share feature coming soon!");
                      }}
                      className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium text-blue-600 active:bg-blue-50 touch-manipulation"
                    >
                      <Share2 className="size-4" />
                      Share
                    </button>
                    <div className="w-px bg-slate-200" />
                    <button
                      onClick={() => handleRemove(innovation.id)}
                      className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium text-red-600 active:bg-red-50 touch-manipulation"
                    >
                      <Trash2 className="size-4" />
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          /* Empty state */
          <div className="text-center py-16">
            <div className="text-6xl mb-4">❤️</div>
            <h2 className="text-xl font-bold text-slate-900 mb-3">
              No saved solutions yet
            </h2>
            <p className="text-sm text-slate-600 mb-6 max-w-xs mx-auto leading-relaxed">
              When you find solutions you like, tap the heart icon to save them here for later.
            </p>
            <Button
              size="lg"
              onClick={() => navigate("/farmer/search")}
              className="h-12 px-6 bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white touch-manipulation"
            >
              Browse solutions
            </Button>
          </div>
        )}

        {/* Tips section */}
        {savedInnovations.length > 0 && (
          <div className="mt-8 bg-blue-50 rounded-2xl p-5 border border-blue-200">
            <div className="flex items-start gap-3">
              <div className="text-2xl">💡</div>
              <div>
                <h3 className="font-semibold text-blue-900 mb-2 text-base">
                  Next steps
                </h3>
                <ul className="text-sm text-blue-800 space-y-1.5 leading-relaxed">
                  <li>• Discuss these ideas with your farmer group</li>
                  <li>• Ask your extension officer for advice</li>
                  <li>• Try one solution at a time</li>
                  <li>• Share what works with other farmers</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <FarmerBottomNav currentPage="saved" />
    </div>
  );
}
