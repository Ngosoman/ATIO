import { useState } from "react";
import { useNavigate } from "react-router";
import { 
  ArrowLeft, 
  Search, 
  TrendingUp, 
  DollarSign,
  Users,
  Briefcase,
  Target,
  Filter,
  Bookmark
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { mockTechnologies } from "../data/mockTechnologies";

export function AgripreneurDashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"discover" | "pipeline">("discover");
  const [pipeline, setPipeline] = useState<{
    explore: string[];
    evaluate: string[];
    engage: string[];
    pilot: string[];
  }>({
    explore: ["1", "2"],
    evaluate: ["3"],
    engage: [],
    pilot: [],
  });

  const filteredTechnologies = mockTechnologies.filter((tech) => {
    const matchesSearch = searchQuery === "" || 
      tech.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.summary.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesSearch;
  });

  const addToPipeline = (techId: string, stage: keyof typeof pipeline) => {
    setPipeline(prev => ({
      ...prev,
      [stage]: [...prev[stage], techId]
    }));
  };

  const movePipelineStage = (techId: string, fromStage: keyof typeof pipeline, toStage: keyof typeof pipeline) => {
    setPipeline(prev => ({
      ...prev,
      [fromStage]: prev[fromStage].filter(id => id !== techId),
      [toStage]: [...prev[toStage], techId]
    }));
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
              >
                <ArrowLeft className="size-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-xl font-bold text-slate-900">Agripreneur Dashboard</h1>
                <p className="text-sm text-slate-600">Discover innovations and build partnerships</p>
              </div>
            </div>
            <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "discover" | "pipeline")}>
              <TabsList>
                <TabsTrigger value="discover">Discover</TabsTrigger>
                <TabsTrigger value="pipeline">
                  My Pipeline ({Object.values(pipeline).flat().length})
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {viewMode === "discover" && (
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="Search for market-ready innovations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {viewMode === "discover" ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredTechnologies.map((tech) => (
              <Card key={tech.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-lg text-slate-900 mb-1">{tech.title}</h3>
                    <p className="text-sm text-slate-600">{tech.domain}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => addToPipeline(tech.id, "explore")}
                  >
                    <Bookmark className="size-4 mr-1" />
                    Track
                  </Button>
                </div>

                <p className="text-sm text-slate-700 mb-4">{tech.summary}</p>

                {/* Business Metrics */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="bg-green-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <TrendingUp className="size-4 text-green-700" />
                      <span className="text-xs text-green-700">ROI Potential</span>
                    </div>
                    <p className="text-lg font-bold text-green-900">
                      +{tech.impact.productivity}%
                    </p>
                  </div>

                  <div className="bg-blue-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <DollarSign className="size-4 text-blue-700" />
                      <span className="text-xs text-blue-700">Cost</span>
                    </div>
                    <p className="text-sm font-bold text-blue-900 capitalize">
                      {tech.costLevel}
                    </p>
                  </div>

                  <div className="bg-purple-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="size-4 text-purple-700" />
                      <span className="text-xs text-purple-700">Adoption</span>
                    </div>
                    <p className="text-sm font-bold text-purple-900 capitalize">
                      {tech.adoptionLevel}
                    </p>
                  </div>
                </div>

                {/* Market Info */}
                {tech.marketSegments && tech.marketSegments.length > 0 && (
                  <div className="mb-4 pb-4 border-b border-slate-200">
                    <p className="text-xs font-semibold text-slate-600 mb-2">Target Markets:</p>
                    <div className="flex flex-wrap gap-1">
                      {tech.marketSegments.map((segment, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {segment}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Partners */}
                <div className="mb-4">
                  <p className="text-xs font-semibold text-slate-600 mb-2">
                    <Briefcase className="size-3 inline mr-1" />
                    Partners:
                  </p>
                  <p className="text-sm text-slate-700">
                    {tech.partnerOrganizations.slice(0, 2).join(", ")}
                    {tech.partnerOrganizations.length > 2 && ` +${tech.partnerOrganizations.length - 2} more`}
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => navigate(`/technology/${tech.id}?role=agripreneur`)}
                  >
                    View Business Case
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => alert("Contact feature coming soon")}
                  >
                    <Target className="size-4 mr-1" />
                    Contact
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          /* Pipeline View - Kanban Style */
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {(["explore", "evaluate", "engage", "pilot"] as const).map((stage) => (
              <div key={stage} className="bg-white rounded-lg p-4 border border-slate-200">
                <h3 className="font-semibold text-sm text-slate-900 mb-1 capitalize">{stage}</h3>
                <p className="text-xs text-slate-500 mb-4">{pipeline[stage].length} innovations</p>
                
                <div className="space-y-3">
                  {pipeline[stage].map((techId) => {
                    const tech = mockTechnologies.find(t => t.id === techId);
                    if (!tech) return null;

                    return (
                      <Card key={techId} className="p-3 cursor-pointer hover:shadow-md" onClick={() => navigate(`/technology/${techId}?role=agripreneur`)}>
                        <h4 className="font-medium text-sm text-slate-900 mb-2">{tech.title}</h4>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="text-xs capitalize">{tech.costLevel} cost</Badge>
                          <Badge variant="outline" className="text-xs">TRL {tech.readinessLevel}</Badge>
                        </div>
                        {stage !== "pilot" && (
                          <Button
                            size="sm"
                            variant="secondary"
                            className="w-full text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              const stages = ["explore", "evaluate", "engage", "pilot"] as const;
                              const currentIndex = stages.indexOf(stage);
                              if (currentIndex < stages.length - 1) {
                                movePipelineStage(techId, stage, stages[currentIndex + 1]);
                              }
                            }}
                          >
                            Move to {stage === "explore" ? "Evaluate" : stage === "evaluate" ? "Engage" : "Pilot"}
                          </Button>
                        )}
                      </Card>
                    );
                  })}

                  {pipeline[stage].length === 0 && (
                    <p className="text-sm text-slate-400 text-center py-8">No innovations yet</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
