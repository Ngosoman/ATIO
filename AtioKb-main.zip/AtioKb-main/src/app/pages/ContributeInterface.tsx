import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Upload, Shield, Info, CheckCircle2, MapPin, Users, Lightbulb } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import { Card } from "../components/ui/card";
import { Checkbox } from "../components/ui/checkbox";
import { Badge } from "../components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";

export function ContributeInterface() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    innovationName: "",
    location: "",
    problemSolved: "",
    description: "",
    outcomes: "",
    challenges: "",
    resources: "",
    genderImpact: "",
    consent: false,
    attribution: "",
  });

  const steps = [
    { number: 1, title: "Context", icon: <MapPin className="size-5" /> },
    { number: 2, title: "Solution", icon: <Lightbulb className="size-5" /> },
    { number: 3, title: "Impact", icon: <Users className="size-5" /> },
    { number: 4, title: "Consent", icon: <Shield className="size-5" /> },
  ];

  const handleNext = () => {
    if (currentStep < 4) setCurrentStep(currentStep + 1);
  };

  const handlePrevious = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleSubmit = () => {
    alert("Thank you for sharing your innovation! Your submission will be reviewed and added to the knowledge base.");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="size-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Share Your Innovation</h1>
              <p className="text-sm text-slate-600">Your knowledge matters to the community</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Info Banner */}
        <Card className="p-6 bg-blue-50 border-blue-200 mb-8">
          <div className="flex gap-4">
            <Info className="size-6 text-blue-700 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Why Your Knowledge Matters</h3>
              <p className="text-sm text-blue-800 mb-3">
                Traditional and grassroots innovations are vital to the ATIO Knowledge Base. Your experience helps other farmers, communities, and organizations learn what works in real conditions.
              </p>
              <div className="flex gap-4 text-sm text-blue-700">
                <span className="flex items-center gap-1">
                  <Shield className="size-4" />
                  Protected data
                </span>
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="size-4" />
                  Full attribution
                </span>
              </div>
            </div>
          </div>
        </Card>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, idx) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center">
                  <div className={`size-12 rounded-full flex items-center justify-center font-semibold transition-colors ${
                    currentStep >= step.number 
                      ? "bg-amber-500 text-white" 
                      : "bg-slate-200 text-slate-500"
                  }`}>
                    {step.icon}
                  </div>
                  <span className="text-xs mt-2 font-medium text-slate-700">{step.title}</span>
                </div>
                {idx < steps.length - 1 && (
                  <div className={`flex-1 h-1 mx-4 rounded transition-colors ${
                    currentStep > step.number ? "bg-amber-500" : "bg-slate-200"
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <Card className="p-8">
          {currentStep === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Tell Us About the Context</h2>
              <p className="text-slate-600 mb-6">Where is this innovation used and what problem does it solve?</p>

              <div>
                <Label htmlFor="innovationName" className="text-base">Innovation Name *</Label>
                <Input
                  id="innovationName"
                  placeholder="e.g., Clay pot irrigation for vegetable gardens"
                  value={formData.innovationName}
                  onChange={(e) => setFormData({...formData, innovationName: e.target.value})}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="location" className="text-base">Location *</Label>
                <Input
                  id="location"
                  placeholder="Village, District, Country"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="problemSolved" className="text-base">What Problem Does It Solve? *</Label>
                <Textarea
                  id="problemSolved"
                  placeholder="Describe the challenge this innovation addresses..."
                  value={formData.problemSolved}
                  onChange={(e) => setFormData({...formData, problemSolved: e.target.value})}
                  className="mt-2 min-h-[100px]"
                />
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Describe the Solution</h2>
              <p className="text-slate-600 mb-6">How does it work and what do you need to implement it?</p>

              <div>
                <Label htmlFor="description" className="text-base">How Does It Work? *</Label>
                <Textarea
                  id="description"
                  placeholder="Explain the innovation in your own words..."
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="mt-2 min-h-[120px]"
                />
              </div>

              <div>
                <Label htmlFor="resources" className="text-base">What Resources Are Needed?</Label>
                <Textarea
                  id="resources"
                  placeholder="List materials, tools, skills, or support needed..."
                  value={formData.resources}
                  onChange={(e) => setFormData({...formData, resources: e.target.value})}
                  className="mt-2 min-h-[80px]"
                />
              </div>

              <div>
                <Label className="text-base mb-2 block">Innovation Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="crop">Crop/Livestock Practice</SelectItem>
                    <SelectItem value="water">Water Management</SelectItem>
                    <SelectItem value="soil">Soil Health</SelectItem>
                    <SelectItem value="postharvest">Post-Harvest</SelectItem>
                    <SelectItem value="social">Social/Organizational</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Share the Impact</h2>
              <p className="text-slate-600 mb-6">What changed and what did you learn?</p>

              <div>
                <Label htmlFor="outcomes" className="text-base">What Changed? *</Label>
                <Textarea
                  id="outcomes"
                  placeholder="Describe social, economic, or environmental outcomes..."
                  value={formData.outcomes}
                  onChange={(e) => setFormData({...formData, outcomes: e.target.value})}
                  className="mt-2 min-h-[100px]"
                />
              </div>

              <div>
                <Label htmlFor="challenges" className="text-base">Challenges & Lessons Learned</Label>
                <Textarea
                  id="challenges"
                  placeholder="What difficulties did you face? What would you do differently?"
                  value={formData.challenges}
                  onChange={(e) => setFormData({...formData, challenges: e.target.value})}
                  className="mt-2 min-h-[100px]"
                />
              </div>

              <div>
                <Label htmlFor="genderImpact" className="text-base">Gender & Inclusion Aspects</Label>
                <Textarea
                  id="genderImpact"
                  placeholder="How does this innovation affect women, youth, or other groups?"
                  value={formData.genderImpact}
                  onChange={(e) => setFormData({...formData, genderImpact: e.target.value})}
                  className="mt-2 min-h-[80px]"
                />
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Consent & Attribution</h2>
              <p className="text-slate-600 mb-6">Control how your knowledge is shared</p>

              <Card className="p-5 bg-green-50 border-green-200">
                <h3 className="font-semibold text-green-900 mb-3">Data Governance & Your Rights</h3>
                <ul className="space-y-2 text-sm text-green-800">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="size-4 mt-0.5 flex-shrink-0" />
                    You control how your innovation is shared and attributed
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="size-4 mt-0.5 flex-shrink-0" />
                    You can opt out of sharing sensitive information
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="size-4 mt-0.5 flex-shrink-0" />
                    Traditional knowledge is respected and protected
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="size-4 mt-0.5 flex-shrink-0" />
                    Your data will not be used for AI training without explicit consent
                  </li>
                </ul>
              </Card>

              <div>
                <Label htmlFor="attribution" className="text-base">How Would You Like to Be Credited?</Label>
                <Input
                  id="attribution"
                  placeholder="e.g., Maria K., Smallholder Farmer, Kenya or Anonymous"
                  value={formData.attribution}
                  onChange={(e) => setFormData({...formData, attribution: e.target.value})}
                  className="mt-2"
                />
              </div>

              <div className="space-y-4 p-5 bg-slate-50 rounded-lg">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="consent"
                    checked={formData.consent}
                    onCheckedChange={(checked) => setFormData({...formData, consent: checked as boolean})}
                  />
                  <Label htmlFor="consent" className="text-sm cursor-pointer leading-relaxed">
                    I consent to sharing this innovation in the ATIO Knowledge Base. I understand that it will be attributed as specified above and that I can request changes or removal at any time.
                  </Label>
                </div>
              </div>

              <Card className="p-4 bg-blue-50 border-blue-200">
                <div className="flex gap-3">
                  <Info className="size-5 text-blue-700 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-blue-800">
                    For detailed information about how we protect and use your data, see our <a href="#" className="underline font-medium">Data Governance Policy</a>.
                  </p>
                </div>
              </Card>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-slate-200">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 1}
            >
              Previous
            </Button>
            
            {currentStep < 4 ? (
              <Button onClick={handleNext}>
                Next Step
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={!formData.consent}
              >
                <Upload className="size-4 mr-2" />
                Submit Innovation
              </Button>
            )}
          </div>
        </Card>
      </main>
    </div>
  );
}
