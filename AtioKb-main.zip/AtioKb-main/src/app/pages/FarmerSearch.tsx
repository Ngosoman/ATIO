import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { Search, ArrowLeft, SlidersHorizontal } from "lucide-react";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { atioInnovations } from "../data/atioInnovations";
import { FarmerBottomNav } from "./FarmerHome";

export function FarmerSearch() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialQuery = searchParams.get("q") || "";
  const initialCategory = searchParams.get("category") || "";

  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);

  // Simple filtering for farmers
  const filteredInnovations = atioInnovations.filter((innovation) => {
    const matchesSearch = searchQuery === "" || 
      innovation.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (innovation.farmer_friendly_description || innovation.short_description).toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.use_cases.some(uc => uc.toLowerCase().includes(searchQuery.toLowerCase())) ||
      innovation.challenges_addressed.some(ca => ca.toLowerCase().includes(searchQuery.toLowerCase())) ||
      innovation.theme.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesRegion = !selectedRegion || innovation.region.includes(selectedRegion);

    return matchesSearch && matchesRegion;
  });

  const regions = ["East Africa", "West Africa", "Southern Africa", "Central Africa"];

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Progress Indicator */}
      <div className="bg-green-600 text-white px-4 py-2 text-center">
        <div className="max-w-2xl mx-auto flex items-center justify-center gap-2 text-xs">
          <span className="opacity-75">Step 1: Describe →</span>
          <span className="font-semibold">Step 2: Pick solution</span>
          <span className="opacity-75">→ Step 3: View details</span>
        </div>
      </div>

      {/* Header with Search */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="px-4 py-3">
          {/* Clear Guidance */}
          <div className="text-center mb-3">
            <p className="text-sm font-medium text-slate-900">
              Pick a solution to explore
            </p>
            <p className="text-xs text-slate-600">
              {filteredInnovations.length} solution{filteredInnovations.length !== 1 ? "s" : ""} match your search
            </p>
          </div>

          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={() => navigate("/farmer")}
              className="p-2 -ml-2 rounded-lg active:bg-slate-100 touch-manipulation"
              aria-label="Go back"
            >
              <ArrowLeft className="size-6 text-slate-700" />
            </button>
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="Refine your search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-base"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 h-12 rounded-lg border-2 touch-manipulation flex items-center gap-2 ${
                showFilters || selectedRegion
                  ? "border-green-600 bg-green-50 text-green-700"
                  : "border-slate-200 bg-white text-slate-600"
              }`}
            >
              <SlidersHorizontal className="size-5" />
              {selectedRegion && (
                <span className="text-xs font-medium">1</span>
              )}
            </button>
          </div>
        </div>

        {/* Simple Region Filter */}
        {showFilters && (
          <div className="px-4 pb-4 pt-2 border-t border-slate-200 bg-slate-50">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                Filter by region
              </p>
              {selectedRegion && (
                <button
                  onClick={() => setSelectedRegion(null)}
                  className="text-xs font-medium text-green-600"
                >
                  Clear filter
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedRegion(null)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors touch-manipulation ${
                  selectedRegion === null
                    ? "bg-green-600 text-white"
                    : "bg-white text-slate-700 border border-slate-200"
                }`}
              >
                All regions
              </button>
              {regions.map((region) => (
                <button
                  key={region}
                  onClick={() => setSelectedRegion(region === selectedRegion ? null : region)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors touch-manipulation ${
                    selectedRegion === region
                      ? "bg-green-600 text-white"
                      : "bg-white text-slate-700 border border-slate-200"
                  }`}
                >
                  {region}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Results */}
      <main className="px-4 py-4 max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-slate-600">
            {filteredInnovations.length} solution{filteredInnovations.length !== 1 ? "s" : ""} found
          </p>
          {initialCategory && (
            <Badge variant="secondary" className="capitalize">
              {initialCategory}
            </Badge>
          )}
        </div>

        <div className="space-y-3">
          {filteredInnovations.map((innovation) => (
            <FarmerInnovationCard
              key={innovation.id}
              innovation={innovation}
              onClick={() => navigate(`/innovation/${innovation.id}?role=farmer`)}
            />
          ))}

          {filteredInnovations.length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl">
              <div className="text-5xl mb-4">🔍</div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                No solutions found
              </h3>
              <p className="text-sm text-slate-600 mb-6 max-w-xs mx-auto">
                Try searching with different words or browse by topic on the home page
              </p>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("");
                  setSelectedRegion(null);
                }}
                className="h-12 px-6 touch-manipulation"
              >
                Clear search
              </Button>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <FarmerBottomNav currentPage="search" />
    </div>
  );
}

// Farmer Innovation Card Component
interface FarmerInnovationCardProps {
  innovation: any;
  onClick: () => void;
}

function FarmerInnovationCard({ innovation, onClick }: FarmerInnovationCardProps) {
  // Get 2-3 simple tags
  const simpleTags: string[] = [];
  
  if (innovation.cost_level === "low") simpleTags.push("Low cost");
  if (innovation.labour_intensity === "low") simpleTags.push("Saves labour");
  if (innovation.target_users.some((u: string) => u.toLowerCase().includes("women"))) {
    simpleTags.push("Women-friendly");
  }
  if (simpleTags.length < 3 && innovation.use_cases[0]) {
    simpleTags.push(innovation.use_cases[0]);
  }

  // Simple adoption badge
  const getBadgeText = (level: string) => {
    switch(level) {
      case "early": return "New";
      case "growing": return "Growing";
      case "common": return "Common";
      case "widespread": return "Proven";
      default: return level;
    }
  };

  const getBadgeColor = (level: string) => {
    switch(level) {
      case "early": return "bg-purple-100 text-purple-800";
      case "growing": return "bg-blue-100 text-blue-800";
      case "common": return "bg-green-100 text-green-800";
      case "widespread": return "bg-teal-100 text-teal-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  return (
    <button
      onClick={onClick}
      className="w-full bg-white rounded-2xl p-5 shadow-sm border border-slate-200 hover:shadow-md transition-all active:scale-98 text-left touch-manipulation"
    >
      {/* Title */}
      <h3 className="font-semibold text-base text-slate-900 mb-2 leading-snug">
        {innovation.name}
      </h3>
      
      {/* Description - 1-2 lines */}
      <p className="text-sm text-slate-700 mb-4 leading-relaxed line-clamp-2">
        {innovation.farmer_friendly_description || innovation.short_description}
      </p>

      {/* Tags */}
      <div className="flex flex-wrap gap-2 mb-3">
        {simpleTags.slice(0, 3).map((tag, idx) => (
          <span 
            key={idx}
            className="text-xs bg-slate-100 text-slate-700 px-3 py-1.5 rounded-full font-medium"
          >
            {tag}
          </span>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">
            📍 Used in {innovation.countries_adoption.length} countries
          </span>
        </div>
        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${getBadgeColor(innovation.adoption_level)}`}>
          {getBadgeText(innovation.adoption_level)}
        </span>
      </div>
    </button>
  );
}