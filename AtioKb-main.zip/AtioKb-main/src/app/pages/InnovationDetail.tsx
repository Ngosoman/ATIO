import { useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router";
import { ArrowLeft, Heart, Share2, ChevronDown, ChevronUp, MapPin, Users, Lightbulb } from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { atioInnovations, SDG_COLORS, SDG_NAMES } from "../data/atioInnovations";
import { FarmerBottomNav } from "./FarmerHome";

export function InnovationDetail() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const role = searchParams.get("role") || "farmer";
  
  const [showMoreDetails, setShowMoreDetails] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const innovation = atioInnovations.find(i => i.id === id);

  if (!innovation) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center">
          <h2 className="text-xl font-bold text-slate-900 mb-2">Innovation not found</h2>
          <Button onClick={() => navigate(-1)}>Go back</Button>
        </div>
      </div>
    );
  }

  // Farmer-specific view
  if (role === "farmer") {
    return <FarmerInnovationDetail innovation={innovation} isSaved={isSaved} setIsSaved={setIsSaved} />;
  }

  // Default view (can be enhanced for other roles)
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-lg active:bg-slate-100 touch-manipulation"
          >
            <ArrowLeft className="size-6 text-slate-700" />
          </button>
          <h1 className="text-lg font-semibold text-slate-900 flex-1 px-3 truncate">
            {innovation.name}
          </h1>
          <button
            onClick={() => setIsSaved(!isSaved)}
            className="p-2 rounded-lg active:bg-slate-100 touch-manipulation"
          >
            <Heart className={`size-6 ${isSaved ? "fill-red-500 text-red-500" : "text-slate-600"}`} />
          </button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-slate-900 mb-4">{innovation.name}</h1>
        <p className="text-base text-slate-700 mb-6">{innovation.short_description}</p>
        
        {/* Add more role-specific content here */}
      </main>
    </div>
  );
}

// Farmer-Focused Innovation Detail Component
function FarmerInnovationDetail({ innovation, isSaved, setIsSaved }: any) {
  const navigate = useNavigate();
  const [showMoreDetails, setShowMoreDetails] = useState(false);

  const getBadgeText = (level: string) => {
    switch(level) {
      case "early": return "New";
      case "growing": return "Growing";
      case "common": return "Common";
      case "widespread": return "Proven";
      default: return level;
    }
  };

  const getBadgeColor = (level: string) => {
    switch(level) {
      case "early": return "bg-purple-100 text-purple-800";
      case "growing": return "bg-blue-100 text-blue-800";
      case "common": return "bg-green-100 text-green-800";
      case "widespread": return "bg-teal-100 text-teal-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Progress Indicator */}
      <div className="bg-green-600 text-white px-4 py-2 text-center">
        <div className="max-w-2xl mx-auto flex items-center justify-center gap-2 text-xs">
          <span className="opacity-75">Step 1: Describe →</span>
          <span className="opacity-75">Step 2: Pick →</span>
          <span className="font-semibold">Step 3: View details</span>
        </div>
      </div>

      {/* Header */}
      <header className="bg-gradient-to-br from-green-600 to-green-700 text-white sticky top-0 z-30 shadow-lg">
        <div className="px-4 py-4">
          {/* Clear Guidance */}
          <div className="text-center mb-3">
            <p className="text-xs text-green-100">Solution details</p>
            <h2 className="text-sm font-semibold">Will this work for your farm?</h2>
          </div>

          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 -ml-2 rounded-lg active:bg-white/20 touch-manipulation"
              aria-label="Go back"
            >
              <ArrowLeft className="size-6 text-white" />
            </button>
            <div className="flex gap-2">
              <button
                onClick={() => setIsSaved(!isSaved)}
                className="p-2 rounded-lg bg-white/20 active:bg-white/30 touch-manipulation"
                aria-label={isSaved ? "Remove from saved" : "Save for later"}
              >
                <Heart className={`size-6 ${isSaved ? "fill-white text-white" : "text-white"}`} />
              </button>
              <button
                className="p-2 rounded-lg bg-white/20 active:bg-white/30 touch-manipulation"
                aria-label="Share"
              >
                <Share2 className="size-6 text-white" />
              </button>
            </div>
          </div>

          <h1 className="text-xl font-bold mb-2 leading-tight">
            {innovation.name}
          </h1>
          
          <div className="flex items-center gap-2">
            <span className={`text-xs px-3 py-1.5 rounded-full font-semibold ${getBadgeColor(innovation.adoption_level)} bg-white`}>
              {getBadgeText(innovation.adoption_level)}
            </span>
            <span className="text-xs bg-white/20 px-3 py-1.5 rounded-full font-medium">
              {innovation.type}
            </span>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        {/* Section 1: What it is */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
          <h2 className="text-lg font-bold text-slate-900 mb-3 flex items-center gap-2">
            <span className="text-xl">💡</span>
            What it is
          </h2>
          <p className="text-base text-slate-700 leading-relaxed mb-4">
            {innovation.farmer_friendly_description || innovation.short_description}
          </p>
          <p className="text-sm text-slate-600 leading-relaxed">
            {innovation.long_description}
          </p>
        </section>

        {/* Section 2: Where it is used */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
          <h2 className="text-lg font-bold text-slate-900 mb-3 flex items-center gap-2">
            <span className="text-xl">📍</span>
            Where it is used
          </h2>
          <div className="space-y-3">
            <div>
              <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">
                Countries ({innovation.countries_adoption.length})
              </p>
              <div className="flex flex-wrap gap-2">
                {innovation.countries_adoption.map((country: string) => (
                  <span key={country} className="text-sm bg-slate-100 text-slate-800 px-3 py-1.5 rounded-lg font-medium">
                    {country}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">
                Regions
              </p>
              <div className="flex flex-wrap gap-2">
                {innovation.region.map((region: string) => (
                  <span key={region} className="text-sm bg-green-100 text-green-800 px-3 py-1.5 rounded-lg font-medium">
                    {region}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Who it is for */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
          <h2 className="text-lg font-bold text-slate-900 mb-3 flex items-center gap-2">
            <span className="text-xl">👥</span>
            Who it is for
          </h2>
          <div className="space-y-3">
            {innovation.target_users.map((user: string, idx: number) => (
              <div key={idx} className="flex items-start gap-3">
                <div className="size-2 bg-green-600 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm text-slate-700 leading-relaxed">{user}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Section 4: Will it work for me? */}
        <section className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-5 border-2 border-blue-200">
          <h2 className="text-lg font-bold text-blue-900 mb-3 flex items-center gap-2">
            <span className="text-xl">✅</span>
            Will it work for me?
          </h2>
          
          {/* Contextual hints based on adoption level */}
          {innovation.adoption_level === "widespread" || innovation.adoption_level === "common" ? (
            <p className="text-sm text-blue-800 leading-relaxed mb-4">
              ✓ <strong>Many farmers are using this successfully.</strong> It has been tested in different places and is working well.
            </p>
          ) : innovation.adoption_level === "growing" ? (
            <p className="text-sm text-blue-800 leading-relaxed mb-4">
              ⚠️ <strong>This is still growing.</strong> Some farmers are trying it and seeing good results. Talk to your extension officer first.
            </p>
          ) : (
            <p className="text-sm text-blue-800 leading-relaxed mb-4">
              ⚠️ <strong>This is new.</strong> Only a few farmers have tried it. Get expert advice before starting.
            </p>
          )}

          {/* Enabling conditions */}
          {innovation.enabling_conditions && innovation.enabling_conditions.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-blue-900 mb-2 uppercase tracking-wide">
                What you need
              </p>
              <div className="space-y-2">
                {innovation.enabling_conditions.map((condition: string, idx: number) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="text-blue-600 mt-0.5">•</span>
                    <p className="text-sm text-blue-800 leading-relaxed">{condition}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Section 5: Steps to get started */}
        <section className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
          <h2 className="text-lg font-bold text-slate-900 mb-3 flex items-center gap-2">
            <span className="text-xl">📋</span>
            Steps to get started
          </h2>
          
          {innovation.simple_steps && innovation.simple_steps.length > 0 ? (
            <div className="space-y-3">
              {innovation.simple_steps.map((step: string, idx: number) => (
                <div key={idx} className="flex gap-3">
                  <div className="flex-shrink-0 size-7 bg-green-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                    {idx + 1}
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed pt-0.5">{step}</p>
                </div>
              ))}
            </div>
          ) : innovation.information_for_use ? (
            <p className="text-sm text-slate-700 leading-relaxed">
              {innovation.information_for_use}
            </p>
          ) : (
            <p className="text-sm text-slate-600 italic">
              Contact your local extension officer for detailed steps.
            </p>
          )}
        </section>

        {/* Local examples */}
        {innovation.local_examples && innovation.local_examples.length > 0 && (
          <section className="bg-green-50 rounded-2xl p-5 border border-green-200">
            <h2 className="text-lg font-bold text-green-900 mb-3 flex items-center gap-2">
              <span className="text-xl">💬</span>
              What other farmers say
            </h2>
            <div className="space-y-4">
              {innovation.local_examples.map((example: string, idx: number) => (
                <div key={idx} className="bg-white rounded-xl p-4 border border-green-200">
                  <p className="text-sm text-slate-700 leading-relaxed italic">
                    "{example}"
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* More details accordion */}
        <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <button
            onClick={() => setShowMoreDetails(!showMoreDetails)}
            className="w-full px-5 py-4 flex items-center justify-between touch-manipulation active:bg-slate-50"
          >
            <span className="text-base font-semibold text-slate-900">
              More details
            </span>
            {showMoreDetails ? (
              <ChevronUp className="size-5 text-slate-600" />
            ) : (
              <ChevronDown className="size-5 text-slate-600" />
            )}
          </button>

          {showMoreDetails && (
            <div className="px-5 pb-5 space-y-4 border-t border-slate-200 pt-4">
              {/* SDG Impact */}
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">
                  UN Sustainable Development Goals
                </p>
                <div className="flex flex-wrap gap-2">
                  {innovation.impact_sdgs.map((sdg: number) => {
                    const sdgColors = SDG_COLORS[sdg];
                    return (
                      <div
                        key={sdg}
                        className={`${sdgColors.bg} ${sdgColors.text} px-3 py-2 rounded-lg font-semibold text-xs`}
                      >
                        SDG {sdg}: {SDG_NAMES[sdg]}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Partners */}
              {innovation.partners && innovation.partners.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">
                    Supporting organizations
                  </p>
                  <p className="text-sm text-slate-700">
                    {innovation.partners.join(", ")}
                  </p>
                </div>
              )}

              {/* Data source */}
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">
                  Information source
                </p>
                <p className="text-sm text-slate-700">
                  {innovation.data_source}
                </p>
              </div>

              {/* Readiness level */}
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">
                  Readiness level
                </p>
                <p className="text-sm text-slate-700">
                  {innovation.readiness_level}/9 - {innovation.atio_innovation_stage}
                </p>
              </div>
            </div>
          )}
        </section>

        {/* Call to action */}
        <section className="bg-gradient-to-br from-green-600 to-green-700 rounded-2xl p-6 text-white text-center">
          <Lightbulb className="size-12 mx-auto mb-4 text-green-100" />
          <h3 className="text-lg font-bold mb-2">
            Want to try this on your farm?
          </h3>
          <p className="text-sm text-green-100 mb-4 leading-relaxed">
            Talk to your local extension officer or farmer group leader for help getting started.
          </p>
          <Button
            size="lg"
            className="w-full h-12 bg-white text-green-700 hover:bg-green-50 font-semibold touch-manipulation"
          >
            Find local support
          </Button>
        </section>
      </main>

      {/* Bottom Navigation */}
      <FarmerBottomNav currentPage="search" />
    </div>
  );
}