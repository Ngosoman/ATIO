import { useNavigate } from "react-router";
import { ArrowLeft, MapPin, Settings, HelpCircle, Share2, LogOut, ChevronRight } from "lucide-react";
import { Button } from "../components/ui/button";
import { FarmerBottomNav } from "./FarmerHome";

export function FarmerProfile() {
  const navigate = useNavigate();

  const menuItems = [
    { id: "location", label: "My location", icon: MapPin, action: () => alert("Location settings coming soon") },
    { id: "settings", label: "Settings", icon: Settings, action: () => alert("Settings coming soon") },
    { id: "help", label: "Help & support", icon: HelpCircle, action: () => alert("Help coming soon") },
    { id: "share", label: "Share this app", icon: Share2, action: () => alert("Share coming soon") },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white pb-20">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-700 to-slate-800 text-white px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={() => navigate("/farmer")}
            className="mb-4 p-2 -ml-2 rounded-lg active:bg-white/20 touch-manipulation"
          >
            <ArrowLeft className="size-6 text-white" />
          </button>

          <div className="flex items-center gap-4">
            <div className="size-20 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-3xl shadow-lg">
              👤
            </div>
            <div>
              <h1 className="text-2xl font-bold mb-1">Farmer Profile</h1>
              <p className="text-slate-300 text-sm">
                Manage your account
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        {/* Profile info card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 mb-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">My Information</h2>
          
          <div className="space-y-3">
            <div>
              <p className="text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Role</p>
              <p className="text-base text-slate-900">Farmer</p>
            </div>
            
            <div>
              <p className="text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Region</p>
              <div className="flex items-center justify-between">
                <p className="text-base text-slate-900">East Africa</p>
                <button
                  onClick={() => alert("Change region coming soon")}
                  className="text-sm font-medium text-green-600 active:text-green-700"
                >
                  Change
                </button>
              </div>
            </div>

            <div>
              <p className="text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Language</p>
              <div className="flex items-center justify-between">
                <p className="text-base text-slate-900">English</p>
                <button
                  onClick={() => alert("Change language coming soon")}
                  className="text-sm font-medium text-green-600 active:text-green-700"
                >
                  Change
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Menu items */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-6">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div key={item.id}>
                {index > 0 && <div className="h-px bg-slate-200 mx-5" />}
                <button
                  onClick={item.action}
                  className="w-full flex items-center justify-between px-5 py-4 text-left active:bg-slate-50 touch-manipulation"
                >
                  <div className="flex items-center gap-3">
                    <Icon className="size-5 text-slate-600" />
                    <span className="text-base font-medium text-slate-900">{item.label}</span>
                  </div>
                  <ChevronRight className="size-5 text-slate-400" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-5 border border-green-200">
            <div className="text-3xl font-bold text-green-700 mb-1">12</div>
            <p className="text-sm text-green-800">Solutions viewed</p>
          </div>
          <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-2xl p-5 border border-red-200">
            <div className="text-3xl font-bold text-red-700 mb-1">2</div>
            <p className="text-sm text-red-800">Solutions saved</p>
          </div>
        </div>

        {/* Change role */}
        <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 mb-6">
          <h3 className="font-semibold text-slate-900 mb-2">
            Not a farmer?
          </h3>
          <p className="text-sm text-slate-600 mb-4 leading-relaxed">
            If you're a policy maker, researcher, or another type of user, you can switch to a different view.
          </p>
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="w-full h-12 touch-manipulation"
          >
            Change my role
          </Button>
        </div>

        {/* About */}
        <div className="text-center text-sm text-slate-500 space-y-2">
          <p>FAO ATIO Knowledge Base</p>
          <p>Version 1.0.0</p>
          <button className="text-green-600 font-medium">
            Privacy Policy
          </button>
        </div>
      </main>

      {/* Bottom Navigation */}
      <FarmerBottomNav currentPage="profile" />
    </div>
  );
}
