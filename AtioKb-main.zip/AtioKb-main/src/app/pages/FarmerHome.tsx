import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, BookmarkIcon, UserCircle } from "lucide-react";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";

export function FarmerHome() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    { 
      id: "crops", 
      label: "Crops", 
      emoji: "🌾",
      description: "Seeds, planting, growing",
      keywords: ["crop", "seed", "planting", "growing", "harvest", "yield"]
    },
    { 
      id: "livestock", 
      label: "Livestock", 
      emoji: "🐄",
      description: "Animals, feed, health",
      keywords: ["livestock", "animal", "cattle", "poultry", "feed", "health"]
    },
    { 
      id: "water", 
      label: "Water", 
      emoji: "💧",
      description: "Irrigation, storage, wells",
      keywords: ["water", "irrigation", "drought", "wells", "storage"]
    },
    { 
      id: "postharvest", 
      label: "Post-harvest", 
      emoji: "📦",
      description: "Storage, drying, processing",
      keywords: ["storage", "drying", "processing", "post-harvest", "preservation"]
    },
    { 
      id: "climate", 
      label: "Climate", 
      emoji: "⛈️",
      description: "Weather, drought, resilience",
      keywords: ["climate", "weather", "drought", "resilience", "adaptation"]
    },
    { 
      id: "market", 
      label: "Selling", 
      emoji: "💰",
      description: "Markets, prices, buyers",
      keywords: ["market", "selling", "price", "buyer", "income"]
    },
  ];

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/farmer/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleCategoryClick = (category: typeof categories[0]) => {
    navigate(`/farmer/search?category=${category.id}&q=${category.keywords[0]}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-white to-green-50 pb-20">
      {/* Progress Indicator */}
      <div className="bg-white border-b border-slate-200 px-4 py-2">
        <div className="max-w-2xl mx-auto flex items-center gap-2 text-xs text-slate-600">
          <span className="font-medium text-green-600">Step 1 of 3:</span>
          <span>Describe your need</span>
        </div>
      </div>

      {/* Header */}
      <header className="bg-gradient-to-r from-green-600 to-green-700 text-white px-4 pt-6 pb-8 rounded-b-3xl shadow-lg">
        <div className="max-w-2xl mx-auto">
          {/* Clear Guidance */}
          <div className="mb-4 text-center">
            <p className="text-sm text-green-100 mb-1">👋 Welcome, Farmer!</p>
            <h1 className="text-xl font-bold">What challenge can we help you solve?</h1>
          </div>

          <div className="flex items-center justify-between mb-6">
            <button
              onClick={() => navigate("/")}
              className="text-sm text-green-100 hover:text-white flex items-center gap-1"
            >
              ← Change role
            </button>
            <button
              onClick={() => navigate("/farmer/profile")}
              className="p-2 rounded-full bg-white/20 active:bg-white/30 touch-manipulation"
            >
              <UserCircle className="size-7 text-white" />
            </button>
          </div>

          {/* Main Search Bar - PRIMARY CTA */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
            <Input
              placeholder="Type your farming challenge here..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full pl-12 pr-4 h-14 text-base bg-white text-slate-900 border-0 shadow-lg rounded-xl placeholder:text-slate-400"
            />
          </div>
          
          <Button
            onClick={handleSearch}
            disabled={!searchQuery.trim()}
            className="w-full mt-3 h-12 bg-white text-green-700 hover:bg-green-50 font-semibold shadow-md touch-manipulation disabled:opacity-50"
          >
            Search Solutions →
          </Button>
        </div>
      </header>

      {/* Categories Section */}
      <main className="px-4 py-6 max-w-2xl mx-auto">
        <h2 className="text-base font-semibold text-slate-700 mb-1">
          Or choose a topic:
        </h2>
        <p className="text-sm text-slate-500 mb-4">
          Browse solutions by category
        </p>
        
        <div className="grid grid-cols-2 gap-3">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => handleCategoryClick(category)}
              className="bg-white rounded-2xl p-5 shadow-sm border-2 border-slate-100 hover:border-green-300 hover:shadow-md transition-all active:scale-95 text-left touch-manipulation min-h-[120px] flex flex-col"
            >
              <div className="text-4xl mb-3">{category.emoji}</div>
              <div className="font-semibold text-base text-slate-900 mb-1">
                {category.label}
              </div>
              <div className="text-xs text-slate-600 leading-relaxed">
                {category.description}
              </div>
            </button>
          ))}
        </div>

        {/* Quick Tips Section */}
        <div className="mt-8 bg-blue-50 rounded-2xl p-5 border border-blue-200">
          <div className="flex items-start gap-3">
            <div className="text-2xl">💡</div>
            <div>
              <h3 className="font-semibold text-blue-900 mb-2 text-base">
                How to use this app
              </h3>
              <ul className="text-sm text-blue-800 space-y-1.5 leading-relaxed">
                <li>• Search for what you need help with</li>
                <li>• Browse solutions other farmers use</li>
                <li>• Save ideas to try later</li>
                <li>• Share with your farmer group</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Recently Added - Optional */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-slate-900">
              Recently added
            </h2>
            <button
              onClick={() => navigate("/farmer/search")}
              className="text-sm font-medium text-green-700 active:text-green-800"
            >
              See all
            </button>
          </div>
          
          <div className="space-y-3">
            <QuickInnovationCard
              title="Solar water pump for irrigation"
              description="Use sun power to water your crops"
              badge="Growing"
              countries={5}
              onClick={() => navigate("/innovation/atio-001?role=farmer")}
            />
            <QuickInnovationCard
              title="Community seed bank"
              description="Save and share traditional seeds"
              badge="Common"
              countries={6}
              onClick={() => navigate("/innovation/atio-002?role=farmer")}
            />
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <FarmerBottomNav currentPage="home" />
    </div>
  );
}

// Quick Innovation Card Component
interface QuickInnovationCardProps {
  title: string;
  description: string;
  badge: string;
  countries: number;
  onClick: () => void;
}

function QuickInnovationCard({ title, description, badge, countries, onClick }: QuickInnovationCardProps) {
  return (
    <button
      onClick={onClick}
      className="w-full bg-white rounded-xl p-4 shadow-sm border border-slate-200 hover:shadow-md transition-shadow active:scale-98 text-left touch-manipulation"
    >
      <h3 className="font-semibold text-base text-slate-900 mb-1.5">
        {title}
      </h3>
      <p className="text-sm text-slate-600 mb-3 leading-relaxed">
        {description}
      </p>
      <div className="flex items-center gap-3">
        <span className="text-xs bg-green-100 text-green-800 px-2.5 py-1 rounded-full font-medium">
          {badge}
        </span>
        <span className="text-xs text-slate-500">
          Used in {countries} countries
        </span>
      </div>
    </button>
  );
}

// Farmer Bottom Navigation Component
interface FarmerBottomNavProps {
  currentPage: "home" | "search" | "saved" | "profile";
}

export function FarmerBottomNav({ currentPage }: FarmerBottomNavProps) {
  const navigate = useNavigate();

  const navItems = [
    { id: "home", label: "Home", icon: "🏠", path: "/farmer" },
    { id: "search", label: "Search", icon: "🔍", path: "/farmer/search" },
    { id: "saved", label: "Saved", icon: "❤️", path: "/farmer/saved" },
    { id: "profile", label: "Profile", icon: "👤", path: "/farmer/profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-40 safe-area-bottom shadow-lg">
      <div className="grid grid-cols-4 max-w-2xl mx-auto">
        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center py-3 gap-1 transition-colors touch-manipulation min-h-[64px] ${
                isActive 
                  ? "text-green-700 bg-green-50" 
                  : "text-slate-600 active:bg-slate-50"
              }`}
            >
              <span className="text-2xl">{item.icon}</span>
              <span className={`text-xs font-medium ${isActive ? "font-semibold" : ""}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}