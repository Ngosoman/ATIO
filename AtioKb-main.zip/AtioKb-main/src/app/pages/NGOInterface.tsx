import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Search, MapPin, Heart, Users2, Share2, FileText } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import { mockTechnologies, SDG_NAMES } from "../data/mockTechnologies";

export function NGOInterface() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSDGs, setSelectedSDGs] = useState<number[]>([]);

  const filteredTechnologies = mockTechnologies.filter((tech) => {
    const matchesSearch = searchQuery === "" || 
      tech.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.summary.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSDG = selectedSDGs.length === 0 || 
      tech.sdgs.some(s => selectedSDGs.includes(s));

    return matchesSearch && matchesSDG;
  });

  const toggleSDG = (sdg: number) => {
    if (selectedSDGs.includes(sdg)) {
      setSelectedSDGs(selectedSDGs.filter(s => s !== sdg));
    } else {
      setSelectedSDGs([...selectedSDGs, sdg]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-green-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
                <ArrowLeft className="size-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-xl font-bold text-slate-900">NGO & Development Dashboard</h1>
                <p className="text-sm text-slate-600">SDG-aligned innovations for inclusive development</p>
              </div>
            </div>
            <Button onClick={() => navigate("/contribute")}>
              <Share2 className="size-4 mr-2" />
              Share Your Case Study
            </Button>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
            <Input
              placeholder="Search for SDG-aligned innovations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </header>

      <div className="flex">
        {/* SDG Filter Sidebar */}
        <aside className="w-80 bg-white border-r border-slate-200 p-6">
          <h3 className="font-semibold text-sm text-slate-900 mb-4">Filter by SDG</h3>
          <div className="space-y-3">
            {Object.entries(SDG_NAMES).map(([sdg, name]) => (
              <div key={sdg} className="flex items-start">
                <Checkbox
                  id={`sdg-${sdg}`}
                  checked={selectedSDGs.includes(Number(sdg))}
                  onCheckedChange={() => toggleSDG(Number(sdg))}
                  className="mt-1"
                />
                <Label
                  htmlFor={`sdg-${sdg}`}
                  className="ml-3 cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <div className="size-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                      {sdg}
                    </div>
                    <span className="text-sm">{name}</span>
                  </div>
                </Label>
              </div>
            ))}
          </div>
        </aside>

        <main className="flex-1 p-6 max-w-6xl">
          <div className="mb-4">
            <p className="text-sm text-slate-600">{filteredTechnologies.length} innovations found</p>
          </div>

          <div className="space-y-4">
            {filteredTechnologies.map((tech) => (
              <Card key={tech.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex gap-6">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-lg text-slate-900 mb-1">{tech.title}</h3>
                        <div className="flex items-center gap-2 text-sm text-slate-600">
                          <MapPin className="size-4" />
                          {tech.region.join(", ")}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {tech.sdgs.slice(0, 3).map((sdg) => (
                          <div
                            key={sdg}
                            className="size-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-sm"
                            title={`SDG ${sdg}: ${SDG_NAMES[sdg]}`}
                          >
                            {sdg}
                          </div>
                        ))}
                      </div>
                    </div>

                    <p className="text-sm text-slate-700 mb-4">{tech.summary}</p>

                    {/* Impact on Communities */}
                    <div className="grid grid-cols-3 gap-4 mb-4 p-4 bg-teal-50 rounded-lg">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Heart className="size-4 text-teal-700" />
                          <span className="text-xs text-teal-700">Resilience</span>
                        </div>
                        <p className="text-xl font-bold text-teal-900">+{tech.impact.resilience}%</p>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Users2 className="size-4 text-green-700" />
                          <span className="text-xs text-green-700">Nutrition</span>
                        </div>
                        <p className="text-xl font-bold text-green-900">+{tech.impact.nutrition}%</p>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <MapPin className="size-4 text-blue-700" />
                          <span className="text-xs text-blue-700">Countries</span>
                        </div>
                        <p className="text-xl font-bold text-blue-900">{tech.countries.length}</p>
                      </div>
                    </div>

                    {/* Equity Tags */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {tech.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="bg-white">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    {/* Partner Organizations */}
                    <div className="mb-4 pb-4 border-t border-slate-200 pt-4">
                      <p className="text-xs font-semibold text-slate-600 mb-2">Implementation Partners:</p>
                      <div className="flex flex-wrap gap-2">
                        {tech.partnerOrganizations.map((partner, idx) => (
                          <Badge key={idx} variant="secondary">
                            {partner}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => navigate(`/technology/${tech.id}?role=ngo`)}
                      >
                        <FileText className="size-4 mr-2" />
                        View Implementation Cases
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share2 className="size-4 mr-2" />
                        Share Experience
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
