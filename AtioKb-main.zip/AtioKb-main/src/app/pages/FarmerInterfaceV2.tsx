import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, MapPin, Lightbulb, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { 
  atioInnovations, 
  VALUE_CHAIN_STAGES,
  getAdoptionBadgeColor
} from "../data/atioInnovations";
import { InnovationCard } from "../components/InnovationCard";
import { MobileHeader } from "../components/MobileNav";

export function FarmerInterfaceV2() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  // Simple filtering for farmers
  const filteredInnovations = atioInnovations.filter((innovation) => {
    const matchesSearch = searchQuery === "" || 
      innovation.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (innovation.farmer_friendly_description || innovation.short_description).toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.use_cases.some(uc => uc.toLowerCase().includes(searchQuery.toLowerCase())) ||
      innovation.challenges_addressed.some(ca => ca.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStage = !selectedStage || innovation.food_value_chain_stage.includes(selectedStage);

    return matchesSearch && matchesStage;
  });

  // Group challenges for quick access
  const commonChallenges = [
    { label: "Water problems", icon: "💧", keywords: ["water", "irrigation", "drought"] },
    { label: "Low harvest", icon: "🌾", keywords: ["yield", "productivity", "harvest"] },
    { label: "Selling crops", icon: "💰", keywords: ["market", "price", "selling"] },
    { label: "Weather", icon: "⛈️", keywords: ["climate", "weather", "resilience"] },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white pb-20">
      {/* Mobile Header */}
      <MobileHeader
        title="Find Solutions"
        onBack={() => navigate("/")}
      />

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-green-600 to-green-700 text-white px-4 py-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-2xl md:text-3xl font-bold mb-3">
            Find Farming Solutions That Work
          </h1>
          <p className="text-green-50 text-sm md:text-base mb-6">
            Practical innovations used by farmers like you across Africa
          </p>

          {/* Main Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-green-600" />
            <Input
              placeholder="Describe your farming challenge..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-14 text-base bg-white text-slate-900 border-0 shadow-lg rounded-xl"
            />
          </div>
        </div>
      </div>

      {/* Quick Challenge Buttons */}
      <div className="px-4 py-6 -mt-4">
        <div className="max-w-3xl mx-auto">
          <p className="text-xs font-semibold text-slate-600 mb-3 uppercase tracking-wide">
            Common challenges
          </p>
          <div className="grid grid-cols-2 gap-3">
            {commonChallenges.map((challenge) => (
              <button
                key={challenge.label}
                onClick={() => setSearchQuery(challenge.keywords[0])}
                className="bg-white rounded-xl p-4 shadow-sm border border-slate-200 hover:shadow-md transition-shadow text-left active:scale-95"
              >
                <div className="text-2xl mb-2">{challenge.icon}</div>
                <div className="font-medium text-sm text-slate-900">{challenge.label}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Simple Filters */}
      <div className="px-4 pb-4">
        <div className="max-w-3xl mx-auto">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="w-full flex items-center justify-between px-4 py-3 bg-white rounded-lg border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            <span>Filter by farming stage</span>
            {showFilters ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
          </button>

          {showFilters && (
            <div className="mt-3 bg-white rounded-lg border border-slate-200 p-4">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setSelectedStage(null)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    selectedStage === null 
                      ? "bg-green-600 text-white" 
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  All stages
                </button>
                {VALUE_CHAIN_STAGES.map((stage) => (
                  <button
                    key={stage}
                    onClick={() => setSelectedStage(stage === selectedStage ? null : stage)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedStage === stage 
                        ? "bg-green-600 text-white" 
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {stage}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Results */}
      <div className="px-4 pb-6">
        <div className="max-w-3xl mx-auto">
          <p className="text-sm text-slate-600 mb-4">
            {filteredInnovations.length} solutions found
          </p>

          <div className="space-y-4">
            {filteredInnovations.map((innovation) => (
              <InnovationCard
                key={innovation.id}
                innovation={innovation}
                variant="farmer"
                onClick={() => navigate(`/innovation/${innovation.id}?role=farmer`)}
              />
            ))}

            {filteredInnovations.length === 0 && (
              <div className="text-center py-12 bg-white rounded-xl">
                <div className="text-4xl mb-3">🔍</div>
                <p className="text-slate-600 mb-4">No solutions found for "{searchQuery}"</p>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedStage(null);
                  }}
                >
                  Clear search
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Help Section */}
      <div className="px-4 pb-8">
        <div className="max-w-3xl mx-auto bg-blue-50 rounded-xl p-6 border border-blue-200">
          <div className="flex items-start gap-3">
            <Lightbulb className="size-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Need help choosing?</h3>
              <p className="text-sm text-blue-800 mb-3">
                Contact your local extension officer or farmer group leader. They can help you decide which solution works best for your farm.
              </p>
              <Button size="sm" variant="outline" className="bg-white">
                Find local support
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
