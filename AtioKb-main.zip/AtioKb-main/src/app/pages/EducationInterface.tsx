import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Search, GraduationCap, BookOpen, Play, Download, Sparkles } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { mockTechnologies, SDG_NAMES } from "../data/mockTechnologies";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const techImages: Record<string, string> = {
  "1": "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400",
  "2": "https://images.unsplash.com/photo-1710090720809-527cefdac598?w=400",
  "3": "https://images.unsplash.com/photo-1761666519224-5f81305cf170?w=400",
  "4": "https://images.unsplash.com/photo-1655102713930-ed68081e6b7d?w=400",
  "5": "https://images.unsplash.com/photo-1608061609218-0f39494d6d7a?w=400",
  "6": "https://images.unsplash.com/photo-1644845664240-bd0813b50cb5?w=400",
};

export function EducationInterface() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"explore" | "learn">("explore");

  const filteredTechnologies = mockTechnologies.filter((tech) => {
    const matchesSearch = searchQuery === "" || 
      tech.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.summary.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
                <ArrowLeft className="size-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-3">
                <div className="size-10 bg-gradient-to-br from-pink-500 to-purple-500 rounded-lg flex items-center justify-center">
                  <GraduationCap className="size-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900">Youth & Education Portal</h1>
                  <p className="text-sm text-slate-600">Learn about agricultural innovations</p>
                </div>
              </div>
            </div>
            <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "explore" | "learn")}>
              <TabsList>
                <TabsTrigger value="explore">Explore Innovations</TabsTrigger>
                <TabsTrigger value="learn">Learning Resources</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {viewMode === "explore" && (
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="What would you like to learn about?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {viewMode === "explore" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTechnologies.map((tech) => (
              <Card key={tech.id} className="overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 cursor-pointer"
                onClick={() => navigate(`/technology/${tech.id}?role=education`)}>
                <div className="relative h-48 bg-gradient-to-br from-slate-200 to-slate-300">
                  <ImageWithFallback
                    src={techImages[tech.id] || "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400"}
                    alt={tech.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-white/90 text-slate-900 backdrop-blur-sm">
                      <Sparkles className="size-3 mr-1" />
                      Inspiring
                    </Badge>
                  </div>
                </div>

                <div className="p-5">
                  <h3 className="font-bold text-lg text-slate-900 mb-2">{tech.title}</h3>
                  <p className="text-sm text-slate-700 mb-4 leading-relaxed">{tech.summary}</p>

                  {/* SDG Badges */}
                  <div className="flex gap-2 mb-4">
                    {tech.sdgs.slice(0, 3).map((sdg) => (
                      <div
                        key={sdg}
                        className="size-8 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-full flex items-center justify-center font-bold text-xs"
                        title={`SDG ${sdg}: ${SDG_NAMES[sdg]}`}
                      >
                        {sdg}
                      </div>
                    ))}
                  </div>

                  {/* Why It Matters */}
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 mb-4">
                    <p className="text-xs font-semibold text-purple-900 mb-1">Why it matters:</p>
                    <p className="text-sm text-purple-800">
                      Helps farmers increase food production and adapt to climate change
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1">
                      <BookOpen className="size-4 mr-1" />
                      Learn More
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="size-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          /* Learning Resources */
          <div className="space-y-6">
            <Card className="p-6 bg-gradient-to-r from-pink-100 to-purple-100 border-pink-200">
              <div className="flex items-start gap-4">
                <div className="size-16 bg-white rounded-lg flex items-center justify-center flex-shrink-0">
                  <Play className="size-8 text-pink-600" />
                </div>
                <div>
                  <h3 className="font-bold text-xl text-slate-900 mb-2">Introduction to Agrifood Innovations</h3>
                  <p className="text-slate-700 mb-4">
                    A beginner-friendly video series explaining how technology is transforming agriculture in Africa.
                  </p>
                  <div className="flex gap-2">
                    <Badge variant="secondary">Video Course</Badge>
                    <Badge variant="secondary">Beginner</Badge>
                    <Badge variant="secondary">45 minutes</Badge>
                  </div>
                </div>
              </div>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="size-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <BookOpen className="size-6 text-green-700" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-slate-900">Student Guides</h3>
                    <p className="text-sm text-slate-600">Downloadable PDFs</p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="size-2 rounded-full bg-green-500" />
                    Climate-Smart Agriculture Basics
                  </li>
                  <li className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="size-2 rounded-full bg-green-500" />
                    Soil Health and Testing
                  </li>
                  <li className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="size-2 rounded-full bg-green-500" />
                    Water Conservation Techniques
                  </li>
                </ul>
                <Button className="w-full mt-4" variant="outline">
                  <Download className="size-4 mr-2" />
                  Download All Guides
                </Button>
              </Card>

              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="size-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <GraduationCap className="size-6 text-blue-700" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-slate-900">Classroom Activities</h3>
                    <p className="text-sm text-slate-600">Hands-on experiments</p>
                  </div>
                </div>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="size-2 rounded-full bg-blue-500" />
                    Build a Mini Drip Irrigation System
                  </li>
                  <li className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="size-2 rounded-full bg-blue-500" />
                    Soil Testing Lab Activity
                  </li>
                  <li className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="size-2 rounded-full bg-blue-500" />
                    School Garden Setup Guide
                  </li>
                </ul>
                <Button className="w-full mt-4" variant="outline">
                  View All Activities
                </Button>
              </Card>
            </div>

            <Card className="p-6 bg-amber-50 border-amber-200">
              <h3 className="font-semibold text-lg text-slate-900 mb-3">Quiz: Test Your Knowledge</h3>
              <p className="text-slate-700 mb-4">
                Take our interactive quiz to see how much you've learned about agrifood innovations!
              </p>
              <Button>Start Quiz</Button>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
