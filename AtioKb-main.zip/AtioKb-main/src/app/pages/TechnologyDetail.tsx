import { useParams, useNavigate, useSearchParams } from "react-router";
import { 
  ArrowLeft, 
  Download, 
  BookOpen, 
  MapPin, 
  TrendingUp,
  Users,
  DollarSign,
  CheckCircle2,
  FileText,
  ExternalLink,
  Share2,
  AlertCircle,
  Lightbulb
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Separator } from "../components/ui/separator";
import { mockTechnologies, SDG_NAMES } from "../data/mockTechnologies";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const techImages: Record<string, string> = {
  "1": "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800",
  "2": "https://images.unsplash.com/photo-1710090720809-527cefdac598?w=800",
  "3": "https://images.unsplash.com/photo-1761666519224-5f81305cf170?w=800",
  "4": "https://images.unsplash.com/photo-1655102713930-ed68081e6b7d?w=800",
  "5": "https://images.unsplash.com/photo-1608061609218-0f39494d6d7a?w=800",
  "6": "https://images.unsplash.com/photo-1644845664240-bd0813b50cb5?w=800",
};

export function TechnologyDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const role = searchParams.get("role") || "policy";

  const tech = mockTechnologies.find(t => t.id === id);

  if (!tech) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Technology Not Found</h2>
          <p className="text-slate-600 mb-4">The requested innovation could not be found.</p>
          <Button onClick={() => navigate("/")}>Go Back Home</Button>
        </div>
      </div>
    );
  }

  const getRoleBackPath = () => {
    switch (role) {
      case "farmer": return "/farmer";
      case "researcher": return "/researcher";
      case "policy": return "/policy-maker";
      default: return "/";
    }
  };

  const getRoleSpecificTabs = () => {
    if (role === "farmer") {
      return (
        <Tabs defaultValue="guide" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="guide">Step-by-Step</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="tips">Farmer Tips</TabsTrigger>
            <TabsTrigger value="context">Will it work here?</TabsTrigger>
          </TabsList>

          <TabsContent value="guide" className="mt-6">
            <h3 className="font-semibold text-lg text-slate-900 mb-4">How to Implement</h3>
            <div className="space-y-4">
              {tech.implementationSteps.map((step, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="flex-shrink-0 size-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold">
                    {idx + 1}
                  </div>
                  <div className="flex-1 pt-1">
                    <p className="text-base text-slate-800">{step}</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="materials" className="mt-6">
            <h3 className="font-semibold text-lg text-slate-900 mb-4">What You Need</h3>
            <div className="space-y-3">
              {tech.materials.map((material, idx) => (
                <Card key={idx} className="p-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="size-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <p className="text-base text-slate-800">{material}</p>
                  </div>
                </Card>
              ))}
            </div>
            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Lightbulb className="size-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-900 mb-1">Local Alternatives</p>
                  <p className="text-sm text-blue-800">
                    Many materials shown have local alternatives listed. Ask your extension officer or farmer group about what's available in your area.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tips" className="mt-6">
            <h3 className="font-semibold text-lg text-slate-900 mb-4">What Other Farmers Say</h3>
            <div className="space-y-4">
              {tech.farmerTips.map((tip, idx) => (
                <Card key={idx} className="p-5 bg-amber-50 border-amber-200">
                  <div className="flex items-start gap-3">
                    <Users className="size-5 text-amber-700 mt-0.5 flex-shrink-0" />
                    <p className="text-base text-amber-900 italic">"{tip}"</p>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="w-full mt-6" variant="outline">
              <Share2 className="size-4 mr-2" />
              Share Your Experience
            </Button>
          </TabsContent>

          <TabsContent value="context" className="mt-6">
            <h3 className="font-semibold text-lg text-slate-900 mb-4">Where Does This Work?</h3>
            <div className="space-y-4">
              <Card className="p-5">
                <h4 className="font-semibold text-slate-900 mb-2">Countries Using This</h4>
                <div className="flex flex-wrap gap-2">
                  {tech.countries.map((country) => (
                    <Badge key={country} variant="outline" className="text-sm">
                      <MapPin className="size-3 mr-1" />
                      {country}
                    </Badge>
                  ))}
                </div>
              </Card>

              {tech.contextualConstraints.length > 0 && (
                <Card className="p-5 bg-orange-50 border-orange-200">
                  <h4 className="font-semibold text-orange-900 mb-3">Things to Consider</h4>
                  <div className="space-y-2">
                    {tech.contextualConstraints.map((constraint, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <AlertCircle className="size-4 text-orange-700 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-orange-900">{constraint}</p>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      );
    }

    if (role === "researcher") {
      return (
        <Tabs defaultValue="evidence" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="evidence">Evidence & Studies</TabsTrigger>
            <TabsTrigger value="scalability">Scalability</TabsTrigger>
            <TabsTrigger value="gaps">Research Gaps</TabsTrigger>
            <TabsTrigger value="data">Technical Data</TabsTrigger>
          </TabsList>

          <TabsContent value="evidence" className="mt-6">
            <div className="space-y-4">
              <Card className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <Badge className={
                    tech.evidenceStrength === "high" 
                      ? "bg-green-100 text-green-800 text-sm" 
                      : tech.evidenceStrength === "medium"
                      ? "bg-yellow-100 text-yellow-800 text-sm"
                      : "bg-orange-100 text-orange-800 text-sm"
                  }>
                    {tech.evidenceStrength.toUpperCase()} Evidence Strength
                  </Badge>
                  <span className="text-sm text-slate-600">
                    {tech.evidenceLinks.length} studies and reports
                  </span>
                </div>
                <Separator className="my-4" />
                <div className="space-y-3">
                  {tech.evidenceLinks.map((link, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer">
                      <FileText className="size-5 text-slate-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-900">{link}</p>
                      </div>
                      <ExternalLink className="size-4 text-slate-400 flex-shrink-0" />
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-5">
                <h4 className="font-semibold text-slate-900 mb-3">Impact Evidence</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-green-700 mb-1">Productivity Gain</p>
                    <p className="text-2xl font-bold text-green-900">+{tech.impact.productivity}%</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-blue-700 mb-1">Resilience Improvement</p>
                    <p className="text-2xl font-bold text-blue-900">+{tech.impact.resilience}%</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <p className="text-sm text-orange-700 mb-1">Nutrition Impact</p>
                    <p className="text-2xl font-bold text-orange-900">+{tech.impact.nutrition}%</p>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="scalability" className="mt-6">
            <Card className="p-5">
              <h4 className="font-semibold text-slate-900 mb-3">Scalability Assessment</h4>
              <p className="text-slate-700 mb-6">{tech.scalabilityNotes}</p>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-sm font-semibold text-slate-600 mb-2">Deployment Status</p>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-slate-600">Countries</span>
                      <span className="font-semibold text-slate-900">{tech.countries.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-slate-600">Adoption Level</span>
                      <Badge className="capitalize">{tech.adoptionLevel}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-slate-600">Readiness (TRL)</span>
                      <span className="font-semibold text-slate-900">{tech.readinessLevel}/9</span>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-semibold text-slate-600 mb-2">Resource Requirements</p>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-slate-600">Cost Level</span>
                      <Badge className="capitalize">{tech.costLevel}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-slate-600">Labour Intensity</span>
                      <Badge className="capitalize">{tech.labourIntensity}</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {tech.partnerOrganizations.length > 0 && (
              <Card className="p-5 mt-4">
                <h4 className="font-semibold text-slate-900 mb-3">Implementation Partners</h4>
                <div className="flex flex-wrap gap-2">
                  {tech.partnerOrganizations.map((partner, idx) => (
                    <Badge key={idx} variant="secondary">
                      {partner}
                    </Badge>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="gaps" className="mt-6">
            <Card className="p-5">
              <h4 className="font-semibold text-slate-900 mb-4">Identified Research Gaps</h4>
              {tech.researchGaps.length > 0 ? (
                <div className="space-y-3">
                  {tech.researchGaps.map((gap, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <AlertCircle className="size-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-slate-900">{gap}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-600 italic">No specific research gaps have been identified for this innovation.</p>
              )}
            </Card>

            <Card className="p-5 mt-4">
              <h4 className="font-semibold text-slate-900 mb-4">Contextual Constraints</h4>
              {tech.contextualConstraints.length > 0 ? (
                <div className="space-y-2">
                  {tech.contextualConstraints.map((constraint, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <div className="size-2 rounded-full bg-slate-400 mt-2 flex-shrink-0" />
                      <p className="text-slate-700">{constraint}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-600 italic">No contextual constraints documented.</p>
              )}
            </Card>

            <div className="mt-6">
              <Button className="w-full">
                <Download className="size-4 mr-2" />
                Export Research Concept Note
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="data" className="mt-6">
            <div className="space-y-4">
              <Card className="p-5">
                <h4 className="font-semibold text-slate-900 mb-4">Technical Specifications</h4>
                <dl className="space-y-3">
                  <div className="flex justify-between border-b border-slate-200 pb-2">
                    <dt className="text-sm text-slate-600">Innovation Type</dt>
                    <dd className="text-sm font-semibold text-slate-900">{tech.innovationType}</dd>
                  </div>
                  <div className="flex justify-between border-b border-slate-200 pb-2">
                    <dt className="text-sm text-slate-600">Primary Domain</dt>
                    <dd className="text-sm font-semibold text-slate-900">{tech.domain}</dd>
                  </div>
                  <div className="flex justify-between border-b border-slate-200 pb-2">
                    <dt className="text-sm text-slate-600">Technology Readiness Level</dt>
                    <dd className="text-sm font-semibold text-slate-900">{tech.readinessLevel}/9</dd>
                  </div>
                  <div className="flex justify-between border-b border-slate-200 pb-2">
                    <dt className="text-sm text-slate-600">Target Users</dt>
                    <dd className="text-sm font-semibold text-slate-900">{tech.targetUsers.join(", ")}</dd>
                  </div>
                </dl>
              </Card>

              <Card className="p-5">
                <h4 className="font-semibold text-slate-900 mb-4">Geographic Coverage</h4>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-slate-600 mb-2">Regions</p>
                    <div className="flex flex-wrap gap-2">
                      {tech.region.map((region) => (
                        <Badge key={region} variant="outline">{region}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-2">Countries</p>
                    <div className="flex flex-wrap gap-2">
                      {tech.countries.map((country) => (
                        <Badge key={country} variant="secondary">{country}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      );
    }

    // Policy maker view
    return (
      <Tabs defaultValue="impact" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="impact">Impact & Evidence</TabsTrigger>
          <TabsTrigger value="policy">Policy Considerations</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
          <TabsTrigger value="equity">Equity & Gender</TabsTrigger>
        </TabsList>

        <TabsContent value="impact" className="mt-6">
          <div className="grid grid-cols-3 gap-4 mb-6">
            <Card className="p-5 bg-gradient-to-br from-green-50 to-green-100">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="size-6 text-green-700" />
                <h4 className="font-semibold text-green-900">Productivity</h4>
              </div>
              <p className="text-3xl font-bold text-green-900">+{tech.impact.productivity}%</p>
              <p className="text-sm text-green-700 mt-1">Average yield increase</p>
            </Card>

            <Card className="p-5 bg-gradient-to-br from-blue-50 to-blue-100">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="size-6 text-blue-700" />
                <h4 className="font-semibold text-blue-900">Resilience</h4>
              </div>
              <p className="text-3xl font-bold text-blue-900">+{tech.impact.resilience}%</p>
              <p className="text-sm text-blue-700 mt-1">Climate adaptation</p>
            </Card>

            <Card className="p-5 bg-gradient-to-br from-orange-50 to-orange-100">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="size-6 text-orange-700" />
                <h4 className="font-semibold text-orange-900">Nutrition</h4>
              </div>
              <p className="text-3xl font-bold text-orange-900">+{tech.impact.nutrition}%</p>
              <p className="text-sm text-orange-700 mt-1">Food security impact</p>
            </Card>
          </div>

          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-slate-900">Evidence Base</h4>
              <Badge className={
                tech.evidenceStrength === "high" 
                  ? "bg-green-100 text-green-800" 
                  : tech.evidenceStrength === "medium"
                  ? "bg-yellow-100 text-yellow-800"
                  : "bg-orange-100 text-orange-800"
              }>
                {tech.evidenceStrength.toUpperCase()} Evidence
              </Badge>
            </div>
            <div className="space-y-2">
              {tech.evidenceLinks.map((link, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm text-slate-700">
                  <FileText className="size-4 text-slate-400" />
                  <span>{link}</span>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="policy" className="mt-6">
          <Card className="p-5 mb-4">
            <h4 className="font-semibold text-slate-900 mb-3">SDG Alignment</h4>
            <div className="flex flex-wrap gap-3">
              {tech.sdgs.map((sdg) => (
                <div key={sdg} className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2">
                  <div className="size-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                    {sdg}
                  </div>
                  <span className="text-sm font-medium text-slate-900">{SDG_NAMES[sdg]}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <h4 className="font-semibold text-slate-900 mb-3">Scalability & Adoption</h4>
            <p className="text-slate-700 mb-4">{tech.scalabilityNotes}</p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-600 mb-1">Current Adoption</p>
                <p className="text-lg font-semibold text-slate-900 capitalize">{tech.adoptionLevel}</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm text-slate-600 mb-1">Geographic Spread</p>
                <p className="text-lg font-semibold text-slate-900">{tech.countries.length} Countries</p>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="implementation" className="mt-6">
          <Card className="p-5 mb-4">
            <h4 className="font-semibold text-slate-900 mb-3">Implementation Partners</h4>
            <div className="flex flex-wrap gap-2">
              {tech.partnerOrganizations.map((partner, idx) => (
                <Badge key={idx} variant="secondary" className="text-sm">
                  {partner}
                </Badge>
              ))}
            </div>
          </Card>

          <Card className="p-5 mb-4">
            <h4 className="font-semibold text-slate-900 mb-3">Resource Requirements</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-600 mb-1">Investment Level</p>
                <Badge className="capitalize">{tech.costLevel} Cost</Badge>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Labour Requirements</p>
                <Badge className="capitalize">{tech.labourIntensity} Labour</Badge>
              </div>
            </div>
          </Card>

          {tech.contextualConstraints.length > 0 && (
            <Card className="p-5 bg-amber-50 border-amber-200">
              <h4 className="font-semibold text-amber-900 mb-3">Implementation Considerations</h4>
              <ul className="space-y-2">
                {tech.contextualConstraints.map((constraint, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-amber-900">
                    <span className="text-amber-600">•</span>
                    <span>{constraint}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="equity" className="mt-6">
          <Card className="p-5 mb-4">
            <h4 className="font-semibold text-slate-900 mb-3">Target Beneficiaries</h4>
            <div className="flex flex-wrap gap-2">
              {tech.targetUsers.map((user, idx) => (
                <Badge key={idx} variant="outline" className="text-sm">
                  {user}
                </Badge>
              ))}
            </div>
          </Card>

          <Card className="p-5 mb-4">
            <h4 className="font-semibold text-slate-900 mb-3">Inclusion Considerations</h4>
            <div className="space-y-3">
              {tech.tags.filter(tag => 
                tag.toLowerCase().includes("women") || 
                tag.toLowerCase().includes("youth") ||
                tag.toLowerCase().includes("friendly")
              ).map((tag, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <CheckCircle2 className="size-5 text-green-600" />
                  <span className="text-slate-900">{tag}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5 bg-blue-50 border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2">Gender & Social Considerations</h4>
            <p className="text-sm text-blue-800">
              This innovation has been identified as accessible to diverse user groups. 
              For detailed gender and social impact analysis, please refer to the full research reports.
            </p>
          </Card>
        </TabsContent>
      </Tabs>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="ghost"
              onClick={() => navigate(getRoleBackPath())}
            >
              <ArrowLeft className="size-4 mr-2" />
              Back to {role === "farmer" ? "Solutions" : role === "researcher" ? "Workspace" : "Dashboard"}
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Share2 className="size-4 mr-2" />
                Share
              </Button>
              <Button size="sm">
                <Download className="size-4 mr-2" />
                {role === "policy" ? "Generate Brief" : role === "farmer" ? "Save Offline" : "Export Data"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Image */}
            <div className="relative h-80 bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg overflow-hidden">
              <ImageWithFallback
                src={techImages[tech.id] || "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800"}
                alt={tech.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Info */}
            <div>
              <div className="flex flex-wrap gap-2 mb-3">
                {tech.tags.slice(0, 3).map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
              
              <h1 className="text-3xl font-bold text-slate-900 mb-3">
                {tech.title}
              </h1>

              <p className="text-lg text-slate-700 mb-6">
                {tech.description}
              </p>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-3 bg-slate-50 rounded-lg p-3">
                  <MapPin className="size-5 text-blue-600" />
                  <div>
                    <p className="text-xs text-slate-600">Geographic Reach</p>
                    <p className="text-sm font-semibold text-slate-900">
                      {tech.countries.length} Countries
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-slate-50 rounded-lg p-3">
                  <DollarSign className="size-5 text-green-600" />
                  <div>
                    <p className="text-xs text-slate-600">Cost Level</p>
                    <p className="text-sm font-semibold text-slate-900 capitalize">
                      {tech.costLevel}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-slate-50 rounded-lg p-3">
                  <Users className="size-5 text-purple-600" />
                  <div>
                    <p className="text-xs text-slate-600">Adoption</p>
                    <p className="text-sm font-semibold text-slate-900 capitalize">
                      {tech.adoptionLevel}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-slate-50 rounded-lg p-3">
                  <BookOpen className="size-5 text-orange-600" />
                  <div>
                    <p className="text-xs text-slate-600">Evidence</p>
                    <p className="text-sm font-semibold text-slate-900 capitalize">
                      {tech.evidenceStrength}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        {getRoleSpecificTabs()}
      </main>
    </div>
  );
}
