import { useNavigate } from "react-router";
import { 
  Building2, 
  Sprout, 
  FlaskConical, 
  TrendingUp, 
  Users, 
  GraduationCap,
  Database,
  HandHeart 
} from "lucide-react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";

interface RoleCard {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  illustration: string;
  path: string;
  color: string;
  enabled: boolean;
}

export function RoleLanding() {
  const navigate = useNavigate();

  const roles: RoleCard[] = [
    {
      id: "policy",
      title: "Policy Makers",
      description: "Compare innovations and create evidence-based policy briefs",
      icon: <Building2 className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1640200330428-9fe2ab926de1?w=400&h=300&fit=crop",
      path: "/policy-maker",
      color: "from-blue-500 to-blue-600",
      enabled: true,
    },
    {
      id: "farmer",
      title: "Farmers",
      description: "Find practical solutions for your farm with step-by-step guides",
      icon: <Sprout className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1666987570506-f8c3e05b6c58?w=400&h=300&fit=crop",
      path: "/farmer",
      color: "from-green-500 to-green-600",
      enabled: true,
    },
    {
      id: "researcher",
      title: "Researchers",
      description: "Identify research gaps and evaluate innovation scalability",
      icon: <FlaskConical className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1631556760646-50241850eb25?w=400&h=300&fit=crop",
      path: "/researcher",
      color: "from-purple-500 to-purple-600",
      enabled: true,
    },
    {
      id: "private",
      title: "Agripreneurs",
      description: "Scout innovations, assess market readiness, find partnerships",
      icon: <TrendingUp className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1661286178389-e067299f907e?w=400&h=300&fit=crop",
      path: "/agripreneur",
      color: "from-orange-500 to-orange-600",
      enabled: true,
    },
    {
      id: "ngo",
      title: "NGOs & Development",
      description: "Find SDG-aligned innovations and share field implementations",
      icon: <Users className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1560220604-1985ebfe28b1?w=400&h=300&fit=crop",
      path: "/ngo",
      color: "from-teal-500 to-teal-600",
      enabled: true,
    },
    {
      id: "education",
      title: "Youth & Education",
      description: "Access inspiring examples and training resources",
      icon: <GraduationCap className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1758612898304-1a6bb546ac44?w=400&h=300&fit=crop",
      path: "/education",
      color: "from-pink-500 to-pink-600",
      enabled: true,
    },
    {
      id: "grassroots",
      title: "Community Contributors",
      description: "Share your innovations and traditional knowledge",
      icon: <HandHeart className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1740630267005-db9af10c0164?w=400&h=300&fit=crop",
      path: "/contribute",
      color: "from-amber-500 to-amber-600",
      enabled: true,
    },
    {
      id: "data",
      title: "Data Providers",
      description: "Connect your database to the knowledge base",
      icon: <Database className="size-8" />,
      illustration: "https://images.unsplash.com/photo-1695668548342-c0c1ad479aee?w=400&h=300&fit=crop",
      path: "/data-provider",
      color: "from-indigo-500 to-indigo-600",
      enabled: true,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 pb-safe">
      {/* Header - Mobile Optimized */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-6">
          <div className="flex items-center gap-3">
            <div className="size-10 md:size-12 bg-gradient-to-br from-blue-600 to-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Sprout className="size-6 md:size-7 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-lg md:text-2xl font-bold text-slate-900 truncate">
                ATIO Knowledge Base
              </h1>
              <p className="text-xs md:text-sm text-slate-600 truncate">
                FAO Agrifood Technology & Innovation Outlook
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-12">
        {/* Introduction - Mobile Optimized */}
        <div className="text-center mb-8 md:mb-12 max-w-3xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-3 md:mb-4">
            Welcome to the ATIO Knowledge Base
          </h2>
          <p className="text-base md:text-lg text-slate-600 mb-2">
            A comprehensive platform for discovering, sharing, and implementing agrifood technologies and innovations across Sub-Saharan Africa.
          </p>
          <p className="text-sm md:text-base text-slate-500">
            Select your role below to access tailored content and tools designed for your specific needs.
          </p>
        </div>

        {/* Role Cards Grid - Mobile-First Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
          {roles.map((role) => (
            <Card
              key={role.id}
              className={`relative overflow-hidden transition-all duration-300 group ${
                role.enabled
                  ? "hover:shadow-xl hover:-translate-y-1 cursor-pointer"
                  : "opacity-60 cursor-not-allowed"
              }`}
              onClick={() => role.enabled && navigate(role.path)}
            >
              {/* Illustration Header */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={role.illustration}
                  alt={role.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                {/* Gradient Overlay for better text readability */}
                <div className={`absolute inset-0 bg-gradient-to-br ${role.color} opacity-60 mix-blend-multiply`} />
                {/* Icon Badge */}
                <div className="absolute bottom-4 left-4">
                  <div className="bg-white/95 backdrop-blur-sm rounded-full p-3 shadow-lg">
                    <div className={`bg-gradient-to-br ${role.color} rounded-full p-2.5`}>
                      <div className="text-white">
                        {role.icon}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="font-semibold text-lg text-slate-900 mb-2">
                  {role.title}
                </h3>
                <p className="text-sm text-slate-600 mb-4 min-h-[3rem]">
                  {role.description}
                </p>
                
                {role.enabled ? (
                  <Button 
                    className="w-full"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(role.path);
                    }}
                  >
                    Get Started
                  </Button>
                ) : (
                  <Button 
                    className="w-full"
                    disabled
                    variant="secondary"
                  >
                    Coming Soon
                  </Button>
                )}
              </div>

              {/* Enabled badge */}
              {role.enabled && (
                <div className="absolute top-3 right-3">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-white/95 backdrop-blur-sm text-slate-700 shadow-sm">
                    Active
                  </span>
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Info Section */}
        <div className="bg-white rounded-lg shadow-sm p-8 max-w-3xl mx-auto">
          <h3 className="font-semibold text-xl text-slate-900 mb-4">
            About the ATIO Knowledge Base
          </h3>
          <div className="space-y-3 text-slate-600">
            <p>
              The ATIO Knowledge Base is a federated platform that connects diverse sources of knowledge about agrifood technologies and innovations relevant to Sub-Saharan Africa.
            </p>
            <p>
              Our goal is to make evidence-based information accessible to everyone—from policy makers crafting national strategies to farmers seeking practical solutions.
            </p>
            <p className="text-sm text-slate-500 pt-4 border-t border-slate-200">
              This is a prototype demonstration. All user roles are now fully functional.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-slate-600">
              © 2026 FAO ATIO Knowledge Base. All rights reserved.
            </div>
            <div className="flex gap-6 text-sm text-slate-600">
              <a href="#" className="hover:text-slate-900">Privacy Policy</a>
              <a href="#" className="hover:text-slate-900">Data Governance</a>
              <a href="#" className="hover:text-slate-900">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}