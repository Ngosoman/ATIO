import { useState } from "react";
import { useNavigate } from "react-router";
import { 
  ArrowLeft, 
  Search, 
  Sprout, 
  Droplet, 
  Wheat, 
  Package,
  DollarSign,
  Users,
  BookOpen,
  Download
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { mockTechnologies } from "../data/mockTechnologies";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const techImages: Record<string, string> = {
  "1": "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600",
  "2": "https://images.unsplash.com/photo-1710090720809-527cefdac598?w=600",
  "3": "https://images.unsplash.com/photo-1761666519224-5f81305cf170?w=600",
  "4": "https://images.unsplash.com/photo-1655102713930-ed68081e6b7d?w=600",
  "5": "https://images.unsplash.com/photo-1608061609218-0f39494d6d7a?w=600",
  "6": "https://images.unsplash.com/photo-1644845664240-bd0813b50cb5?w=600",
};

export function FarmerInterface() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = [
    { id: "water", label: "Water & Irrigation", icon: <Droplet className="size-5" /> },
    { id: "crop", label: "Crops & Soil", icon: <Wheat className="size-5" /> },
    { id: "postharvest", label: "Storage & Post-harvest", icon: <Package className="size-5" /> },
    { id: "all", label: "All Solutions", icon: <Sprout className="size-5" /> },
  ];

  const filteredTechnologies = mockTechnologies.filter((tech) => {
    const matchesSearch = searchQuery === "" || 
      tech.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.summary.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = !selectedCategory || selectedCategory === "all" ||
      (selectedCategory === "water" && tech.domain.includes("Water")) ||
      (selectedCategory === "crop" && (tech.domain.includes("Soil") || tech.domain.includes("Pest") || tech.domain.includes("Climate"))) ||
      (selectedCategory === "postharvest" && tech.domain.includes("Post-Harvest"));

    return matchesSearch && matchesCategory;
  });

  const getCostBadge = (cost: string) => {
    switch (cost) {
      case "low": return { color: "bg-green-100 text-green-800", label: "Low Cost" };
      case "medium": return { color: "bg-yellow-100 text-yellow-800", label: "Medium Cost" };
      case "high": return { color: "bg-red-100 text-red-800", label: "Higher Cost" };
      default: return { color: "bg-slate-100 text-slate-800", label: "Cost varies" };
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 shadow-sm">
        <div className="px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="size-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center gap-2">
              <div className="size-10 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                <Sprout className="size-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900">Farmer Solutions</h1>
                <p className="text-xs text-slate-600">Find practical farming innovations</p>
              </div>
            </div>
          </div>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
            <Input
              placeholder="Describe your farming challenge..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-base"
            />
          </div>

          {/* Category Pills */}
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? "default" : "outline"}
                size="sm"
                className="flex-shrink-0"
                onClick={() => setSelectedCategory(cat.id)}
              >
                {cat.icon}
                <span className="ml-2">{cat.label}</span>
              </Button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-6 max-w-4xl mx-auto">
        <div className="mb-4">
          <p className="text-sm text-slate-600">
            {filteredTechnologies.length} solutions available
          </p>
        </div>

        {/* Technology Cards */}
        <div className="space-y-4">
          {filteredTechnologies.map((tech) => {
            const costBadge = getCostBadge(tech.costLevel);
            
            return (
              <Card
                key={tech.id}
                className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => navigate(`/technology/${tech.id}?role=farmer`)}
              >
                {/* Image */}
                <div className="relative h-48 bg-gradient-to-br from-slate-100 to-slate-200">
                  <ImageWithFallback
                    src={techImages[tech.id] || "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600"}
                    alt={tech.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Tags overlay */}
                  <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
                    {tech.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} className="bg-white/90 text-slate-900 backdrop-blur-sm">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="font-bold text-xl text-slate-900 mb-2">
                    {tech.title}
                  </h3>
                  
                  <p className="text-base text-slate-700 mb-4 leading-relaxed">
                    {tech.summary}
                  </p>

                  {/* Quick Info Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-3">
                      <DollarSign className="size-5 text-green-600" />
                      <div>
                        <p className="text-xs text-slate-600">Cost</p>
                        <p className="text-sm font-semibold text-slate-900">
                          {costBadge.label}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-3">
                      <Users className="size-5 text-blue-600" />
                      <div>
                        <p className="text-xs text-slate-600">Labour</p>
                        <p className="text-sm font-semibold text-slate-900 capitalize">
                          {tech.labourIntensity}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Tools Needed */}
                  <div className="mb-4">
                    <p className="text-xs font-semibold text-slate-600 mb-2">Tools needed:</p>
                    <div className="flex flex-wrap gap-1">
                      {tech.toolsNeeded.slice(0, 3).map((tool, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {tool}
                        </Badge>
                      ))}
                      {tech.toolsNeeded.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{tech.toolsNeeded.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Farmer Tips Preview */}
                  {tech.farmerTips.length > 0 && (
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
                      <div className="flex items-start gap-2">
                        <BookOpen className="size-4 text-amber-700 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-xs font-semibold text-amber-900 mb-1">Farmer tip:</p>
                          <p className="text-sm text-amber-900 italic">
                            "{tech.farmerTips[0]}"
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      className="flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/technology/${tech.id}?role=farmer`);
                      }}
                    >
                      <BookOpen className="size-4 mr-2" />
                      View Step-by-Step Guide
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        alert("Downloading for offline use...");
                      }}
                    >
                      <Download className="size-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {filteredTechnologies.length === 0 && (
          <div className="text-center py-12">
            <Sprout className="size-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">No solutions match your search</p>
            <p className="text-sm text-slate-500 mb-4">Try different keywords or browse all categories</p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
              }}
            >
              Show All Solutions
            </Button>
          </div>
        )}
      </main>

      {/* Floating Help Button */}
      <div className="fixed bottom-6 right-6">
        <Button
          size="lg"
          className="rounded-full shadow-lg h-14 px-6"
          onClick={() => alert("Help and support feature coming soon")}
        >
          Need Help?
        </Button>
      </div>
    </div>
  );
}
