import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, Download, Filter, GitCompare, X, FileText } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import { ScrollArea } from "../components/ui/scroll-area";
import { Separator } from "../components/ui/separator";
import { 
  atioInnovations, 
  ATIOInnovation,
  INNOVATION_TYPES, 
  REGIONS, 
  THEMES,
  SDG_NAMES,
  SDG_COLORS,
  getAdoptionBadgeColor,
  getEvidenceBadgeColor
} from "../data/atioInnovations";
import { InnovationCard } from "../components/InnovationCard";
import { FilterSheet } from "../components/FilterSheet";
import { MobileHeader } from "../components/MobileNav";

export function PolicyMakerDashboardV2() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Filters based on ATIO content model
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [selectedSDGs, setSelectedSDGs] = useState<number[]>([]);
  const [selectedReadiness, setSelectedReadiness] = useState<number[]>([]);
  const [selectedAdoption, setSelectedAdoption] = useState<string[]>([]);
  
  const [showFilters, setShowFilters] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState<string[]>([]);
  const [showComparison, setShowComparison] = useState(false);

  // Filter innovations
  const filteredInnovations = atioInnovations.filter((innovation) => {
    const matchesSearch = searchQuery === "" || 
      innovation.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.short_description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.long_description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesType = selectedTypes.length === 0 || selectedTypes.includes(innovation.type);
    const matchesRegion = selectedRegions.length === 0 || innovation.region.some(r => selectedRegions.includes(r));
    const matchesTheme = selectedThemes.length === 0 || innovation.theme.some(t => selectedThemes.includes(t));
    const matchesSDG = selectedSDGs.length === 0 || innovation.impact_sdgs.some(s => selectedSDGs.includes(s));
    const matchesReadiness = selectedReadiness.length === 0 || selectedReadiness.includes(innovation.readiness_level);
    const matchesAdoption = selectedAdoption.length === 0 || selectedAdoption.includes(innovation.adoption_level);

    return matchesSearch && matchesType && matchesRegion && matchesTheme && matchesSDG && matchesReadiness && matchesAdoption;
  });

  const toggleFilter = <T,>(value: T, list: T[], setter: (list: T[]) => void) => {
    if (list.includes(value)) {
      setter(list.filter(item => item !== value));
    } else {
      setter([...list, value]);
    }
  };

  const toggleComparison = (innovationId: string) => {
    if (selectedForComparison.includes(innovationId)) {
      setSelectedForComparison(selectedForComparison.filter(id => id !== innovationId));
    } else if (selectedForComparison.length < 3) {
      setSelectedForComparison([...selectedForComparison, innovationId]);
    } else {
      alert("You can compare up to 3 innovations at a time");
    }
  };

  const clearAllFilters = () => {
    setSearchQuery("");
    setSelectedTypes([]);
    setSelectedRegions([]);
    setSelectedThemes([]);
    setSelectedSDGs([]);
    setSelectedReadiness([]);
    setSelectedAdoption([]);
  };

  const activeFilterCount = selectedTypes.length + selectedRegions.length + selectedThemes.length + 
                           selectedSDGs.length + selectedReadiness.length + selectedAdoption.length;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Comparison Modal */}
      {showComparison && (
        <ComparisonModal
          innovations={atioInnovations.filter(i => selectedForComparison.includes(i.id))}
          onClose={() => setShowComparison(false)}
        />
      )}

      {/* Mobile Filter Sheet */}
      <FilterSheet
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        title="Filter Innovations"
        onApply={() => {}}
        onReset={clearAllFilters}
      >
        <FilterContent
          selectedTypes={selectedTypes}
          setSelectedTypes={setSelectedTypes}
          selectedRegions={selectedRegions}
          setSelectedRegions={setSelectedRegions}
          selectedThemes={selectedThemes}
          setSelectedThemes={setSelectedThemes}
          selectedSDGs={selectedSDGs}
          setSelectedSDGs={setSelectedSDGs}
          selectedReadiness={selectedReadiness}
          setSelectedReadiness={setSelectedReadiness}
          selectedAdoption={selectedAdoption}
          setSelectedAdoption={setSelectedAdoption}
          toggleFilter={toggleFilter}
          isMobile={true}
        />
      </FilterSheet>

      {/* Header - Mobile Optimized */}
      <MobileHeader
        title="Policy Dashboard"
        onBack={() => navigate("/")}
        actions={
          <>
            {selectedForComparison.length > 0 && (
              <Button
                size="sm"
                onClick={() => setShowComparison(true)}
                className="h-10 touch-manipulation"
              >
                <GitCompare className="size-4 md:mr-2" />
                <span className="hidden sm:inline">Compare</span>
                <span className="ml-1">({selectedForComparison.length})</span>
              </Button>
            )}
          </>
        }
      />

      {/* Search Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 sticky top-14 md:top-0 z-20">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="Search innovations by name, description, or theme..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-base"
              />
            </div>
            <Button
              variant="outline"
              size="lg"
              onClick={() => setShowFilters(!showFilters)}
              className="h-12 px-4 md:hidden touch-manipulation"
            >
              <Filter className="size-5" />
              {activeFilterCount > 0 && (
                <span className="ml-1 text-xs">({activeFilterCount})</span>
              )}
            </Button>
          </div>

          {activeFilterCount > 0 && (
            <div className="mt-2 flex items-center gap-2">
              <span className="text-xs text-slate-600">{activeFilterCount} active filters</span>
              <Button variant="ghost" size="sm" onClick={clearAllFilters} className="h-6 text-xs">
                Clear all
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Main Layout */}
      <div className="flex max-w-7xl mx-auto">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden md:block w-80 bg-white border-r border-slate-200 h-[calc(100vh-180px)] sticky top-[120px]">
          <ScrollArea className="h-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-slate-900">Filters</h2>
                {activeFilterCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                    Clear all
                  </Button>
                )}
              </div>
              
              <FilterContent
                selectedTypes={selectedTypes}
                setSelectedTypes={setSelectedTypes}
                selectedRegions={selectedRegions}
                setSelectedRegions={setSelectedRegions}
                selectedThemes={selectedThemes}
                setSelectedThemes={setSelectedThemes}
                selectedSDGs={selectedSDGs}
                setSelectedSDGs={setSelectedSDGs}
                selectedReadiness={selectedReadiness}
                setSelectedReadiness={setSelectedReadiness}
                selectedAdoption={selectedAdoption}
                setSelectedAdoption={setSelectedAdoption}
                toggleFilter={toggleFilter}
                isMobile={false}
              />
            </div>
          </ScrollArea>
        </aside>

        {/* Results Area */}
        <main className="flex-1 p-4 md:p-6">
          <div className="mb-4 flex justify-between items-center">
            <p className="text-sm text-slate-600">
              {filteredInnovations.length} innovations found
            </p>
            {selectedForComparison.length > 0 && (
              <Button size="sm" onClick={() => setShowComparison(true)} className="hidden md:flex">
                <GitCompare className="size-4 mr-2" />
                Compare {selectedForComparison.length} innovations
              </Button>
            )}
          </div>

          <div className="space-y-4">
            {filteredInnovations.map((innovation) => (
              <InnovationCard
                key={innovation.id}
                innovation={innovation}
                variant="policy"
                onClick={() => navigate(`/innovation/${innovation.id}?role=policy`)}
                selected={selectedForComparison.includes(innovation.id)}
                showCheckbox={true}
                onCheckboxChange={() => toggleComparison(innovation.id)}
              />
            ))}

            {filteredInnovations.length === 0 && (
              <div className="text-center py-12">
                <p className="text-slate-600 mb-4">No innovations match your current filters.</p>
                <Button variant="outline" onClick={clearAllFilters}>
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

// Filter Content Component (shared between mobile and desktop)
interface FilterContentProps {
  selectedTypes: string[];
  setSelectedTypes: (types: string[]) => void;
  selectedRegions: string[];
  setSelectedRegions: (regions: string[]) => void;
  selectedThemes: string[];
  setSelectedThemes: (themes: string[]) => void;
  selectedSDGs: number[];
  setSelectedSDGs: (sdgs: number[]) => void;
  selectedReadiness: number[];
  setSelectedReadiness: (levels: number[]) => void;
  selectedAdoption: string[];
  setSelectedAdoption: (levels: string[]) => void;
  toggleFilter: <T,>(value: T, list: T[], setter: (list: T[]) => void) => void;
  isMobile: boolean;
}

function FilterContent({ 
  selectedTypes, 
  setSelectedTypes,
  selectedRegions, 
  setSelectedRegions,
  selectedThemes, 
  setSelectedThemes,
  selectedSDGs,
  setSelectedSDGs,
  selectedReadiness,
  setSelectedReadiness,
  selectedAdoption,
  setSelectedAdoption,
  toggleFilter,
  isMobile 
}: FilterContentProps) {
  const spacing = isMobile ? "space-y-3" : "space-y-2";
  const labelSize = isMobile ? "text-base py-1" : "text-sm";

  return (
    <div className="space-y-6">
      {/* Innovation Type */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Innovation Type</h3>
        <div className={spacing}>
          {INNOVATION_TYPES.map((type) => (
            <div key={type} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}type-${type}`}
                checked={selectedTypes.includes(type)}
                onCheckedChange={() => toggleFilter(type, selectedTypes, setSelectedTypes)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}type-${type}`} className={`ml-3 cursor-pointer capitalize ${labelSize}`}>
                {type}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Region */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Region</h3>
        <div className={spacing}>
          {REGIONS.map((region) => (
            <div key={region} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}region-${region}`}
                checked={selectedRegions.includes(region)}
                onCheckedChange={() => toggleFilter(region, selectedRegions, setSelectedRegions)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}region-${region}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                {region}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Theme */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Theme</h3>
        <div className={spacing}>
          {THEMES.map((theme) => (
            <div key={theme} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}theme-${theme}`}
                checked={selectedThemes.includes(theme)}
                onCheckedChange={() => toggleFilter(theme, selectedThemes, setSelectedThemes)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}theme-${theme}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                {theme}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* SDG Goals */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Impact SDGs</h3>
        <div className={spacing}>
          {Object.entries(SDG_NAMES).slice(0, 8).map(([sdg, name]) => (
            <div key={sdg} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}sdg-${sdg}`}
                checked={selectedSDGs.includes(Number(sdg))}
                onCheckedChange={() => toggleFilter(Number(sdg), selectedSDGs, setSelectedSDGs)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}sdg-${sdg}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                SDG {sdg}: {name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Readiness Level */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Readiness Level</h3>
        <div className={spacing}>
          {[7, 8, 9].map((level) => (
            <div key={level} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}readiness-${level}`}
                checked={selectedReadiness.includes(level)}
                onCheckedChange={() => toggleFilter(level, selectedReadiness, setSelectedReadiness)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}readiness-${level}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                Level {level}/9 {level >= 8 && "(Mature)"}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Adoption Level */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Adoption Level</h3>
        <div className={spacing}>
          {["early", "growing", "common", "widespread"].map((level) => (
            <div key={level} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}adoption-${level}`}
                checked={selectedAdoption.includes(level)}
                onCheckedChange={() => toggleFilter(level, selectedAdoption, setSelectedAdoption)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}adoption-${level}`} className={`ml-3 cursor-pointer capitalize ${labelSize}`}>
                {level}
              </Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Comparison Modal Component
function ComparisonModal({ innovations, onClose }: { innovations: ATIOInnovation[], onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">Compare Innovations</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg">
            <X className="size-5" />
          </button>
        </div>

        {/* Comparison Table */}
        <ScrollArea className="flex-1">
          <div className="p-6">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="text-left p-3 bg-slate-50 font-semibold text-sm">Field</th>
                  {innovations.map((innovation) => (
                    <th key={innovation.id} className="text-left p-3 bg-slate-50 font-semibold text-sm w-1/3">
                      {innovation.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <ComparisonRow label="Type" values={innovations.map(i => i.type)} />
                <ComparisonRow label="Region" values={innovations.map(i => i.region.join(", "))} />
                <ComparisonRow label="Country Origin" values={innovations.map(i => i.country_origin)} />
                <ComparisonRow 
                  label="Adoption Countries" 
                  values={innovations.map(i => `${i.countries_adoption.length} countries: ${i.countries_adoption.slice(0, 3).join(", ")}${i.countries_adoption.length > 3 ? '...' : ''}`)} 
                />
                <ComparisonRow 
                  label="Readiness Level" 
                  values={innovations.map(i => `${i.readiness_level}/9`)} 
                />
                <ComparisonRow 
                  label="Adoption Level" 
                  values={innovations.map(i => <Badge key={i.id} className={getAdoptionBadgeColor(i.adoption_level)}>{i.adoption_level}</Badge>)} 
                />
                <ComparisonRow 
                  label="Impact SDGs" 
                  values={innovations.map(i => (
                    <div key={i.id} className="flex gap-1 flex-wrap">
                      {i.impact_sdgs.map(sdg => (
                        <Badge key={sdg} className={`${SDG_COLORS[sdg].bg} ${SDG_COLORS[sdg].text}`}>
                          {sdg}
                        </Badge>
                      ))}
                    </div>
                  ))} 
                />
                <ComparisonRow 
                  label="Profitability" 
                  values={innovations.map(i => i.impact_indicators?.profitability || "N/A")} 
                />
                <ComparisonRow 
                  label="Accessibility" 
                  values={innovations.map(i => i.impact_indicators?.accessibility || "N/A")} 
                />
                <ComparisonRow 
                  label="Sustainability" 
                  values={innovations.map(i => i.impact_indicators?.sustainability || "N/A")} 
                />
                <ComparisonRow 
                  label="Evidence Strength" 
                  values={innovations.map(i => <Badge key={i.id} className={getEvidenceBadgeColor(i.evidence_strength)}>{i.evidence_strength}</Badge>)} 
                />
                <ComparisonRow 
                  label="Data Source" 
                  values={innovations.map(i => i.data_source)} 
                />
                <ComparisonRow 
                  label="Key Partners" 
                  values={innovations.map(i => i.partners.slice(0, 3).join(", "))} 
                />
              </tbody>
            </table>
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="flex justify-end gap-2 px-6 py-4 border-t border-slate-200">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button>
            <Download className="size-4 mr-2" />
            Export Comparison
          </Button>
        </div>
      </div>
    </div>
  );
}

function ComparisonRow({ label, values }: { label: string, values: React.ReactNode[] }) {
  return (
    <tr className="border-b border-slate-200">
      <td className="p-3 font-medium text-sm text-slate-700 bg-slate-50/50">{label}</td>
      {values.map((value, idx) => (
        <td key={idx} className="p-3 text-sm text-slate-900">{value}</td>
      ))}
    </tr>
  );
}