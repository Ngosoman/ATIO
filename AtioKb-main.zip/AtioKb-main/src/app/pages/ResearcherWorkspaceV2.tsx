import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, Download, Filter, Bookmark, FileText, Database } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import { ScrollArea } from "../components/ui/scroll-area";
import { Separator } from "../components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  atioInnovations, 
  ATIOInnovation,
  INNOVATION_TYPES, 
  REGIONS, 
  THEMES,
  VALUE_CHAIN_STAGES,
  SDG_NAMES
} from "../data/atioInnovations";
import { InnovationCard } from "../components/InnovationCard";
import { FilterSheet } from "../components/FilterSheet";
import { MobileHeader } from "../components/MobileNav";

export function ResearcherWorkspaceV2() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [savedForLater, setSavedForLater] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"all" | "saved">("all");
  
  // Advanced filters for researchers
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [selectedStages, setSelectedStages] = useState<string[]>([]);
  const [selectedSDGs, setSelectedSDGs] = useState<number[]>([]);
  const [selectedReadiness, setSelectedReadiness] = useState<number[]>([]);
  const [selectedAdoption, setSelectedAdoption] = useState<string[]>([]);
  const [selectedEvidence, setSelectedEvidence] = useState<string[]>([]);
  const [hasResearchGaps, setHasResearchGaps] = useState(false);
  
  const [showFilters, setShowFilters] = useState(false);

  // Filter innovations
  const filteredInnovations = atioInnovations.filter((innovation) => {
    const matchesSearch = searchQuery === "" || 
      innovation.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.short_description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.long_description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      innovation.use_cases.some(uc => uc.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesType = selectedTypes.length === 0 || selectedTypes.includes(innovation.type);
    const matchesRegion = selectedRegions.length === 0 || innovation.region.some(r => selectedRegions.includes(r));
    const matchesTheme = selectedThemes.length === 0 || innovation.theme.some(t => selectedThemes.includes(t));
    const matchesStage = selectedStages.length === 0 || innovation.food_value_chain_stage.some(s => selectedStages.includes(s));
    const matchesSDG = selectedSDGs.length === 0 || innovation.impact_sdgs.some(s => selectedSDGs.includes(s));
    const matchesReadiness = selectedReadiness.length === 0 || selectedReadiness.includes(innovation.readiness_level);
    const matchesAdoption = selectedAdoption.length === 0 || selectedAdoption.includes(innovation.adoption_level);
    const matchesEvidence = selectedEvidence.length === 0 || selectedEvidence.includes(innovation.evidence_strength);
    const matchesResearchGaps = !hasResearchGaps || (innovation.further_research_needed && innovation.further_research_needed.length > 0);
    const matchesSaved = viewMode === "all" || savedForLater.includes(innovation.id);

    return matchesSearch && matchesType && matchesRegion && matchesTheme && matchesStage && 
           matchesSDG && matchesReadiness && matchesAdoption && matchesEvidence && 
           matchesResearchGaps && matchesSaved;
  });

  const toggleFilter = <T,>(value: T, list: T[], setter: (list: T[]) => void) => {
    if (list.includes(value)) {
      setter(list.filter(item => item !== value));
    } else {
      setter([...list, value]);
    }
  };

  const toggleSaved = (innovationId: string) => {
    if (savedForLater.includes(innovationId)) {
      setSavedForLater(savedForLater.filter(id => id !== innovationId));
    } else {
      setSavedForLater([...savedForLater, innovationId]);
    }
  };

  const clearAllFilters = () => {
    setSearchQuery("");
    setSelectedTypes([]);
    setSelectedRegions([]);
    setSelectedThemes([]);
    setSelectedStages([]);
    setSelectedSDGs([]);
    setSelectedReadiness([]);
    setSelectedAdoption([]);
    setSelectedEvidence([]);
    setHasResearchGaps(false);
  };

  const activeFilterCount = selectedTypes.length + selectedRegions.length + selectedThemes.length + 
                           selectedStages.length + selectedSDGs.length + selectedReadiness.length + 
                           selectedAdoption.length + selectedEvidence.length + (hasResearchGaps ? 1 : 0);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile Filter Sheet */}
      <FilterSheet
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        title="Advanced Filters"
        onApply={() => {}}
        onReset={clearAllFilters}
      >
        <ResearcherFilterContent
          selectedTypes={selectedTypes}
          setSelectedTypes={setSelectedTypes}
          selectedRegions={selectedRegions}
          setSelectedRegions={setSelectedRegions}
          selectedThemes={selectedThemes}
          setSelectedThemes={setSelectedThemes}
          selectedStages={selectedStages}
          setSelectedStages={setSelectedStages}
          selectedSDGs={selectedSDGs}
          setSelectedSDGs={setSelectedSDGs}
          selectedReadiness={selectedReadiness}
          setSelectedReadiness={setSelectedReadiness}
          selectedAdoption={selectedAdoption}
          setSelectedAdoption={setSelectedAdoption}
          selectedEvidence={selectedEvidence}
          setSelectedEvidence={setSelectedEvidence}
          hasResearchGaps={hasResearchGaps}
          setHasResearchGaps={setHasResearchGaps}
          toggleFilter={toggleFilter}
          isMobile={true}
        />
      </FilterSheet>

      {/* Header */}
      <MobileHeader
        title="Research Workspace"
        onBack={() => navigate("/")}
        actions={
          <Button
            size="sm"
            variant="outline"
            onClick={() => setViewMode(viewMode === "all" ? "saved" : "all")}
            className="h-10"
          >
            <Bookmark className={`size-4 md:mr-2 ${savedForLater.length > 0 ? "fill-current" : ""}`} />
            <span className="hidden md:inline">Saved</span>
            <span className="md:hidden">({savedForLater.length})</span>
          </Button>
        }
      />

      {/* Search Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 sticky top-14 md:top-0 z-20">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="Search by innovation name, use case, theme, or challenge..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-base"
              />
            </div>
            <Button
              variant="outline"
              size="lg"
              onClick={() => setShowFilters(!showFilters)}
              className="h-12 px-4 md:hidden touch-manipulation"
            >
              <Filter className="size-5" />
              {activeFilterCount > 0 && (
                <span className="ml-1 text-xs">({activeFilterCount})</span>
              )}
            </Button>
          </div>

          {activeFilterCount > 0 && (
            <div className="mt-2 flex items-center gap-2">
              <span className="text-xs text-slate-600">{activeFilterCount} active filters</span>
              <Button variant="ghost" size="sm" onClick={clearAllFilters} className="h-6 text-xs">
                Clear all
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Main Layout */}
      <div className="flex max-w-7xl mx-auto">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden md:block w-80 bg-white border-r border-slate-200 h-[calc(100vh-180px)] sticky top-[120px]">
          <ScrollArea className="h-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-slate-900">Advanced Filters</h2>
                {activeFilterCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                    Clear all
                  </Button>
                )}
              </div>
              
              <ResearcherFilterContent
                selectedTypes={selectedTypes}
                setSelectedTypes={setSelectedTypes}
                selectedRegions={selectedRegions}
                setSelectedRegions={setSelectedRegions}
                selectedThemes={selectedThemes}
                setSelectedThemes={setSelectedThemes}
                selectedStages={selectedStages}
                setSelectedStages={setSelectedStages}
                selectedSDGs={selectedSDGs}
                setSelectedSDGs={setSelectedSDGs}
                selectedReadiness={selectedReadiness}
                setSelectedReadiness={setSelectedReadiness}
                selectedAdoption={selectedAdoption}
                setSelectedAdoption={setSelectedAdoption}
                selectedEvidence={selectedEvidence}
                setSelectedEvidence={setSelectedEvidence}
                hasResearchGaps={hasResearchGaps}
                setHasResearchGaps={setHasResearchGaps}
                toggleFilter={toggleFilter}
                isMobile={false}
              />
            </div>
          </ScrollArea>
        </aside>

        {/* Results Area */}
        <main className="flex-1 p-4 md:p-6">
          {/* View Mode Tabs */}
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "all" | "saved")} className="mb-4">
            <TabsList>
              <TabsTrigger value="all">
                All Results ({filteredInnovations.length})
              </TabsTrigger>
              <TabsTrigger value="saved">
                Saved ({savedForLater.length})
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="mb-4 flex justify-between items-center">
            <p className="text-sm text-slate-600">
              {filteredInnovations.length} innovations found
            </p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline">
                <Database className="size-4 mr-2" />
                Export Dataset
              </Button>
              <Button size="sm">
                <Download className="size-4 mr-2" />
                Download Report
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            {filteredInnovations.map((innovation) => (
              <div key={innovation.id} className="relative">
                <InnovationCard
                  innovation={innovation}
                  variant="researcher"
                  onClick={() => navigate(`/innovation/${innovation.id}?role=researcher`)}
                  selected={savedForLater.includes(innovation.id)}
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSaved(innovation.id);
                  }}
                  className="absolute top-4 right-4 p-2 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow"
                  title={savedForLater.includes(innovation.id) ? "Remove from saved" : "Save for later"}
                >
                  <Bookmark 
                    className={`size-5 ${savedForLater.includes(innovation.id) ? "fill-blue-600 text-blue-600" : "text-slate-400"}`} 
                  />
                </button>
              </div>
            ))}

            {filteredInnovations.length === 0 && (
              <div className="text-center py-12">
                <p className="text-slate-600 mb-4">
                  {viewMode === "saved" 
                    ? "No saved innovations yet. Click the bookmark icon to save innovations for later."
                    : "No innovations match your current filters."}
                </p>
                {viewMode === "all" && (
                  <Button variant="outline" onClick={clearAllFilters}>
                    Clear All Filters
                  </Button>
                )}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

// Researcher Filter Content Component
interface ResearcherFilterContentProps {
  selectedTypes: string[];
  setSelectedTypes: (types: string[]) => void;
  selectedRegions: string[];
  setSelectedRegions: (regions: string[]) => void;
  selectedThemes: string[];
  setSelectedThemes: (themes: string[]) => void;
  selectedStages: string[];
  setSelectedStages: (stages: string[]) => void;
  selectedSDGs: number[];
  setSelectedSDGs: (sdgs: number[]) => void;
  selectedReadiness: number[];
  setSelectedReadiness: (levels: number[]) => void;
  selectedAdoption: string[];
  setSelectedAdoption: (levels: string[]) => void;
  selectedEvidence: string[];
  setSelectedEvidence: (levels: string[]) => void;
  hasResearchGaps: boolean;
  setHasResearchGaps: (value: boolean) => void;
  toggleFilter: <T,>(value: T, list: T[], setter: (list: T[]) => void) => void;
  isMobile: boolean;
}

function ResearcherFilterContent({ 
  selectedTypes,
  setSelectedTypes,
  selectedRegions,
  setSelectedRegions,
  selectedThemes,
  setSelectedThemes,
  selectedStages,
  setSelectedStages,
  selectedSDGs,
  setSelectedSDGs,
  selectedReadiness,
  setSelectedReadiness,
  selectedAdoption,
  setSelectedAdoption,
  selectedEvidence,
  setSelectedEvidence,
  hasResearchGaps,
  setHasResearchGaps,
  toggleFilter,
  isMobile 
}: ResearcherFilterContentProps) {
  const spacing = isMobile ? "space-y-3" : "space-y-2";
  const labelSize = isMobile ? "text-base py-1" : "text-sm";

  return (
    <div className="space-y-6">
      {/* Innovation Type */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Innovation Type</h3>
        <div className={spacing}>
          {INNOVATION_TYPES.map((type) => (
            <div key={type} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}type-${type}`}
                checked={selectedTypes.includes(type)}
                onCheckedChange={() => toggleFilter(type, selectedTypes, setSelectedTypes)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}type-${type}`} className={`ml-3 cursor-pointer capitalize ${labelSize}`}>
                {type}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Value Chain Stage */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Value Chain Stage</h3>
        <div className={spacing}>
          {VALUE_CHAIN_STAGES.map((stage) => (
            <div key={stage} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}stage-${stage}`}
                checked={selectedStages.includes(stage)}
                onCheckedChange={() => toggleFilter(stage, selectedStages, setSelectedStages)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}stage-${stage}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                {stage}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Region */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Region</h3>
        <div className={spacing}>
          {REGIONS.map((region) => (
            <div key={region} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}region-${region}`}
                checked={selectedRegions.includes(region)}
                onCheckedChange={() => toggleFilter(region, selectedRegions, setSelectedRegions)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}region-${region}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                {region}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Theme */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Theme</h3>
        <div className={spacing}>
          {THEMES.map((theme) => (
            <div key={theme} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}theme-${theme}`}
                checked={selectedThemes.includes(theme)}
                onCheckedChange={() => toggleFilter(theme, selectedThemes, setSelectedThemes)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}theme-${theme}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                {theme}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Evidence Strength */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Evidence Strength</h3>
        <div className={spacing}>
          {["high", "medium", "low"].map((level) => (
            <div key={level} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}evidence-${level}`}
                checked={selectedEvidence.includes(level)}
                onCheckedChange={() => toggleFilter(level, selectedEvidence, setSelectedEvidence)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}evidence-${level}`} className={`ml-3 cursor-pointer capitalize ${labelSize}`}>
                {level}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Readiness Level */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Readiness Level</h3>
        <div className={spacing}>
          {[7, 8, 9].map((level) => (
            <div key={level} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}readiness-${level}`}
                checked={selectedReadiness.includes(level)}
                onCheckedChange={() => toggleFilter(level, selectedReadiness, setSelectedReadiness)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}readiness-${level}`} className={`ml-3 cursor-pointer ${labelSize}`}>
                Level {level}/9 {level >= 8 && "(Mature)"}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Adoption Level */}
      <div>
        <h3 className="font-semibold text-sm text-slate-900 mb-3">Adoption Level</h3>
        <div className={spacing}>
          {["early", "growing", "common", "widespread"].map((level) => (
            <div key={level} className="flex items-center">
              <Checkbox
                id={`${isMobile ? 'mobile-' : ''}adoption-${level}`}
                checked={selectedAdoption.includes(level)}
                onCheckedChange={() => toggleFilter(level, selectedAdoption, setSelectedAdoption)}
                className={isMobile ? "touch-manipulation" : ""}
              />
              <Label htmlFor={`${isMobile ? 'mobile-' : ''}adoption-${level}`} className={`ml-3 cursor-pointer capitalize ${labelSize}`}>
                {level}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Research Gaps */}
      <div>
        <div className="flex items-center">
          <Checkbox
            id={`${isMobile ? 'mobile-' : ''}research-gaps`}
            checked={hasResearchGaps}
            onCheckedChange={setHasResearchGaps}
            className={isMobile ? "touch-manipulation" : ""}
          />
          <Label htmlFor={`${isMobile ? 'mobile-' : ''}research-gaps`} className={`ml-3 cursor-pointer ${labelSize}`}>
            Has identified research gaps
          </Label>
        </div>
      </div>
    </div>
  );
}