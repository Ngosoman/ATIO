import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Search, Download, FileText, TrendingUp, Filter, GitCompare, X } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import { ScrollArea } from "../components/ui/scroll-area";
import { Separator } from "../components/ui/separator";
import { mockTechnologies, SDG_NAMES, SDG_COLORS, TECH_ILLUSTRATIONS, REGIONS, DOMAINS, Technology } from "../data/mockTechnologies";
import { ComparisonView } from "../components/ComparisonView";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { FilterSheet } from "../components/FilterSheet";
import { MobileHeader } from "../components/MobileNav";

export function PolicyMakerDashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedSDGs, setSelectedSDGs] = useState<number[]>([]);
  const [selectedDomains, setSelectedDomains] = useState<string[]>([]);
  const [selectedAdoption, setSelectedAdoption] = useState<string[]>([]);
  const [selectedEvidence, setSelectedEvidence] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false); // Mobile-first: filters hidden by default
  const [selectedForComparison, setSelectedForComparison] = useState<string[]>([]);
  const [showComparison, setShowComparison] = useState(false);

  // Filter technologies
  const filteredTechnologies = mockTechnologies.filter((tech) => {
    const matchesSearch = searchQuery === "" || 
      tech.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.domain.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRegion = selectedRegions.length === 0 || 
      tech.region.some(r => selectedRegions.includes(r));

    const matchesSDG = selectedSDGs.length === 0 || 
      tech.sdgs.some(s => selectedSDGs.includes(s));

    const matchesDomain = selectedDomains.length === 0 || 
      selectedDomains.includes(tech.domain);

    const matchesAdoption = selectedAdoption.length === 0 || 
      selectedAdoption.includes(tech.adoptionLevel);

    const matchesEvidence = selectedEvidence.length === 0 || 
      selectedEvidence.includes(tech.evidenceStrength);

    return matchesSearch && matchesRegion && matchesSDG && matchesDomain && matchesAdoption && matchesEvidence;
  });

  const aiSuggestions = [
    "Climate-resilient innovations for East Africa",
    "High-evidence technologies for SDG 2",
    "Scalable water management solutions",
  ];

  const toggleFilter = (value: string, list: string[], setter: (list: string[]) => void) => {
    if (list.includes(value)) {
      setter(list.filter(item => item !== value));
    } else {
      setter([...list, value]);
    }
  };

  const toggleSDG = (sdg: number) => {
    if (selectedSDGs.includes(sdg)) {
      setSelectedSDGs(selectedSDGs.filter(s => s !== sdg));
    } else {
      setSelectedSDGs([...selectedSDGs, sdg]);
    }
  };

  const toggleComparison = (techId: string) => {
    if (selectedForComparison.includes(techId)) {
      setSelectedForComparison(selectedForComparison.filter(id => id !== techId));
    } else if (selectedForComparison.length < 3) {
      setSelectedForComparison([...selectedForComparison, techId]);
    } else {
      alert("You can compare up to 3 technologies at a time");
    }
  };

  const getEvidenceBadgeColor = (evidence: string) => {
    switch (evidence) {
      case "high": return "bg-green-100 text-green-800 border-green-200";
      case "medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low": return "bg-orange-100 text-orange-800 border-orange-200";
      default: return "bg-slate-100 text-slate-800 border-slate-200";
    }
  };

  const getAdoptionBadgeColor = (adoption: string) => {
    switch (adoption) {
      case "high": return "bg-blue-100 text-blue-800 border-blue-200";
      case "medium": return "bg-indigo-100 text-indigo-800 border-indigo-200";
      case "low": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-slate-100 text-slate-800 border-slate-200";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-safe">
      {/* Comparison View Modal */}
      {showComparison && (
        <ComparisonView
          technologies={mockTechnologies.filter(t => selectedForComparison.includes(t.id))}
          onClose={() => setShowComparison(false)}
        />
      )}

      {/* Mobile Filter Sheet */}
      <FilterSheet
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        title="Filter Innovations"
        onApply={() => {}}
        onReset={() => {
          setSelectedRegions([]);
          setSelectedSDGs([]);
          setSelectedDomains([]);
          setSelectedAdoption([]);
          setSelectedEvidence([]);
        }}
      >
        {/* Filter content */}
        <div className="space-y-6">
          {/* Region Filter */}
          <div>
            <h3 className="font-semibold text-sm text-slate-900 mb-3">Region</h3>
            <div className="space-y-3">
              {REGIONS.map((region) => (
                <div key={region} className="flex items-center">
                  <Checkbox
                    id={`mobile-region-${region}`}
                    checked={selectedRegions.includes(region)}
                    onCheckedChange={() => toggleFilter(region, selectedRegions, setSelectedRegions)}
                    className="touch-manipulation"
                  />
                  <Label
                    htmlFor={`mobile-region-${region}`}
                    className="ml-3 text-base cursor-pointer flex-1 py-1"
                  >
                    {region}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* SDG Filter */}
          <div>
            <h3 className="font-semibold text-sm text-slate-900 mb-3">SDG Goals</h3>
            <div className="space-y-3">
              {Object.entries(SDG_NAMES).map(([sdg, name]) => (
                <div key={sdg} className="flex items-center">
                  <Checkbox
                    id={`mobile-sdg-${sdg}`}
                    checked={selectedSDGs.includes(Number(sdg))}
                    onCheckedChange={() => toggleSDG(Number(sdg))}
                    className="touch-manipulation"
                  />
                  <Label
                    htmlFor={`mobile-sdg-${sdg}`}
                    className="ml-3 text-base cursor-pointer flex-1 py-1"
                  >
                    SDG {sdg}: {name}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Domain Filter */}
          <div>
            <h3 className="font-semibold text-sm text-slate-900 mb-3">Domain</h3>
            <div className="space-y-3">
              {DOMAINS.map((domain) => (
                <div key={domain} className="flex items-center">
                  <Checkbox
                    id={`mobile-domain-${domain}`}
                    checked={selectedDomains.includes(domain)}
                    onCheckedChange={() => toggleFilter(domain, selectedDomains, setSelectedDomains)}
                    className="touch-manipulation"
                  />
                  <Label
                    htmlFor={`mobile-domain-${domain}`}
                    className="ml-3 text-base cursor-pointer flex-1 py-1"
                  >
                    {domain}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Adoption Level */}
          <div>
            <h3 className="font-semibold text-sm text-slate-900 mb-3">Adoption Level</h3>
            <div className="space-y-3">
              {["high", "medium", "low"].map((level) => (
                <div key={level} className="flex items-center">
                  <Checkbox
                    id={`mobile-adoption-${level}`}
                    checked={selectedAdoption.includes(level)}
                    onCheckedChange={() => toggleFilter(level, selectedAdoption, setSelectedAdoption)}
                    className="touch-manipulation"
                  />
                  <Label
                    htmlFor={`mobile-adoption-${level}`}
                    className="ml-3 text-base cursor-pointer capitalize flex-1 py-1"
                  >
                    {level}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Evidence Strength */}
          <div>
            <h3 className="font-semibold text-sm text-slate-900 mb-3">Evidence Strength</h3>
            <div className="space-y-3">
              {["high", "medium", "low"].map((level) => (
                <div key={level} className="flex items-center">
                  <Checkbox
                    id={`mobile-evidence-${level}`}
                    checked={selectedEvidence.includes(level)}
                    onCheckedChange={() => toggleFilter(level, selectedEvidence, setSelectedEvidence)}
                    className="touch-manipulation"
                  />
                  <Label
                    htmlFor={`mobile-evidence-${level}`}
                    className="ml-3 text-base cursor-pointer capitalize flex-1 py-1"
                  >
                    {level}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </FilterSheet>

      {/* Header - Mobile Optimized */}
      <MobileHeader
        title="Policy Maker"
        onBack={() => navigate("/")}
        actions={
          <>
            {selectedForComparison.length > 0 && (
              <Button
                size="sm"
                onClick={() => setShowComparison(true)}
                className="h-10 touch-manipulation"
              >
                <GitCompare className="size-4 md:mr-2" />
                <span className="hidden md:inline">Compare ({selectedForComparison.length})</span>
                <span className="md:hidden">({selectedForComparison.length})</span>
              </Button>
            )}
          </>
        }
      />

      {/* Search and Filter Bar - Mobile Optimized */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 sticky top-14 md:top-0 z-20">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
            <Input
              placeholder="Search innovations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-base"
            />
          </div>
          <Button
            variant="outline"
            size="lg"
            onClick={() => setShowFilters(true)}
            className="h-12 px-4 touch-manipulation"
          >
            <Filter className="size-5 md:mr-2" />
            <span className="hidden md:inline">Filters</span>
          </Button>
        </div>

        {/* Active Filter Count */}
        {(selectedRegions.length + selectedSDGs.length + selectedDomains.length + selectedAdoption.length + selectedEvidence.length > 0) && (
          <div className="mt-2 flex items-center gap-2">
            <span className="text-xs text-slate-600">
              {selectedRegions.length + selectedSDGs.length + selectedDomains.length + selectedAdoption.length + selectedEvidence.length} filters active
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSelectedRegions([]);
                setSelectedSDGs([]);
                setSelectedDomains([]);
                setSelectedAdoption([]);
                setSelectedEvidence([]);
              }}
              className="h-6 text-xs"
            >
              Clear all
            </Button>
          </div>
        )}

        {/* AI Suggestions - Hidden on small mobile */}
        <div className="mt-3 hidden sm:flex gap-2 flex-wrap">
          <span className="text-xs text-slate-500">Try:</span>
          {aiSuggestions.map((suggestion, index) => (
            <Button
              key={index}
              variant="secondary"
              size="sm"
              className="text-xs h-7"
              onClick={() => setSearchQuery(suggestion)}
            >
              {suggestion}
            </Button>
          ))}
        </div>
      </div>

      {/* Desktop Sidebar Filters - Hidden on Mobile */}
      <div className="flex">
        {showFilters && (
          <aside className="hidden lg:block w-80 bg-white border-r border-slate-200 h-[calc(100vh-180px)] sticky top-[180px]">
            <ScrollArea className="h-full">
              <div className="p-6 space-y-6">
                {/* Region Filter */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Region</h3>
                  <div className="space-y-2">
                    {REGIONS.map((region) => (
                      <div key={region} className="flex items-center">
                        <Checkbox
                          id={`region-${region}`}
                          checked={selectedRegions.includes(region)}
                          onCheckedChange={() => toggleFilter(region, selectedRegions, setSelectedRegions)}
                        />
                        <Label
                          htmlFor={`region-${region}`}
                          className="ml-2 text-sm cursor-pointer"
                        >
                          {region}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* SDG Filter */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">SDG Goals</h3>
                  <div className="space-y-2">
                    {Object.entries(SDG_NAMES).map(([sdg, name]) => (
                      <div key={sdg} className="flex items-center">
                        <Checkbox
                          id={`sdg-${sdg}`}
                          checked={selectedSDGs.includes(Number(sdg))}
                          onCheckedChange={() => toggleSDG(Number(sdg))}
                        />
                        <Label
                          htmlFor={`sdg-${sdg}`}
                          className="ml-2 text-sm cursor-pointer"
                        >
                          SDG {sdg}: {name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Domain Filter */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Innovation Type</h3>
                  <div className="space-y-2">
                    {DOMAINS.map((domain) => (
                      <div key={domain} className="flex items-center">
                        <Checkbox
                          id={`domain-${domain}`}
                          checked={selectedDomains.includes(domain)}
                          onCheckedChange={() => toggleFilter(domain, selectedDomains, setSelectedDomains)}
                        />
                        <Label
                          htmlFor={`domain-${domain}`}
                          className="ml-2 text-sm cursor-pointer"
                        >
                          {domain}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Adoption Level */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Adoption Level</h3>
                  <div className="space-y-2">
                    {["high", "medium", "low"].map((level) => (
                      <div key={level} className="flex items-center">
                        <Checkbox
                          id={`adoption-${level}`}
                          checked={selectedAdoption.includes(level)}
                          onCheckedChange={() => toggleFilter(level, selectedAdoption, setSelectedAdoption)}
                        />
                        <Label
                          htmlFor={`adoption-${level}`}
                          className="ml-2 text-sm cursor-pointer capitalize"
                        >
                          {level}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Evidence Strength */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Evidence Strength</h3>
                  <div className="space-y-2">
                    {["high", "medium", "low"].map((level) => (
                      <div key={level} className="flex items-center">
                        <Checkbox
                          id={`evidence-${level}`}
                          checked={selectedEvidence.includes(level)}
                          onCheckedChange={() => toggleFilter(level, selectedEvidence, setSelectedEvidence)}
                        />
                        <Label
                          htmlFor={`evidence-${level}`}
                          className="ml-2 text-sm cursor-pointer capitalize"
                        >
                          {level}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => {
                    setSelectedRegions([]);
                    setSelectedSDGs([]);
                    setSelectedDomains([]);
                    setSelectedAdoption([]);
                    setSelectedEvidence([]);
                  }}
                >
                  Clear All Filters
                </Button>
              </div>
            </ScrollArea>
          </aside>
        )}

        {/* Results Area - Mobile Optimized */}
        <main className="flex-1 px-4 py-4 md:p-6">
          <div className="mb-4 flex justify-between items-center">
            <p className="text-sm text-slate-600">
              {filteredTechnologies.length} innovations found
            </p>
          </div>

          <div className="space-y-4">
            {filteredTechnologies.map((tech) => (
              <Card
                key={tech.id}
                className={`p-6 transition-all ${
                  selectedForComparison.includes(tech.id)
                    ? "ring-2 ring-blue-500 shadow-lg"
                    : "hover:shadow-md"
                } cursor-pointer`}
                onClick={() => navigate(`/technology/${tech.id}?role=policy`)}
              >
                <div className="flex gap-4">
                  {/* Selection Checkbox */}
                  <div className="flex items-start pt-1">
                    <Checkbox
                      checked={selectedForComparison.includes(tech.id)}
                      onCheckedChange={(e) => {
                        e.stopPropagation?.();
                        toggleComparison(tech.id);
                      }}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-lg text-slate-900 mb-1">
                          {tech.title}
                        </h3>
                        <p className="text-sm text-slate-600">
                          {tech.region.join(", ")} • {tech.domain}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Badge className={getEvidenceBadgeColor(tech.evidenceStrength)}>
                          {tech.evidenceStrength} evidence
                        </Badge>
                        <Badge className={getAdoptionBadgeColor(tech.adoptionLevel)}>
                          {tech.adoptionLevel} adoption
                        </Badge>
                      </div>
                    </div>

                    <p className="text-sm text-slate-700 mb-4">
                      {tech.summary}
                    </p>

                    {/* SDG Tags */}
                    <div className="flex items-center gap-2 mb-3 flex-wrap">
                      <span className="text-xs font-medium text-slate-600">SDGs:</span>
                      {tech.sdgs.map((sdg) => {
                        const sdgColors = SDG_COLORS[sdg];
                        return (
                          <div
                            key={sdg}
                            className={`${sdgColors.bg} ${sdgColors.text} px-3 py-1 rounded-md font-semibold text-xs flex items-center gap-1.5`}
                            title={`SDG ${sdg}: ${SDG_NAMES[sdg]}`}
                          >
                            <span>{sdg}</span>
                            <span className="hidden md:inline">{SDG_NAMES[sdg]}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Impact Metrics */}
                    <div className="flex gap-6 pt-3 border-t border-slate-200">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="size-4 text-green-600" />
                        <div>
                          <p className="text-xs text-slate-600">Productivity</p>
                          <p className="text-sm font-semibold text-slate-900">+{tech.impact.productivity}%</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="size-4 text-blue-600" />
                        <div>
                          <p className="text-xs text-slate-600">Resilience</p>
                          <p className="text-sm font-semibold text-slate-900">+{tech.impact.resilience}%</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="size-4 text-orange-600" />
                        <div>
                          <p className="text-xs text-slate-600">Nutrition</p>
                          <p className="text-sm font-semibold text-slate-900">+{tech.impact.nutrition}%</p>
                        </div>
                      </div>
                      <div className="ml-auto">
                        <p className="text-xs text-slate-600 mb-1">Readiness</p>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 9 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-2 h-6 rounded-sm ${
                                i < tech.readinessLevel ? "bg-blue-500" : "bg-slate-200"
                              }`}
                            />
                          ))}
                          <span className="text-xs font-medium text-slate-900 ml-1">
                            {tech.readinessLevel}/9
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/technology/${tech.id}?role=policy`);
                    }}
                  >
                    <FileText className="size-4 mr-2" />
                    View Details
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      alert("Policy brief generation would start here");
                    }}
                  >
                    <Download className="size-4 mr-2" />
                    Generate Brief
                  </Button>
                </div>
              </Card>
            ))}

            {filteredTechnologies.length === 0 && (
              <div className="text-center py-12">
                <p className="text-slate-600">No innovations match your current filters.</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedRegions([]);
                    setSelectedSDGs([]);
                    setSelectedDomains([]);
                    setSelectedAdoption([]);
                    setSelectedEvidence([]);
                  }}
                >
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}