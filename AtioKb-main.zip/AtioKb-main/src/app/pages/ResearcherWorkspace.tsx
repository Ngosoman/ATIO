import { useState } from "react";
import { useNavigate } from "react-router";
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  FileText, 
  GitCompare,
  TrendingUp,
  MapPin,
  AlertCircle,
  ExternalLink,
  BookOpen,
  Download
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Card } from "../components/ui/card";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { ScrollArea } from "../components/ui/scroll-area";
import { Separator } from "../components/ui/separator";
import { mockTechnologies, DOMAINS, REGIONS, Technology } from "../data/mockTechnologies";

export function ResearcherWorkspace() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDomains, setSelectedDomains] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedForComparison, setSelectedForComparison] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"list" | "table">("list");
  const [showFilters, setShowFilters] = useState(true);

  const filteredTechnologies = mockTechnologies.filter((tech) => {
    const matchesSearch = searchQuery === "" || 
      tech.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.domain.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDomain = selectedDomains.length === 0 || 
      selectedDomains.includes(tech.domain);

    const matchesRegion = selectedRegions.length === 0 || 
      tech.region.some(r => selectedRegions.includes(r));

    return matchesSearch && matchesDomain && matchesRegion;
  });

  const toggleFilter = (value: string, list: string[], setter: (list: string[]) => void) => {
    if (list.includes(value)) {
      setter(list.filter(item => item !== value));
    } else {
      setter([...list, value]);
    }
  };

  const toggleComparison = (techId: string) => {
    if (selectedForComparison.includes(techId)) {
      setSelectedForComparison(selectedForComparison.filter(id => id !== techId));
    } else if (selectedForComparison.length < 3) {
      setSelectedForComparison([...selectedForComparison, techId]);
    } else {
      alert("You can compare up to 3 technologies at a time");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
              >
                <ArrowLeft className="size-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-xl font-bold text-slate-900">Research Workspace</h1>
                <p className="text-sm text-slate-600">Evaluate innovations and identify research gaps</p>
              </div>
            </div>
            <div className="flex gap-2">
              {selectedForComparison.length > 0 && (
                <Button
                  variant="default"
                  onClick={() => {
                    alert(`Comparing ${selectedForComparison.length} technologies`);
                  }}
                >
                  <GitCompare className="size-4 mr-2" />
                  Compare ({selectedForComparison.length})
                </Button>
              )}
              <Button variant="outline" size="sm">
                <Download className="size-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                placeholder="Search by technology, domain, or research question..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="size-4 mr-2" />
              Filters
            </Button>
          </div>

          {/* View Toggle */}
          <div className="mt-3 flex items-center gap-2">
            <span className="text-sm text-slate-600">View:</span>
            <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "list" | "table")}>
              <TabsList>
                <TabsTrigger value="list">Detailed List</TabsTrigger>
                <TabsTrigger value="table">Research Table</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Filters Sidebar */}
        {showFilters && (
          <aside className="w-72 bg-white border-r border-slate-200 h-[calc(100vh-200px)] sticky top-[200px]">
            <ScrollArea className="h-full">
              <div className="p-6 space-y-6">
                {/* Domain Filter */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Research Domain</h3>
                  <div className="space-y-2">
                    {DOMAINS.map((domain) => (
                      <div key={domain} className="flex items-center">
                        <Checkbox
                          id={`domain-${domain}`}
                          checked={selectedDomains.includes(domain)}
                          onCheckedChange={() => toggleFilter(domain, selectedDomains, setSelectedDomains)}
                        />
                        <Label
                          htmlFor={`domain-${domain}`}
                          className="ml-2 text-sm cursor-pointer"
                        >
                          {domain}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Region Filter */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Geographic Scope</h3>
                  <div className="space-y-2">
                    {REGIONS.map((region) => (
                      <div key={region} className="flex items-center">
                        <Checkbox
                          id={`region-${region}`}
                          checked={selectedRegions.includes(region)}
                          onCheckedChange={() => toggleFilter(region, selectedRegions, setSelectedRegions)}
                        />
                        <Label
                          htmlFor={`region-${region}`}
                          className="ml-2 text-sm cursor-pointer"
                        >
                          {region}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Quick Filters */}
                <div>
                  <h3 className="font-semibold text-sm text-slate-900 mb-3">Research Focus</h3>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => setSearchQuery("research gaps")}
                    >
                      Show innovations with research gaps
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => setSearchQuery("scalability")}
                    >
                      High scalability potential
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start"
                      onClick={() => setSearchQuery("contextual")}
                    >
                      Contextual constraints noted
                    </Button>
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => {
                    setSelectedDomains([]);
                    setSelectedRegions([]);
                    setSearchQuery("");
                  }}
                >
                  Clear All Filters
                </Button>
              </div>
            </ScrollArea>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="mb-4 flex justify-between items-center">
            <p className="text-sm text-slate-600">
              {filteredTechnologies.length} innovations • {selectedForComparison.length} selected for comparison
            </p>
          </div>

          {viewMode === "list" ? (
            <div className="space-y-4">
              {filteredTechnologies.map((tech) => (
                <Card
                  key={tech.id}
                  className={`p-6 transition-all ${
                    selectedForComparison.includes(tech.id)
                      ? "ring-2 ring-purple-500 shadow-lg"
                      : "hover:shadow-md"
                  }`}
                >
                  <div className="flex gap-4">
                    {/* Selection Checkbox */}
                    <div className="flex items-start pt-1">
                      <Checkbox
                        checked={selectedForComparison.includes(tech.id)}
                        onCheckedChange={() => toggleComparison(tech.id)}
                      />
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg text-slate-900 mb-1">
                            {tech.title}
                          </h3>
                          <div className="flex items-center gap-3 text-sm text-slate-600">
                            <span className="flex items-center gap-1">
                              <MapPin className="size-3" />
                              {tech.countries.join(", ")}
                            </span>
                            <span>•</span>
                            <span>{tech.domain}</span>
                            <span>•</span>
                            <Badge variant="outline" className="text-xs">
                              TRL {tech.readinessLevel}/9
                            </Badge>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => navigate(`/technology/${tech.id}?role=researcher`)}
                        >
                          <FileText className="size-4 mr-2" />
                          Full Details
                        </Button>
                      </div>

                      <p className="text-sm text-slate-700 mb-4">
                        {tech.summary}
                      </p>

                      {/* Research Insights Tabs */}
                      <Tabs defaultValue="evidence" className="w-full">
                        <TabsList className="grid w-full grid-cols-4">
                          <TabsTrigger value="evidence">Evidence</TabsTrigger>
                          <TabsTrigger value="scalability">Scalability</TabsTrigger>
                          <TabsTrigger value="gaps">Research Gaps</TabsTrigger>
                          <TabsTrigger value="constraints">Constraints</TabsTrigger>
                        </TabsList>

                        <TabsContent value="evidence" className="mt-4">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className={
                                tech.evidenceStrength === "high" 
                                  ? "bg-green-100 text-green-800" 
                                  : tech.evidenceStrength === "medium"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-orange-100 text-orange-800"
                              }>
                                {tech.evidenceStrength} evidence strength
                              </Badge>
                              <span className="text-sm text-slate-600">
                                {tech.evidenceLinks.length} studies/reports
                              </span>
                            </div>
                            {tech.evidenceLinks.map((link, idx) => (
                              <div key={idx} className="flex items-start gap-2 text-sm">
                                <BookOpen className="size-4 text-slate-400 mt-0.5 flex-shrink-0" />
                                <span className="text-slate-700">{link}</span>
                                <ExternalLink className="size-3 text-slate-400 ml-auto flex-shrink-0" />
                              </div>
                            ))}
                          </div>
                        </TabsContent>

                        <TabsContent value="scalability" className="mt-4">
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <p className="text-sm text-blue-900">
                              {tech.scalabilityNotes}
                            </p>
                          </div>
                          <div className="mt-3 grid grid-cols-3 gap-4">
                            <div>
                              <p className="text-xs text-slate-600 mb-1">Adoption Level</p>
                              <p className="text-sm font-semibold text-slate-900 capitalize">
                                {tech.adoptionLevel}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-600 mb-1">Cost Barrier</p>
                              <p className="text-sm font-semibold text-slate-900 capitalize">
                                {tech.costLevel}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-600 mb-1">Deployment</p>
                              <p className="text-sm font-semibold text-slate-900">
                                {tech.countries.length} countries
                              </p>
                            </div>
                          </div>
                        </TabsContent>

                        <TabsContent value="gaps" className="mt-4">
                          {tech.researchGaps.length > 0 ? (
                            <div className="space-y-2">
                              {tech.researchGaps.map((gap, idx) => (
                                <div key={idx} className="flex items-start gap-2">
                                  <AlertCircle className="size-4 text-amber-600 mt-0.5 flex-shrink-0" />
                                  <span className="text-sm text-slate-700">{gap}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-slate-500 italic">
                              No specific research gaps identified yet
                            </p>
                          )}
                        </TabsContent>

                        <TabsContent value="constraints" className="mt-4">
                          {tech.contextualConstraints.length > 0 ? (
                            <div className="space-y-2">
                              {tech.contextualConstraints.map((constraint, idx) => (
                                <div key={idx} className="flex items-start gap-2">
                                  <div className="size-1.5 rounded-full bg-slate-400 mt-2 flex-shrink-0" />
                                  <span className="text-sm text-slate-700">{constraint}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-slate-500 italic">
                              No contextual constraints documented
                            </p>
                          )}
                        </TabsContent>
                      </Tabs>

                      {/* Impact Metrics */}
                      <div className="flex gap-6 mt-4 pt-4 border-t border-slate-200">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="size-4 text-green-600" />
                          <div>
                            <p className="text-xs text-slate-600">Productivity</p>
                            <p className="text-sm font-semibold text-slate-900">+{tech.impact.productivity}%</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="size-4 text-blue-600" />
                          <div>
                            <p className="text-xs text-slate-600">Resilience</p>
                            <p className="text-sm font-semibold text-slate-900">+{tech.impact.resilience}%</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="size-4 text-orange-600" />
                          <div>
                            <p className="text-xs text-slate-600">Nutrition</p>
                            <p className="text-sm font-semibold text-slate-900">+{tech.impact.nutrition}%</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            // Table View
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Select</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Innovation</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Domain</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">TRL</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Evidence</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Adoption</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Research Gaps</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredTechnologies.map((tech) => (
                      <tr key={tech.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3">
                          <Checkbox
                            checked={selectedForComparison.includes(tech.id)}
                            onCheckedChange={() => toggleComparison(tech.id)}
                          />
                        </td>
                        <td className="px-4 py-3">
                          <div>
                            <p className="font-medium text-sm text-slate-900">{tech.title}</p>
                            <p className="text-xs text-slate-600">{tech.countries.slice(0, 2).join(", ")}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-700">{tech.domain}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline">{tech.readinessLevel}/9</Badge>
                        </td>
                        <td className="px-4 py-3">
                          <Badge className={
                            tech.evidenceStrength === "high" 
                              ? "bg-green-100 text-green-800" 
                              : tech.evidenceStrength === "medium"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-orange-100 text-orange-800"
                          }>
                            {tech.evidenceStrength}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 capitalize text-sm text-slate-700">{tech.adoptionLevel}</td>
                        <td className="px-4 py-3 text-sm text-slate-700">{tech.researchGaps.length}</td>
                        <td className="px-4 py-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/technology/${tech.id}?role=researcher`)}
                          >
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {filteredTechnologies.length === 0 && (
            <div className="text-center py-12">
              <p className="text-slate-600">No innovations match your current filters.</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedDomains([]);
                  setSelectedRegions([]);
                }}
              >
                Clear All Filters
              </Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
