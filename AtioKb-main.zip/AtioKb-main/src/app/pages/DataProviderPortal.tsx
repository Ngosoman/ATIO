import { useState } from "react";
import { useNavigate } from "react-router";
import { 
  ArrowLeft, 
  Database, 
  Link2, 
  BarChart3, 
  Shield, 
  CheckCircle2,
  RefreshCw,
  FileText,
  Settings,
  Upload,
  Globe
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";

export function DataProviderPortal() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<"overview" | "connect" | "manage">("overview");

  const connectedSources = [
    {
      id: "1",
      name: "CGIAR Innovation Database",
      type: "API",
      status: "active",
      records: 2453,
      lastSync: "2 hours ago",
      views: 15234,
    },
    {
      id: "2",
      name: "FAO Technology Catalog",
      type: "Database",
      status: "active",
      records: 1876,
      lastSync: "1 day ago",
      views: 8921,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
                <ArrowLeft className="size-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-3">
                <div className="size-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                  <Database className="size-7 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900">Data Provider Portal</h1>
                  <p className="text-sm text-slate-600">Connect and manage your data sources</p>
                </div>
              </div>
            </div>
            <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "overview" | "connect" | "manage")}>
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="connect">Connect Data</TabsTrigger>
                <TabsTrigger value="manage">Manage Sources</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {viewMode === "overview" && (
          <div className="space-y-6">
            {/* Info Banner */}
            <Card className="p-6 bg-indigo-50 border-indigo-200">
              <div className="flex gap-4">
                <div className="size-12 bg-indigo-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Globe className="size-7 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-xl text-indigo-900 mb-2">Federated Knowledge Model</h2>
                  <p className="text-indigo-800 mb-3">
                    The ATIO Knowledge Base uses a federated approach—your data stays with you. We index and link to your content, giving you full control over access, licensing, and updates.
                  </p>
                  <div className="flex gap-4 text-sm font-medium text-indigo-700">
                    <span className="flex items-center gap-1">
                      <Shield className="size-4" />
                      Your data, your control
                    </span>
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="size-4" />
                      Full attribution
                    </span>
                    <span className="flex items-center gap-1">
                      <BarChart3 className="size-4" />
                      Usage analytics
                    </span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="size-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Database className="size-5 text-blue-700" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-900">2</p>
                    <p className="text-xs text-slate-600">Connected Sources</p>
                  </div>
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="size-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <FileText className="size-5 text-green-700" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-900">4,329</p>
                    <p className="text-xs text-slate-600">Total Records</p>
                  </div>
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="size-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <BarChart3 className="size-5 text-purple-700" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-900">24,155</p>
                    <p className="text-xs text-slate-600">Total Views</p>
                  </div>
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="size-10 bg-orange-100 rounded-lg flex items-center justify-center">
                    <RefreshCw className="size-5 text-orange-700" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-900">2h</p>
                    <p className="text-xs text-slate-600">Last Sync</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Connected Sources */}
            <div>
              <h2 className="text-xl font-bold text-slate-900 mb-4">Your Connected Sources</h2>
              <div className="grid gap-4">
                {connectedSources.map((source) => (
                  <Card key={source.id} className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg text-slate-900">{source.name}</h3>
                          <Badge className="bg-green-100 text-green-800">
                            <div className="size-2 rounded-full bg-green-600 mr-1.5" />
                            {source.status}
                          </Badge>
                          <Badge variant="outline">{source.type}</Badge>
                        </div>

                        <div className="grid grid-cols-3 gap-6 mt-4">
                          <div>
                            <p className="text-sm text-slate-600">Records Indexed</p>
                            <p className="text-xl font-semibold text-slate-900">{source.records.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-slate-600">Total Views</p>
                            <p className="text-xl font-semibold text-slate-900">{source.views.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-slate-600">Last Sync</p>
                            <p className="text-sm font-semibold text-slate-900">{source.lastSync}</p>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2 ml-4">
                        <Button variant="outline" size="sm">
                          <Settings className="size-4 mr-1" />
                          Settings
                        </Button>
                        <Button variant="outline" size="sm">
                          <RefreshCw className="size-4 mr-1" />
                          Sync Now
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}

        {viewMode === "connect" && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Connect Your Data Source</h2>
              <p className="text-slate-600">Choose how you want to integrate your database with the ATIO Knowledge Base</p>
            </div>

            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <Card className="p-6 cursor-pointer hover:shadow-lg transition-shadow border-2 border-transparent hover:border-indigo-500">
                <div className="size-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <Link2 className="size-6 text-indigo-700" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">API Integration</h3>
                <p className="text-sm text-slate-600">
                  Connect via REST API for real-time synchronization
                </p>
              </Card>

              <Card className="p-6 cursor-pointer hover:shadow-lg transition-shadow border-2 border-transparent hover:border-indigo-500">
                <div className="size-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Upload className="size-6 text-green-700" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">File Upload</h3>
                <p className="text-sm text-slate-600">
                  Upload spreadsheets or documents periodically
                </p>
              </Card>

              <Card className="p-6 cursor-pointer hover:shadow-lg transition-shadow border-2 border-transparent hover:border-indigo-500">
                <div className="size-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <FileText className="size-6 text-purple-700" />
                </div>
                <h3 className="font-semibold text-lg text-slate-900 mb-2">Manual Curation</h3>
                <p className="text-sm text-slate-600">
                  Submit entries through a guided form
                </p>
              </Card>
            </div>

            <Card className="p-8">
              <h3 className="font-semibold text-xl text-slate-900 mb-6">Setup New Connection</h3>
              
              <div className="space-y-6">
                <div>
                  <Label htmlFor="sourceName" className="text-base">Data Source Name *</Label>
                  <Input
                    id="sourceName"
                    placeholder="e.g., My Organization Innovation Database"
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label className="text-base mb-2 block">Connection Method *</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="api">REST API</SelectItem>
                      <SelectItem value="file">File Upload</SelectItem>
                      <SelectItem value="manual">Manual Entry</SelectItem>
                      <SelectItem value="website">Website Scraping</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="dataType" className="text-base mb-2 block">Data Type *</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="innovations">Innovations & Technologies</SelectItem>
                      <SelectItem value="research">Research Publications</SelectItem>
                      <SelectItem value="cases">Case Studies</SelectItem>
                      <SelectItem value="practices">Best Practices</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-base mb-2 block">Sync Frequency</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="How often should we sync?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="realtime">Real-time (API only)</SelectItem>
                      <SelectItem value="hourly">Every Hour</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="manual">Manual Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Card className="p-5 bg-amber-50 border-amber-200">
                  <h4 className="font-semibold text-amber-900 mb-3 flex items-center gap-2">
                    <Shield className="size-5" />
                    Data Governance & Licensing
                  </h4>
                  <div className="space-y-2 text-sm text-amber-900">
                    <p>Please specify:</p>
                    <ul className="list-disc list-inside space-y-1 ml-2">
                      <li>What can be indexed and displayed</li>
                      <li>How content should be attributed</li>
                      <li>Usage restrictions (if any)</li>
                      <li>Whether AI/ML training is permitted</li>
                    </ul>
                  </div>
                </Card>

                <div className="flex gap-3 pt-4">
                  <Button className="flex-1">
                    Continue to Mapping
                  </Button>
                  <Button variant="outline">
                    Save as Draft
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}

        {viewMode === "manage" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-slate-900">Manage Your Data Sources</h2>
            
            {connectedSources.map((source) => (
              <Card key={source.id} className="p-6">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h3 className="font-semibold text-lg text-slate-900 mb-1">{source.name}</h3>
                    <div className="flex gap-2">
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                      <Badge variant="outline">{source.type}</Badge>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Settings className="size-4 mr-1" />
                      Configure
                    </Button>
                    <Button variant="outline" size="sm">
                      Pause Sync
                    </Button>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-sm text-slate-700 mb-3">Sharing Preferences</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Public Access:</span>
                        <span className="font-medium text-slate-900">Enabled</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Attribution:</span>
                        <span className="font-medium text-slate-900">Required</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">AI Training:</span>
                        <span className="font-medium text-slate-900">Not Permitted</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm text-slate-700 mb-3">Usage Analytics (Last 30 Days)</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Page Views:</span>
                        <span className="font-medium text-slate-900">{source.views.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Unique Visitors:</span>
                        <span className="font-medium text-slate-900">3,421</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Downloads:</span>
                        <span className="font-medium text-slate-900">892</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
