import { createBrowserRouter } from "react-router";
import { RoleLanding } from "./pages/RoleLanding";
import { PolicyMakerDashboard } from "./pages/PolicyMakerDashboard";
import { PolicyMakerDashboardV2 } from "./pages/PolicyMakerDashboardV2";
import { FarmerInterface } from "./pages/FarmerInterface";
import { FarmerInterfaceV2 } from "./pages/FarmerInterfaceV2";
import { FarmerHome } from "./pages/FarmerHome";
import { FarmerSearch } from "./pages/FarmerSearch";
import { FarmerSaved } from "./pages/FarmerSaved";
import { FarmerProfile } from "./pages/FarmerProfile";
import { ResearcherWorkspace } from "./pages/ResearcherWorkspace";
import { ResearcherWorkspaceV2 } from "./pages/ResearcherWorkspaceV2";
import { AgripreneurDashboard } from "./pages/AgripreneurDashboard";
import { NGOInterface } from "./pages/NGOInterface";
import { EducationInterface } from "./pages/EducationInterface";
import { ContributeInterface } from "./pages/ContributeInterface";
import { DataProviderPortal } from "./pages/DataProviderPortal";
import { TechnologyDetail } from "./pages/TechnologyDetail";
import { InnovationDetail } from "./pages/InnovationDetail";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <RoleLanding />,
  },
  {
    path: "/policy-maker",
    element: <PolicyMakerDashboardV2 />, // Using V2
  },
  // Farmer routes - mobile-first
  {
    path: "/farmer",
    element: <FarmerHome />, // New farmer home
  },
  {
    path: "/farmer/search",
    element: <FarmerSearch />, // New search page
  },
  {
    path: "/farmer/saved",
    element: <FarmerSaved />, // New saved page
  },
  {
    path: "/farmer/profile",
    element: <FarmerProfile />, // New profile page
  },
  {
    path: "/researcher",
    element: <ResearcherWorkspaceV2 />, // Using V2
  },
  {
    path: "/agripreneur",
    element: <AgripreneurDashboard />,
  },
  {
    path: "/ngo",
    element: <NGOInterface />,
  },
  {
    path: "/education",
    element: <EducationInterface />,
  },
  {
    path: "/contribute",
    element: <ContributeInterface />,
  },
  {
    path: "/data-provider",
    element: <DataProviderPortal />,
  },
  {
    path: "/technology/:id",
    element: <TechnologyDetail />,
  },
  {
    path: "/innovation/:id", // New ATIO-based detail page
    element: <InnovationDetail />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);