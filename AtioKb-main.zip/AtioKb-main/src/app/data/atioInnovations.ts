// ATIO Knowledge Base Innovation Profile
// Based on the ATIO KB JSON content model

export interface ATIOInnovation {
  id: string;
  name: string;
  short_description: string;
  long_description: string;
  type: "technological" | "social" | "organizational" | "institutional" | "hybrid";
  
  // Classification & Context
  use_cases: string[];
  challenges_addressed: string[];
  theme: string[];
  food_value_chain_stage: string[];
  
  // Readiness & Adoption
  atio_innovation_stage: string;
  readiness_level: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  adoption_level: "early" | "growing" | "common" | "widespread";
  
  // Geography
  country_origin: string;
  countries_adoption: string[];
  region: string[];
  
  // Impact
  impact_sdgs: number[];
  impact_indicators?: {
    productivity?: string;
    resilience?: string;
    nutrition?: string;
    profitability?: string;
    accessibility?: string;
    sustainability?: string;
  };
  
  // Users & Beneficiaries
  target_users: string[];
  actual_users?: string[];
  beneficiaries?: string[];
  
  // Innovation Elements
  innovation_elements?: {
    technological?: string[];
    social?: string[];
    organizational?: string[];
    institutional?: string[];
  };
  
  // Implementation
  information_for_use?: string;
  enabling_conditions?: string[];
  constraints?: string[];
  
  // Evidence & Research
  data_source: string;
  evidence_strength: "low" | "medium" | "high";
  further_research_needed?: string[];
  
  // Collaboration
  partners: string[];
  investment_partners?: string[];
  
  // Additional metadata
  cost_level?: "low" | "medium" | "high";
  labour_intensity?: "low" | "medium" | "high";
  
  // Farmer-specific (simplified from complex data)
  farmer_friendly_description?: string;
  simple_steps?: string[];
  local_examples?: string[];
}

// SDG Data (official UN SDG names and colors)
export const SDG_NAMES: Record<number, string> = {
  1: "No Poverty",
  2: "Zero Hunger",
  3: "Good Health",
  4: "Quality Education",
  5: "Gender Equality",
  6: "Clean Water",
  7: "Clean Energy",
  8: "Decent Work",
  9: "Industry & Innovation",
  10: "Reduced Inequalities",
  11: "Sustainable Cities",
  12: "Responsible Consumption",
  13: "Climate Action",
  14: "Life Below Water",
  15: "Life on Land",
  16: "Peace & Justice",
  17: "Partnerships",
};

export const SDG_COLORS: Record<number, { bg: string; text: string; border: string }> = {
  1: { bg: "bg-[#E5243B]", text: "text-white", border: "border-[#E5243B]" },
  2: { bg: "bg-[#DDA63A]", text: "text-white", border: "border-[#DDA63A]" },
  3: { bg: "bg-[#4C9F38]", text: "text-white", border: "border-[#4C9F38]" },
  4: { bg: "bg-[#C5192D]", text: "text-white", border: "border-[#C5192D]" },
  5: { bg: "bg-[#FF3A21]", text: "text-white", border: "border-[#FF3A21]" },
  6: { bg: "bg-[#26BDE2]", text: "text-white", border: "border-[#26BDE2]" },
  7: { bg: "bg-[#FCC30B]", text: "text-slate-900", border: "border-[#FCC30B]" },
  8: { bg: "bg-[#A21942]", text: "text-white", border: "border-[#A21942]" },
  9: { bg: "bg-[#FD6925]", text: "text-white", border: "border-[#FD6925]" },
  10: { bg: "bg-[#DD1367]", text: "text-white", border: "border-[#DD1367]" },
  11: { bg: "bg-[#FD9D24]", text: "text-slate-900", border: "border-[#FD9D24]" },
  12: { bg: "bg-[#BF8B2E]", text: "text-white", border: "border-[#BF8B2E]" },
  13: { bg: "bg-[#3F7E44]", text: "text-white", border: "border-[#3F7E44]" },
  14: { bg: "bg-[#0A97D9]", text: "text-white", border: "border-[#0A97D9]" },
  15: { bg: "bg-[#56C02B]", text: "text-white", border: "border-[#56C02B]" },
  16: { bg: "bg-[#00689D]", text: "text-white", border: "border-[#00689D]" },
  17: { bg: "bg-[#19486A]", text: "text-white", border: "border-[#19486A]" },
};

// Filter Options
export const INNOVATION_TYPES = ["technological", "social", "organizational", "institutional", "hybrid"];
export const REGIONS = ["East Africa", "West Africa", "Southern Africa", "Central Africa", "Sub-Saharan Africa"];
export const THEMES = [
  "Climate adaptation",
  "Water management",
  "Soil health",
  "Digital agriculture",
  "Market access",
  "Gender equity",
  "Youth engagement",
  "Sustainable intensification"
];
export const VALUE_CHAIN_STAGES = [
  "Pre-production",
  "Production",
  "Post-harvest",
  "Processing",
  "Marketing",
  "Consumption"
];

// Mock ATIO Innovations Dataset
export const atioInnovations: ATIOInnovation[] = [
  {
    id: "atio-001",
    name: "Solar-Powered Drip Irrigation System",
    short_description: "Low-cost solar drip irrigation reducing water use by 60% while increasing yields by 40%",
    long_description: "A complete irrigation solution that uses solar energy to pump water through drip lines, delivering water directly to plant roots. This system significantly reduces water consumption compared to traditional flooding or furrow irrigation methods while improving crop yields. The technology is particularly suitable for smallholder farmers in water-scarce regions and can be adapted to various crop types. Installation requires minimal technical expertise, and the system pays for itself within 2-3 growing seasons through increased productivity and reduced labor costs.",
    type: "technological",
    
    use_cases: [
      "Vegetable production in water-scarce areas",
      "Year-round irrigation for high-value crops",
      "Climate adaptation for drought-prone regions"
    ],
    challenges_addressed: [
      "Water scarcity",
      "High irrigation labor costs",
      "Unreliable electricity supply",
      "Low crop yields in dry seasons"
    ],
    theme: ["Water management", "Climate adaptation", "Sustainable intensification"],
    food_value_chain_stage: ["Production"],
    
    atio_innovation_stage: "Proven technology with scaling potential",
    readiness_level: 8,
    adoption_level: "growing",
    
    country_origin: "Israel",
    countries_adoption: ["Kenya", "Tanzania", "Ethiopia", "Uganda", "Rwanda"],
    region: ["East Africa", "Sub-Saharan Africa"],
    
    impact_sdgs: [2, 6, 13],
    impact_indicators: {
      productivity: "30-50% yield increase for vegetables",
      resilience: "65% improved drought resilience",
      profitability: "ROI within 2-3 seasons",
      accessibility: "Medium - requires initial investment of $300-800",
      sustainability: "High - renewable energy, reduced water use"
    },
    
    target_users: ["Smallholder vegetable farmers", "Women farmer groups", "Youth in agriculture"],
    actual_users: ["Commercial smallholders with 0.5-2 hectares", "Cooperative farms"],
    beneficiaries: ["Farming households", "Local markets with fresh vegetables"],
    
    innovation_elements: {
      technological: ["Solar photovoltaic pump", "Drip irrigation system", "Timer controls"],
      social: ["Farmer training programs", "Women's access to water technology"],
      organizational: ["Group purchasing models", "Maintenance cooperatives"]
    },
    
    information_for_use: "Install solar panel in sunny location. Set up water storage tank at elevated position. Lay drip lines along crop rows. Connect pump to solar panel and timer. Test system and adjust flow rates. Clean filters weekly to prevent clogging.",
    enabling_conditions: [
      "Access to initial capital or financing",
      "Availability of spare parts",
      "Basic technical training",
      "Suitable water source"
    ],
    constraints: [
      "Requires upfront investment",
      "May need technical support for repairs",
      "Not suitable for very small plots (<0.25 hectare)"
    ],
    
    data_source: "ICRAF Kenya trials (2024), FAO Smallholder Irrigation Report (2023)",
    evidence_strength: "high",
    further_research_needed: [
      "Long-term maintenance costs in different contexts",
      "Social equity impacts within households",
      "Integration with soil moisture sensors"
    ],
    
    partners: ["ICRAF", "Solar Sister", "KickStart International", "FAO"],
    investment_partners: ["IFAD", "African Development Bank", "GCF"],
    
    cost_level: "medium",
    labour_intensity: "low",
    
    farmer_friendly_description: "A sun-powered watering system that saves water and helps crops grow better, even during dry times.",
    simple_steps: [
      "Put the solar panel where it gets lots of sun",
      "Place water container higher than your crops",
      "Lay water pipes next to your plants",
      "Turn on the system - the sun does the rest!",
      "Clean the filter every week"
    ],
    local_examples: [
      "John in Kenya: 'My tomatoes now grow even in dry season. I save 4 hours a day not carrying water.' - Kitui, Kenya",
      "Amina's group in Tanzania: 'We bought one system together and now we all have fresh vegetables to sell.' - Arusha, Tanzania"
    ]
  },
  {
    id: "atio-002",
    name: "Community Seed Banks",
    short_description: "Farmer-managed seed conservation and distribution system preserving local varieties",
    long_description: "Community-based seed banking systems enable farmers to conserve, multiply, and exchange locally adapted crop varieties. These seed banks are managed by farmer groups who store diverse seeds, maintain seed quality through proper storage techniques, and facilitate seed exchange among members. The system preserves agrobiodiversity while ensuring farmers have access to quality seeds suited to local conditions. Community seed banks also serve as knowledge hubs where traditional farming practices are documented and shared across generations.",
    type: "social",
    
    use_cases: [
      "Preservation of indigenous crop varieties",
      "Improving seed security at community level",
      "Reducing dependence on external seed suppliers"
    ],
    challenges_addressed: [
      "Loss of traditional crop varieties",
      "Poor quality commercial seeds",
      "High cost of certified seeds",
      "Climate variability requiring diverse varieties"
    ],
    theme: ["Agrobiodiversity", "Climate adaptation", "Traditional knowledge", "Sustainable intensification"],
    food_value_chain_stage: ["Pre-production"],
    
    atio_innovation_stage: "Established practice with replication evidence",
    readiness_level: 7,
    adoption_level: "common",
    
    country_origin: "India",
    countries_adoption: ["Ethiopia", "Zimbabwe", "Uganda", "Malawi", "Zambia", "Kenya"],
    region: ["East Africa", "Southern Africa", "Sub-Saharan Africa"],
    
    impact_sdgs: [2, 15, 13],
    impact_indicators: {
      resilience: "80% improved seed security",
      sustainability: "High - preserves local biodiversity",
      accessibility: "Very high - community-managed, no individual cost",
      profitability: "Seed costs reduced by 60-80%"
    },
    
    target_users: ["Smallholder farming communities", "Women farmer groups", "Indigenous communities"],
    actual_users: ["Village-level farmer organizations", "Agricultural cooperatives"],
    beneficiaries: ["Entire farming community", "Future generations"],
    
    innovation_elements: {
      social: ["Community governance structures", "Seed exchange protocols", "Knowledge sharing platforms"],
      organizational: ["Seed bank management committees", "Quality control systems"],
      institutional: ["Recognition by local government", "Integration with extension services"]
    },
    
    information_for_use: "Form a community seed bank committee with 10-15 members. Secure storage space with good ventilation and pest control. Collect diverse seed varieties from community members. Establish rules for seed borrowing and return. Document seed characteristics and farmer knowledge. Organize annual seed fairs for exchange.",
    enabling_conditions: [
      "Strong community organization",
      "Secure storage facility",
      "Training in seed storage techniques",
      "Documentation support"
    ],
    constraints: [
      "Requires ongoing community commitment",
      "Vulnerable to pest damage without proper storage",
      "May face regulatory barriers in some countries"
    ],
    
    data_source: "Bioversity International (2023), PELUM Ethiopia case studies (2024)",
    evidence_strength: "high",
    further_research_needed: [
      "Impact on crop genetic diversity over time",
      "Integration with formal seed certification systems",
      "Economic valuation of agrobiodiversity conservation"
    ],
    
    partners: ["Bioversity International", "PELUM", "USC Canada", "FAO", "Local NGOs"],
    investment_partners: ["CGIAR", "European Union", "Community development funds"],
    
    cost_level: "low",
    labour_intensity: "medium",
    
    farmer_friendly_description: "A community storage place for traditional seeds where farmers can borrow, share, and keep our local crop varieties safe.",
    simple_steps: [
      "Join with other farmers (10-15 people)",
      "Find a dry, safe place to store seeds",
      "Each person brings their best traditional seeds",
      "Write down what each seed is good for",
      "Borrow seeds when planting, return double after harvest"
    ],
    local_examples: [
      "Meseret in Ethiopia: 'We saved 8 types of sorghum our grandmothers grew. Now we choose the best for each year's weather.' - Tigray, Ethiopia",
      "Grace's group in Zimbabwe: 'The seed bank saved us during drought. We had varieties that still grew when hybrid seeds failed.' - Masvingo, Zimbabwe"
    ]
  },
  {
    id: "atio-003",
    name: "Mobile-Based Market Price Information System",
    short_description: "SMS and app-based platform providing real-time market prices to farmers",
    long_description: "A digital platform that delivers real-time market price information to farmers via SMS or mobile application, enabling better decision-making on when and where to sell produce. The system aggregates price data from multiple markets and provides farmers with comparative information, reducing information asymmetry that typically disadvantages smallholder farmers. The platform also includes weather forecasts, agronomic tips, and buyer connections. Success depends on mobile network coverage and farmer digital literacy, but has shown significant impact on farmer incomes by enabling strategic marketing decisions.",
    type: "technological",
    
    use_cases: [
      "Accessing real-time market prices before harvest",
      "Comparing prices across different markets",
      "Connecting directly with buyers"
    ],
    challenges_addressed: [
      "Price exploitation by middlemen",
      "Lack of market information",
      "Post-harvest losses due to distress selling",
      "Limited bargaining power"
    ],
    theme: ["Market access", "Digital agriculture", "Gender equity"],
    food_value_chain_stage: ["Marketing", "Post-harvest"],
    
    atio_innovation_stage: "Scaling with evidence of impact",
    readiness_level: 9,
    adoption_level: "widespread",
    
    country_origin: "Kenya",
    countries_adoption: ["Kenya", "Uganda", "Tanzania", "Rwanda", "Ghana", "Nigeria", "Ethiopia"],
    region: ["East Africa", "West Africa", "Sub-Saharan Africa"],
    
    impact_sdgs: [2, 8, 5, 9],
    impact_indicators: {
      profitability: "15-25% increase in farm gate prices",
      accessibility: "High - works on basic mobile phones",
      productivity: "Indirect - better planning based on market demand"
    },
    
    target_users: ["Smallholder farmers with mobile phones", "Women farmers", "Farmer cooperatives"],
    actual_users: ["Commercial smallholders", "Aggregators", "Rural traders"],
    beneficiaries: ["Farming households", "Rural economies"],
    
    innovation_elements: {
      technological: ["Mobile platform", "SMS gateway", "Market data aggregation"],
      social: ["Farmer training on mobile use", "Group WhatsApp marketing"],
      organizational: ["Market data collection network", "Buyer verification systems"]
    },
    
    information_for_use: "Register for service via SMS or app download. Enter your location and crops. Receive daily or weekly price updates via SMS. Compare prices before selling. Use buyer directory to contact traders directly. Provide feedback on service quality.",
    enabling_conditions: [
      "Mobile phone ownership or access",
      "Mobile network coverage",
      "Basic literacy (for app version)",
      "Affordable data or SMS bundles"
    ],
    constraints: [
      "Requires mobile network infrastructure",
      "May exclude very remote or poorest farmers",
      "Data costs can be barrier",
      "Digital literacy challenges for some users"
    ],
    
    data_source: "M-Farm Kenya impact evaluation (2023), Esoko Ghana studies (2024), GSMA AgriTech report (2024)",
    evidence_strength: "high",
    further_research_needed: [
      "Long-term behavior change and adoption patterns",
      "Gender-differentiated impacts on decision-making",
      "Integration with digital payment systems"
    ],
    
    partners: ["Safaricom", "Esoko", "WeFarm", "FAO", "GSMA"],
    investment_partners: ["World Bank", "USAID", "Mastercard Foundation"],
    
    cost_level: "low",
    labour_intensity: "low",
    
    farmer_friendly_description: "Get today's market prices sent to your phone so you know the best time and place to sell your crops.",
    simple_steps: [
      "Send an SMS to register (often free)",
      "Tell them what crops you grow",
      "Receive price messages on your phone",
      "Compare prices from different markets",
      "Sell when and where prices are best"
    ],
    local_examples: [
      "Peter in Kenya: 'I used to sell maize for 25 shillings. After checking prices on my phone, I found a market paying 35 shillings!' - Bungoma, Kenya",
      "Fatima in Nigeria: 'The messages tell me when to harvest tomatoes for the best price. I make 40% more now.' - Kano, Nigeria"
    ]
  }
];

// Helper function to get readable adoption level
export function getAdoptionLabel(level: string): string {
  switch(level) {
    case "early": return "Early Stage";
    case "growing": return "Growing";
    case "common": return "Common Use";
    case "widespread": return "Widespread";
    default: return level;
  }
}

// Helper function to get adoption badge color
export function getAdoptionBadgeColor(level: string): string {
  switch(level) {
    case "early": return "bg-purple-100 text-purple-800 border-purple-200";
    case "growing": return "bg-blue-100 text-blue-800 border-blue-200";
    case "common": return "bg-green-100 text-green-800 border-green-200";
    case "widespread": return "bg-teal-100 text-teal-800 border-teal-200";
    default: return "bg-slate-100 text-slate-800 border-slate-200";
  }
}

// Helper function to get evidence badge color
export function getEvidenceBadgeColor(level: string): string {
  switch(level) {
    case "high": return "bg-green-100 text-green-800 border-green-200";
    case "medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
    case "low": return "bg-orange-100 text-orange-800 border-orange-200";
    default: return "bg-slate-100 text-slate-800 border-slate-200";
  }
}
