export interface Technology {
  id: string;
  title: string;
  region: string[];
  countries: string[];
  sdgs: number[];
  domain: string;
  innovationType: string;
  readinessLevel: number;
  adoptionLevel: "low" | "medium" | "high";
  evidenceStrength: "low" | "medium" | "high";
  summary: string;
  impact: {
    productivity: number;
    resilience: number;
    nutrition: number;
  };
  costLevel: "low" | "medium" | "high";
  labourIntensity: "low" | "medium" | "high";
  toolsNeeded: string[];
  tags: string[];
  description: string;
  implementationSteps: string[];
  materials: string[];
  farmerTips: string[];
  evidenceLinks: string[];
  scalabilityNotes: string;
  researchGaps: string[];
  contextualConstraints: string[];
  businessModel?: string;
  targetUsers: string[];
  marketSegments?: string[];
  partnerOrganizations: string[];
}

export const mockTechnologies: Technology[] = [
  {
    id: "1",
    title: "Solar-Powered Drip Irrigation System",
    region: ["East Africa", "Sub-Saharan Africa"],
    countries: ["Kenya", "Tanzania", "Ethiopia"],
    sdgs: [2, 6, 13],
    domain: "Water Management",
    innovationType: "Technology",
    readinessLevel: 8,
    adoptionLevel: "medium",
    evidenceStrength: "high",
    summary: "Low-cost solar-powered drip irrigation for smallholder farmers, reducing water use by 60% while increasing yields by 40%.",
    impact: {
      productivity: 40,
      resilience: 65,
      nutrition: 25,
    },
    costLevel: "medium",
    labourIntensity: "low",
    toolsNeeded: ["Solar panel", "Drip pipes", "Water tank", "Basic tools"],
    tags: ["Climate-resilient", "Water-efficient", "Women-friendly"],
    description: "A complete irrigation solution that uses solar energy to pump water through drip lines, delivering water directly to plant roots. Reduces water consumption by up to 60% compared to traditional methods while improving crop yields.",
    implementationSteps: [
      "Install solar panel in sunny location",
      "Set up water storage tank at elevated position",
      "Lay drip lines along crop rows",
      "Connect pump to solar panel and timer",
      "Test system and adjust flow rates",
    ],
    materials: [
      "50W solar panel (or local alternatives: refurbished panels)",
      "12V DC pump (or local alternatives: hand-crank backup pump)",
      "100m drip tape (or local alternatives: perforated hose)",
      "200L plastic drum (or local alternatives: recycled barrels)",
    ],
    farmerTips: [
      "Position panel to face north (in Southern hemisphere) for maximum sunlight - John, Kenya",
      "Check filters weekly to prevent clogging - Amina, Tanzania",
      "Use mulch around plants to retain moisture even better - David, Ethiopia",
    ],
    evidenceLinks: [
      "ICRAF Study 2024: 40% yield increase in Kenya trials",
      "FAO Report 2023: Water savings in smallholder contexts",
      "Journal of Agricultural Engineering 2023",
    ],
    scalabilityNotes: "Successfully scaled across East Africa. Works best in areas with >5 hours daily sunlight. Requires initial investment support but 3-year payback period.",
    researchGaps: [
      "Long-term durability in high-humidity climates",
      "Integration with mobile-based monitoring systems",
      "Impact on groundwater levels with widespread adoption",
    ],
    contextualConstraints: [
      "Requires access to water source within 100m",
      "Best suited for plots 0.25-2 hectares",
      "Initial cost barrier for poorest farmers",
    ],
    targetUsers: ["Smallholder farmers", "Vegetable producers", "Women farmers"],
    partnerOrganizations: ["SunCulture", "KickStart International", "Kenya Agricultural Research Institute"],
  },
  {
    id: "2",
    title: "Mobile Soil Testing Kit",
    region: ["Sub-Saharan Africa", "West Africa"],
    countries: ["Ghana", "Nigeria", "Senegal"],
    sdgs: [2, 15],
    domain: "Soil Health",
    innovationType: "Digital Technology",
    readinessLevel: 7,
    adoptionLevel: "low",
    evidenceStrength: "medium",
    summary: "Smartphone-connected soil testing kit providing instant NPK readings and fertilizer recommendations, reducing over-application by 30%.",
    impact: {
      productivity: 25,
      resilience: 30,
      nutrition: 20,
    },
    costLevel: "low",
    labourIntensity: "low",
    toolsNeeded: ["Smartphone", "Test kit", "Soil samples"],
    tags: ["Digital agriculture", "Low-cost", "Extension-friendly"],
    description: "Portable soil testing device that connects to a smartphone app, providing instant analysis of soil nutrients and pH. Gives customized fertilizer recommendations based on crop type and local conditions.",
    implementationSteps: [
      "Download SoilDoc app on Android phone",
      "Collect soil sample from 15cm depth",
      "Insert soil into test chamber",
      "Connect device to phone via Bluetooth",
      "Receive instant results and recommendations",
    ],
    materials: [
      "SoilDoc device ($40 USD)",
      "Android smartphone (or use extension officer's phone)",
      "Soil sampling tool (or use clean spade)",
    ],
    farmerTips: [
      "Test in multiple spots across your field for better accuracy - Grace, Ghana",
      "Best to test before planting season - Olu, Nigeria",
      "Share the device among farmer group to reduce cost - Fatou, Senegal",
    ],
    evidenceLinks: [
      "CGIAR Study 2024: 30% reduction in fertilizer costs",
      "Digital Agriculture Report Ghana 2023",
    ],
    scalabilityNotes: "Requires smartphone access and basic literacy. Works well when shared among farmer cooperatives. App available in English, French, and local languages.",
    researchGaps: [
      "Accuracy compared to laboratory testing",
      "Performance in clay-heavy soils",
      "User adoption patterns among low-literacy farmers",
    ],
    contextualConstraints: [
      "Requires smartphone with Bluetooth",
      "Internet connection needed for detailed recommendations",
      "May need training for interpretation",
    ],
    businessModel: "Freemium app with device purchase",
    targetUsers: ["Extension officers", "Farmer cooperatives", "Progressive farmers"],
    marketSegments: ["Smallholder farmers in West Africa", "Agricultural extension services"],
    partnerOrganizations: ["SoilCares", "AGRA", "Ministry of Agriculture Ghana"],
  },
  {
    id: "3",
    title: "Push-Pull Pest Management System",
    region: ["East Africa", "Sub-Saharan Africa"],
    countries: ["Kenya", "Uganda", "Tanzania", "Ethiopia"],
    sdgs: [2, 12, 15],
    domain: "Integrated Pest Management",
    innovationType: "Agroecological Practice",
    readinessLevel: 9,
    adoptionLevel: "high",
    evidenceStrength: "high",
    summary: "Chemical-free pest control using intercropping that repels pests while attracting beneficial insects, increasing maize yields by 60-100%.",
    impact: {
      productivity: 80,
      resilience: 70,
      nutrition: 15,
    },
    costLevel: "low",
    labourIntensity: "low",
    toolsNeeded: ["Desmodium seeds", "Napier grass", "Basic planting tools"],
    tags: ["Agroecology", "Chemical-free", "Climate-resilient", "Women-friendly"],
    description: "An intercropping system where maize is planted with Desmodium (which repels stem borers) and surrounded by Napier grass (which attracts and traps pests). Also improves soil fertility and provides livestock fodder.",
    implementationSteps: [
      "Plant Napier grass around field border",
      "Plant maize in rows as usual",
      "Intercrop Desmodium between maize rows",
      "Maintain Desmodium ground cover",
      "Harvest Napier grass for fodder periodically",
    ],
    materials: [
      "Desmodium seeds - available from local agro-dealers or farmer groups",
      "Napier grass cuttings - can get from neighbors who already use system",
      "No special equipment needed",
    ],
    farmerTips: [
      "Desmodium fixes nitrogen too, so you need less fertilizer over time - Mary, Kenya",
      "Cut Napier grass regularly to prevent it spreading into maize - James, Uganda",
      "Works even better when you add manure - Christine, Tanzania",
    ],
    evidenceLinks: [
      "ICIPE 20-year study: 60-100% yield increase",
      "Nature Sustainability 2023: Climate adaptation benefits",
      "FAO Best Practice Guide 2024",
      "Over 200,000 farmers in East Africa using system",
    ],
    scalabilityNotes: "One of the most successful agroecological innovations in Africa. Highly scalable, low cost, and culturally accepted. Works across different farm sizes and agro-ecological zones.",
    researchGaps: [
      "Optimization for different maize varieties",
      "Performance in areas with high rainfall variability",
      "Economic analysis of fodder co-benefits",
    ],
    contextualConstraints: [
      "Desmodium seed availability in some regions",
      "Requires understanding of intercropping principles",
      "May need initial training or demonstration",
    ],
    targetUsers: ["Maize farmers", "Mixed crop-livestock farmers", "Smallholders"],
    partnerOrganizations: ["ICIPE", "CIMMYT", "Vi Agroforestry", "World Agroforestry Centre"],
  },
  {
    id: "4",
    title: "Community Grain Storage with Hermetic Bags",
    region: ["Sub-Saharan Africa"],
    countries: ["Malawi", "Zambia", "Mozambique", "Kenya"],
    sdgs: [2, 12],
    domain: "Post-Harvest Management",
    innovationType: "Technology + Social Innovation",
    readinessLevel: 8,
    adoptionLevel: "medium",
    evidenceStrength: "high",
    summary: "Collective storage using airtight bags reduces post-harvest losses from 30% to under 2%, enabling farmers to sell at better prices.",
    impact: {
      productivity: 0,
      resilience: 85,
      nutrition: 35,
    },
    costLevel: "low",
    labourIntensity: "low",
    toolsNeeded: ["PICS bags", "Storage facility", "Moisture meter"],
    tags: ["Post-harvest", "Women-led", "Income-improving", "Food security"],
    description: "Hermetic storage bags (PICS) that create an oxygen-free environment, killing storage pests without chemicals. Combined with community storage groups for economies of scale and market power.",
    implementationSteps: [
      "Dry grain to 13% moisture or below",
      "Fill PICS bag with dry grain",
      "Seal bag tightly with no air leaks",
      "Store in cool, dry place on pallets",
      "Can store safely for 6+ months",
    ],
    materials: [
      "PICS bags (triple-layer hermetic bags) - $2-3 per bag",
      "Moisture meter (shared by group) - $30",
      "Pallets or raised platform - can use local wood",
    ],
    farmerTips: [
      "Make sure grain is completely dry before sealing - Elizabeth, Malawi",
      "We store together as women's group and sell together for better prices - Agnes, Zambia",
      "Check bags monthly for any damage - Moses, Mozambique",
    ],
    evidenceLinks: [
      "Purdue University study: 98% pest control effectiveness",
      "World Bank 2023: Economic benefits for smallholders",
      "Over 3 million bags sold in Sub-Saharan Africa",
    ],
    scalabilityNotes: "Highly scalable. Works for all grain types. Particularly empowering for women farmers who can time sales better. Low cost and no technical barriers.",
    researchGaps: [
      "Optimal storage duration for different grain varieties",
      "Integration with warehouse receipt systems",
      "Behavior change strategies for adoption",
    ],
    contextualConstraints: [
      "Requires proper drying infrastructure",
      "Some upfront cost (though bags reusable 3-4 seasons)",
      "Works best with farmer group organization",
    ],
    businessModel: "Product sales through agro-dealers",
    targetUsers: ["Smallholder grain farmers", "Women farmer groups", "Cooperatives"],
    marketSegments: ["Maize, bean, and cowpea farmers in SSA"],
    partnerOrganizations: ["Purdue University", "Bill & Melinda Gates Foundation", "Local agro-dealer networks"],
  },
  {
    id: "5",
    title: "AI-Powered Crop Disease Diagnosis App",
    region: ["Sub-Saharan Africa", "East Africa", "West Africa"],
    countries: ["Kenya", "Ghana", "Rwanda", "Nigeria"],
    sdgs: [2, 9],
    domain: "Digital Agriculture",
    innovationType: "Digital Technology",
    readinessLevel: 7,
    adoptionLevel: "low",
    evidenceStrength: "medium",
    summary: "Mobile app using image recognition to diagnose crop diseases and provide treatment recommendations in local languages, achieving 85% accuracy.",
    impact: {
      productivity: 30,
      resilience: 45,
      nutrition: 10,
    },
    costLevel: "low",
    labourIntensity: "low",
    toolsNeeded: ["Smartphone with camera"],
    tags: ["Digital agriculture", "AI-powered", "Extension-friendly", "Multi-language"],
    description: "Smartphone application that uses artificial intelligence to identify crop diseases from photos. Provides instant diagnosis and treatment options, including organic and chemical solutions, in local languages.",
    implementationSteps: [
      "Download PlantVillage or Plantix app (free)",
      "Take clear photo of affected plant part",
      "App analyzes image and identifies disease",
      "Receive treatment recommendations",
      "Access local supplier information",
    ],
    materials: [
      "Android smartphone with camera (can share among farmer group)",
      "Free app download (works offline after initial setup)",
    ],
    farmerTips: [
      "Take photos in good light for best results - Peter, Kenya",
      "Our extension officer uses it to help whole village - Akosua, Ghana",
      "Shows both chemical and natural solutions which I like - Jean, Rwanda",
    ],
    evidenceLinks: [
      "Penn State study 2023: 85% diagnostic accuracy",
      "Digital Green adoption study Kenya 2024",
      "FAO Digital Agriculture Toolkit 2024",
    ],
    scalabilityNotes: "High potential for scale. Works offline after initial model download. Barrier is smartphone access, but effective when used by extension agents serving multiple farmers. Multi-language support increasing.",
    researchGaps: [
      "Performance on local disease variants",
      "Effectiveness with low-quality cameras",
      "User trust and adoption patterns",
      "Integration with local extension services",
    ],
    contextualConstraints: [
      "Requires smartphone access",
      "Works best with clear photos",
      "Some diseases need laboratory confirmation",
      "Treatment availability varies by location",
    ],
    businessModel: "Freemium model with premium features",
    targetUsers: ["Extension officers", "Progressive farmers", "Youth farmers"],
    marketSegments: ["Smallholder vegetable and fruit farmers"],
    partnerOrganizations: ["PlantVillage", "Plantix", "FAO", "National extension services"],
  },
  {
    id: "6",
    title: "Climate-Smart Agroforestry Systems",
    region: ["East Africa", "West Africa", "Sub-Saharan Africa"],
    countries: ["Ethiopia", "Kenya", "Malawi", "Niger", "Burkina Faso"],
    sdgs: [2, 13, 15],
    domain: "Climate Adaptation",
    innovationType: "Agroecological Practice",
    readinessLevel: 9,
    adoptionLevel: "medium",
    evidenceStrength: "high",
    summary: "Integrating nitrogen-fixing trees with crops improves soil fertility, provides fodder and fuelwood, and increases resilience to climate shocks.",
    impact: {
      productivity: 50,
      resilience: 90,
      nutrition: 40,
    },
    costLevel: "low",
    labourIntensity: "medium",
    toolsNeeded: ["Tree seedlings", "Basic planting tools"],
    tags: ["Agroforestry", "Climate-resilient", "Soil restoration", "Multi-benefit"],
    description: "Integration of trees such as Faidherbia albida, Gliricidia, and Leucaena with annual crops. Trees provide nitrogen fixation, organic matter, microclimate improvement, and additional products (fodder, fuelwood, fruit).",
    implementationSteps: [
      "Select appropriate tree species for your zone",
      "Plant tree seedlings at start of rainy season",
      "Space trees to minimize crop shading",
      "Protect young trees from livestock",
      "Prune trees to provide mulch and light to crops",
    ],
    materials: [
      "Tree seedlings (often free from forestry departments or NGOs)",
      "Planting holes preparation",
      "Tree guards for livestock protection (can use local thorny branches)",
    ],
    farmerTips: [
      "Faidherbia loses leaves during crop season so no competition - Samuel, Malawi",
      "Gliricidia prunings make excellent green manure - Binta, Niger",
      "Started with 10 trees, now have 100+ and soil is much better - Tesfaye, Ethiopia",
    ],
    evidenceLinks: [
      "World Agroforestry 30-year trials: 100-400% yield increases",
      "IPCC Report: High potential for climate mitigation and adaptation",
      "Africa Rising project evaluations 2024",
      "Millions of hectares under agroforestry in Africa",
    ],
    scalabilityNotes: "Proven at scale across diverse agro-ecologies. Benefits increase over time. Strong evidence base. Main barriers are seedling availability and initial labour. High cultural acceptance.",
    researchGaps: [
      "Optimal tree-crop configurations for different zones",
      "Economic valuation of all co-benefits",
      "Scaling mechanisms beyond project support",
    ],
    contextualConstraints: [
      "Requires 3-5 years for full benefits",
      "Tree seedling supply chains variable",
      "Land tenure security important for tree investments",
    ],
    targetUsers: ["Smallholder farmers", "Pastoralists transitioning to agro-pastoralism", "Women farmers"],
    partnerOrganizations: ["World Agroforestry (ICRAF)", "World Vision", "Vi Agroforestry", "National forestry services"],
  },
];

export const DOMAINS = [
  "Water Management",
  "Soil Health",
  "Integrated Pest Management",
  "Post-Harvest Management",
  "Digital Agriculture",
  "Climate Adaptation",
  "Agroecology",
  "Livestock",
];

// Official UN SDG Colors
export const SDG_COLORS: Record<number, { bg: string; text: string; hex: string }> = {
  1: { bg: "bg-[#E5243B]", text: "text-white", hex: "#E5243B" }, // No Poverty - Red
  2: { bg: "bg-[#DDA63A]", text: "text-white", hex: "#DDA63A" }, // Zero Hunger - Yellow
  5: { bg: "bg-[#FF3A21]", text: "text-white", hex: "#FF3A21" }, // Gender Equality - Orange-Red
  6: { bg: "bg-[#26BDE2]", text: "text-white", hex: "#26BDE2" }, // Clean Water - Light Blue
  7: { bg: "bg-[#FCC30B]", text: "text-slate-900", hex: "#FCC30B" }, // Clean Energy - Bright Yellow
  8: { bg: "bg-[#A21942]", text: "text-white", hex: "#A21942" }, // Decent Work - Burgundy
  9: { bg: "bg-[#FD6925]", text: "text-white", hex: "#FD6925" }, // Innovation - Orange
  12: { bg: "bg-[#BF8B2E]", text: "text-white", hex: "#BF8B2E" }, // Responsible Consumption - Gold
  13: { bg: "bg-[#3F7E44]", text: "text-white", hex: "#3F7E44" }, // Climate Action - Green
  15: { bg: "bg-[#56C02B]", text: "text-white", hex: "#56C02B" }, // Life on Land - Light Green
};

// Technology Illustrations - using Unsplash images
export const TECH_ILLUSTRATIONS: Record<string, string> = {
  "1": "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=600&h=400&fit=crop", // Solar irrigation
  "2": "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=600&h=400&fit=crop", // Soil testing
  "3": "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&h=400&fit=crop", // Pest management/crops
  "4": "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&h=400&fit=crop", // Grain storage
  "5": "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop", // Mobile app/tech
  "6": "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=600&h=400&fit=crop", // Agroforestry
};

export const SDG_NAMES: Record<number, string> = {
  1: "No Poverty",
  2: "Zero Hunger",
  5: "Gender Equality",
  6: "Clean Water",
  7: "Clean Energy",
  8: "Decent Work",
  9: "Innovation",
  12: "Responsible Consumption",
  13: "Climate Action",
  15: "Life on Land",
};

export const REGIONS = [
  "East Africa",
  "West Africa",
  "Southern Africa",
  "Central Africa",
  "Sub-Saharan Africa",
];

export const COUNTRIES = [
  "Kenya",
  "Tanzania",
  "Ethiopia",
  "Uganda",
  "Ghana",
  "Nigeria",
  "Senegal",
  "Malawi",
  "Zambia",
  "Mozambique",
  "Rwanda",
  "Burkina Faso",
  "Niger",
];